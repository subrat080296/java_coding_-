package OOPS;

interface House{// interface
	int length=20;//final & static
	int width=30;//final & static
	
	void m12();//abstaract method
	
	default void m1() {
		System.out.println("this is a home");
	}
	
	static void room() {  //static method are allowed in interface
		System.out.println("this poka ghara");
	}
	
}

public class Interface_Demo implements House{
	
	public void m12(){                //abstaract method
	System.out.println("This is abstarct method");
	}
	
	public static void main(String[] args) {
		Interface_Demo id=new Interface_Demo();
		id.m12();
		id.m1();

	}

}
