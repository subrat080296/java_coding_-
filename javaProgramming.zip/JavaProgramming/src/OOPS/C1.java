package OOPS;

public class C1 implements Interface_Demo123,Interface_Demo_1234{
	
	public void m1() 
	{
		System.out.println(x);
	}
	
	public void m2()
	{
		System.out.println(y);
	}
	
	public static void main (String[] args)
	{
		C1 obj=new C1();
		obj.m1();
		obj.m2();
	}
}
