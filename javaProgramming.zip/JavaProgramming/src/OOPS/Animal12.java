package OOPS;

public class Animal12 {

	public static void tiger() {
		System.out.println("King");
	}

	public void Lion() {
		System.out.println("Queen");
	}

	public static void main(String[] args) {
		Animal12 a=new Animal12();
		Animal12.tiger();
		a.Lion();


	}

}
