package OOPS;

public interface I2 {
	
	int a=56;
	void m1();

}
