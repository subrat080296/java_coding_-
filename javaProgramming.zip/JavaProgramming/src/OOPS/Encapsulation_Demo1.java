package OOPS;

public class Encapsulation_Demo1 {

		private String name;
		private int age;

	public void setName(String name) {
		this.name=name;
	}
	public void setAge(int age) {
		this.age=age;
	}
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}


	public static void main(String[] args) {
		Encapsulation_Demo1 d=new Encapsulation_Demo1();
		d.setName("rohon");
		d.setAge(40);

		System.out.print(d.getName());
		System.out.println(d.getAge());


	}

}
