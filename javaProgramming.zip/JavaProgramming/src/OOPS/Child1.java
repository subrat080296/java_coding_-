package OOPS;

public class Child1 extends Parent implements I1,I2 {
	 public void m1() {
		System.out.println(a);
	}
	public void m2() {
		System.out.println(b);
	}

	public static void main(String[] args)
	{
		Child1 c=new Child1();
		c.m1();
		c.m2();
		c.display();

	}

}
