package OOPS;

public class Animal_Multilevel {

    public void dog() {
        System.out.println("Dog eats chicken");
    }
}

class MotherDog extends Animal_Multilevel {

    public void wifeDog() {
        System.out.println("Mother dog gives milk");
    }
}

class BabyDog extends MotherDog {

    public void babyDog() {
        System.out.println("Baby dog drinks milk");
    }

    public static void main(String[] args) {

        BabyDog b = new BabyDog();

        b.dog();
        b.wifeDog();
        b.babyDog();
    }
}