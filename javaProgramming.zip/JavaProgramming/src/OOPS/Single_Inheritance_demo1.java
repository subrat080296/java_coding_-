package OOPS;

public class Single_Inheritance_demo1 {

	public void m1() {
		System.out.println("Signle inh");
	}
}
class B extends Single_Inheritance_demo1{
	public void m2() {
		System.out.println("it extended");
	}

	public static void main(String[] args) {
		B b=new B();
		b.m1();
		b.m2();

	}

}
