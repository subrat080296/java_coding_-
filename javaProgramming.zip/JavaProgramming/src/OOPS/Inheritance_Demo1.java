package OOPS;

class Inheritance_Demo1 {
    public void animal() {
        System.out.println("Tiger king");
    }
}

class Cat extends Inheritance_Demo1 {
    public void cat() {
        System.out.println("Cat drinks milk");
    }
}

class Goat extends Cat {
    public void goat() {
        System.out.println("Goat eats grass");
    }

    public static void main(String[] args) {
        Goat g = new Goat();

        g.animal();
        g.cat();
        g.goat();
    }
}