package OOPS;

public class Demo1234 {

	public static void main(String[] args) {
		String s="Sapan Kumar Kar ";
		String [] str=s.split(" ");
		for (String w:str)
		{
			System.out.print(w.charAt(0));
		}


	}

}
