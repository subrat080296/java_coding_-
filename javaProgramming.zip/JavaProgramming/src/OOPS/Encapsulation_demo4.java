package OOPS;

public class Encapsulation_demo4 {
	private  String name;
	private int age;
	public void  setName(String name) {
		this .name=name;
	}
	public void setAge(int age) {
		this.age=age;
	}
	  public String getName() {
	return name;
	}

	  public int getAge() {
		  return age;
	  }

	public static void main(String[] args) {
		Encapsulation_demo4 d4=new Encapsulation_demo4();
		d4.setName("raju");
		d4.setAge(5);
		System.out.println(d4.getName());
		System.out.println(d4.getAge());

	}

}
