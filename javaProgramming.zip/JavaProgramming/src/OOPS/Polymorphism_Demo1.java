package OOPS;

public class Polymorphism_Demo1 {

	public void Bike(String name ,int age) {
		System.out.println("bike name and age");

	}
	public void Bike (String name , int age ,double price) {
		System.out.println("bike name and age and price");
	}

	public void Bike(Double price , int age, String name) {
		System.out.println("Price details , age, name");
	}

	public static void main(String[] args) {
		Polymorphism_Demo1 d1=new Polymorphism_Demo1();
			d1.Bike("bullet", 10);
		  d1.Bike("Sp125", 13, 19500);
		  d1.Bike(50.100, 16, "Bajaj");

	}

}
