package OOPS;

public class Test_Abstract_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
