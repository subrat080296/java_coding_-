package OOPS;

public class Error_HandleDemo {

	public static void main(String[] args) {
		int a=10,b=20,c=30,d=40;
		try {
			a=a%b;
			b=b/0;
			c=d-d;
			System.out.println(a);
			System.out.println(b);
			System.out.println(c);
		}
		catch(Exception e) {
			e.printStackTrace();//it will print error type description and stack trace
		}
		System.out.println(b);
		System.out.println(c);

	}

}
