package OOPS;

public class Encapsulation_demo2 {
	private String BANK;
	private int Accountnumber;
	private int pin;
	private Double balance;
	private char tittle;

	public void setName(String name) {
		this.BANK=name;
	}

	public void setAccountnumber(int number) {
		this.Accountnumber=number;
	}
	public void setPin(int pin) {
		this.pin=pin;
	}
	public void setBalance(Double bal) {
		this.balance=bal;
	}
	public void setchar(char title)
	{
		this.tittle=title;
	}
	public String getName() {
	return BANK;
}
	public int getAccountnumber() {
	return Accountnumber;
}
	public int getpin() {
	return pin;
}
	public Double getbalance() {
	return balance;
}
	public char gettittle() {
	return tittle;
}
	public static void main(String[] args) {
		Encapsulation_demo2 ep=new Encapsulation_demo2();
		ep.setAccountnumber(12345678);
		ep.setPin(1996);
		ep.setBalance(190.3);
		ep.setchar('A');
		ep.setName("SBI");

		System.out.println(ep.gettittle());
		System.out.println(ep.getAccountnumber());
		System.out.println(ep.getbalance());
		System.out.println(ep.getName());
		System.out.println("pin number is:"+ ep.getpin());
	}
}
