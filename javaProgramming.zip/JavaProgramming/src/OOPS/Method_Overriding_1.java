package OOPS;
class a{
void m1() {
	System.out.println("namita jena is a women");
	
}
	
}
class b extends a{
	void m1() {
		System.out.println("Namita is a girl");
		
	}
}

class c extends b{
	void m1() {
		System.out.println("Namita is a kid");
	}
}

public class Method_Overriding_1 {

	public static void main(String[] args) {
		c c1=new c();
		c1.m1();
		a obj=new a();
		obj.m1();
		
		b obj1=new b();
		obj1.m1();
	
	}

}
