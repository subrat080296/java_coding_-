package OOPS;

public interface Interface_Demo_1234 {
	int y=10;
	
	void m2();// this is abstract method
}
