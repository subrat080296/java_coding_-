package OOPS;

public abstract class AB_Dmo_21 {
	
	abstract void animal();
	
	void eat() {
		System.out.println("hence");
	}
}

	
	class Dog extends AB_Dmo_21
	{
		void animal() {
			System.out.println("eat chicken");
		}
		
		void eat() {
			System.out.println("eat");
		}
	

	public static void main(String[] args) {
		AB_Dmo_21 c=new Dog();
		c.animal();
		c.eat();
	}

}
