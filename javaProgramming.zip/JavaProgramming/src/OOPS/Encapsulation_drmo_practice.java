package OOPS;

public class Encapsulation_drmo_practice {
	private String name;
	private int b;

	public void setName (String nam) {
	
	this.name=nam;
	
	}

	public void setAge(int age) {
		this.b=age;
		
	}
	
	public String getName() {
		return name;
	}

	public int getAge() {
		return b;
	}

	public static void main(String[] args) {
		
		Encapsulation_drmo_practice d=new Encapsulation_drmo_practice();
		d.setName("ram");
		d.setAge(19);
		System.out.println(d.getAge());
		System.out.println(d.getName());
	}

}
