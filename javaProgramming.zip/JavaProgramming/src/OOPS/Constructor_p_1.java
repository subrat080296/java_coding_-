package OOPS;

public class Constructor_p_1 {
	
	int x;
	int y;
	
	Constructor_p_1(int a,int b){
		
		this.x=a;
		this.y=b;
	}
		
		void display() {
			System.out.println(x+y);
			System.out.println(x*y);
			
		}
	

	public static void main(String[] args) {
		Constructor_p_1 c=new Constructor_p_1(10,20);
		c.display();
		

	}

}
