package OOPS;

public class Demo123 {

	public static void main(String[] args) {
		System.out.println("Hello");

	}

}
