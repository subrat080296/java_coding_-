package OOPS;

public class Parent {
int z=20;
int v=60;

void display() {
System.out.println(z+v);
}
}
