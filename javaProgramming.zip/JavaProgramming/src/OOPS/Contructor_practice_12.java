package OOPS;

public class Contructor_practice_12 {
	
	String name;
	int age;
	String adress;
	Contructor_practice_12(String nam, int ag, String ad){
		
		this.name=nam;
		this.age=ag;
		this.adress=ad;
	}
	void display() {
		System.out.println(name+""+age+""+adress);
		
	}

	public static void main(String[] args) {
		Contructor_practice_12 v=new Contructor_practice_12("rohon",17,"odisha");
		v.display();

	}

}
