package OOPS;

abstract class Demo_SB_demo1 {

    abstract void monkey();

    void eat() {
        System.out.println("monkey eat tree");
    }
}

class Littlemonkey extends Demo_SB_demo1 {

    void monkey() {
        System.out.println("eats banana");
    }

    public static void main(String[] args) {
        Demo_SB_demo1 d = new Littlemonkey();
        d.monkey();
        d.eat();
    }
}