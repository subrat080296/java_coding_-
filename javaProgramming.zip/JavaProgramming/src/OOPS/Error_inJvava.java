package OOPS;

public class Error_inJvava {

	public static void main(String[] args) {
		String s1="acfder";
		try{

		String s=null;


		System.out.println(s.length());
		System.out.println(s1.length());
		}
		catch(Exception e) {
			System.out.println(e);

		}
		System.out.println(s1.length());
	}

	}


