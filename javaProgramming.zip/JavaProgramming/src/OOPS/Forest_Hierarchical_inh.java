package OOPS;

public class Forest_Hierarchical_inh {

   public void Mangotree() {
        System.out.println("It is a mango tree");
    }
}

class Bananatree extends Forest_Hierarchical_inh {

   public void Banana() {
        System.out.println("Banana tree");
    }
}

class Arjuntree extends Forest_Hierarchical_inh {

   public void Arjun() {
        System.out.println("It is an Arjun tree");
    }
}

class Lemontree extends Forest_Hierarchical_inh {

    public void Lemon() {
        System.out.println("It is a lemon tree");
    }

    public static void main (String[] args)
    {

        Bananatree b = new Bananatree();
        b.Mangotree();
        b.Banana();

        Arjuntree a = new Arjuntree();
        a.Mangotree();
        a.Arjun();

        Lemontree l = new Lemontree();
        l.Mangotree();
        l.Lemon();
    }
}