package OOPS;

public class Encapsulation_Demo3 {

	private String name;
	private double price;
	private int pin;
	 public void setName(String mobilename) {
		 this.name=mobilename;
	 }
	 public void setprice(double price) {
		 this.price=price;
	 }
	 public void setpin(int pin) {
		 this.pin=pin;

	 }
	 public String getName() {
		 return name;
	 }
	 public double getprice()
	 {
		 return price;
	 }
	 public int getpin() {
		 return pin;
	 }

	public static void main(String[] args) {
		Encapsulation_Demo3 demo=new Encapsulation_Demo3();
		demo.setName("nokia");
		demo.setpin(123);
		demo.setprice(10.500);

		System.out.println(demo.getName());
		System.out.println(demo.getprice());
		System.out.println(demo.getpin());

	}

}
