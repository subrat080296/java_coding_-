package OOPS;

class x{
	void m1() {
		int a=10;
		int b=5;

			System.out.println(a+b);
		}
	}

class y extends x{
	void m1() {
		int a=1;
		int b=7;
		System.out.println(a*b);
	}
}


public class Method_Overriding_demo21 {

	public static void main(String[] args) {
		y t=new y();
		t.m1();
		x u=new x();
		u.m1();

	}

}
