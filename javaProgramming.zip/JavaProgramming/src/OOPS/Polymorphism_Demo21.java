package OOPS;

public class Polymorphism_Demo21 {
	
	void  car(int a,int b) {
		System.out.println(a+b);
	}
	
	void car(String name, double price)
	{
		System.out.println(name+""+ price);
	}
	
	void car(int age, int milege ,String run ) {
		System.out.println(age+""+ milege+ " "+run);
	}
	
	public static void main(String[] args) {
		Polymorphism_Demo21 c=new Polymorphism_Demo21();
		c.car(10, 20);
		c.car("tataneno", 3.2);
		
		c.car(13, 18,"km");
		

	}

}
