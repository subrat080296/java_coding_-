package OOPS;

public interface Interface_Demo123 {
	
	int x=10;
	
	void m1();// this is abstract method
	

}
