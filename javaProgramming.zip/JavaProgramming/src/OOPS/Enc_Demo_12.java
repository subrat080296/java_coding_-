package OOPS;

public class Enc_Demo_12 {
	
	private String student;
	private int age;
	private double marks;
	
	
	public void setName(String name) {
		this.student=name;
		
	}
	public void setAge(int ag) {
		this.age=ag;
	}
	public void setMarks(double d) {
		this.marks=d;
	}
	
	public String getName() {
		return student;
	}
	public int getAge() {
		return age;
	}
	public double getMarks() {
		return marks;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Enc_Demo_12 student=new Enc_Demo_12();
		student.setName("bijay");
		student.setAge(20);
		student.setMarks(67.5);
		
		System.out.println(student.getName());
		System.out.println(student.getAge());
		System.out.println(student.getMarks());

	}

}
