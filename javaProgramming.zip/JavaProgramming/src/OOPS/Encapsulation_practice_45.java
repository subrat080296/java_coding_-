package OOPS;

public class Encapsulation_practice_45 {
	
	private int age;
	private String name;
	
	public void setAge(int ag) {
		this.age=ag;	
	}
	public void setName(String nam) {
		this.name=nam;
	}
	
	public int getAge() {
		return age;
	}
	public String getName() {
		return name;
	}

	public static void main(String[] args) {
		Encapsulation_practice_45 e=new Encapsulation_practice_45();
		e.setName("hori");
		e.setAge(18);

		System.out.println(e.getAge());
		System.out.println(e.getName());
	}

}
