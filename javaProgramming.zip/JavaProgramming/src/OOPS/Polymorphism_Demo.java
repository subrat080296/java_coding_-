package OOPS;

public class Polymorphism_Demo {

	void add(int a,int b) {
		System.out.println(a+b);

	}
	 public void add(int a, String s ) {
		System.out.println(a+s);
	}

	public static void main(String[] args) {
		Polymorphism_Demo pm=new Polymorphism_Demo();
		pm.add(10, 20);
		pm.add(10, "sbc");

	}

}
