package OOPS;

public interface I1 {
	
	int b=14;
	void m2();

}
