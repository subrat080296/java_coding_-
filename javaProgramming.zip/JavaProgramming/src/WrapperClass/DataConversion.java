

package WrapperClass;

public class DataConversion {

	public static void main (String[] ergs)
	{

//string to Interger convert
	//String s="welcome", cannot convert
	/*String s1="12345";
	String s2="35";
	System.out.println(Integer.parseInt(s1)+ Integer.parseInt(s2));
	//System.out.println(s1+s2);
	///
	 */
		//String to Decimal/Double number
		/*
		String s3="10.9";
		String s4="18.1";
		System.out.println(Double.parseDouble(s3)+Double.parseDouble(s4));
		*/
		//String to Boolean
		/*
		String s="Selenium"; // String s="True";Except True you pass anything it will all are false
		System.out.println(Boolean.parseBoolean(s));
		*/

		//int, double,bool,char==>String convert

		int a=10;
		double d=10.5;
		boolean bool=true;
		char c='A';

		String s=String.valueOf(a);
		System.out.println(a);

		 s=String.valueOf(d);
		System.out.println(d);

		 s=String.valueOf(bool);
		System.out.println(bool);

		 s=String.valueOf(c);
		System.out.println(c);

}
}

