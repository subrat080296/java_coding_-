package WrapperClass;

public class Data_Conversion {

	public static void main(String[] args) {
		//String--->int
		String s="welcome";

		Integer it=Integer.parseInt(s);
		System.out.println(s.length());

	}

}
