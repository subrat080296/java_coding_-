package CollectionJava;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
public class Reverse_String_Using_C {

	public static void main(String[] args) {
		String s="Automation";
		
		List<Character> list=new ArrayList<>();
		
		for(char ch:s.toCharArray()) {
			list.add(ch);
		}
		Collections.reverse(list);
	
	StringBuilder sb=new StringBuilder();
	for(char ch:list)
	sb.append(ch);
	
	System.out.println(sb);
	}

}
