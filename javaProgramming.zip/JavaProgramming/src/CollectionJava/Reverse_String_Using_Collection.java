package CollectionJava;


//import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
public class Reverse_String_Using_Collection {

	public static void main(String[] args) {
		String s[]= {"abc","def","ghi"};
		
		List<String> list= Arrays.asList(s);
		
		Collections.reverse(list);
		
		System.out.println(list);
		
		

	}

}
