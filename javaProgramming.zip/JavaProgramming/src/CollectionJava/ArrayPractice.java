package CollectionJava;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayPractice {

	public static void main(String[] args) {
		//Declaration for Hertorgenious data

		ArrayList mylist=new ArrayList();

		//List mylist=new ArrayList();
      //ArrayList <String>mylist=new ArrayList<String>();

		//Adding data in to ArrayList
          mylist.add(100);
          mylist.add("welcome");
          mylist.add(10.5);
          mylist.add(100);
          mylist.add(true);
          mylist.add(null);
          mylist.add(null);
          mylist.add("A");

		//How to find the size of Array list
		System.out.println("Size of an arraytlist:"+mylist.size());
		//Prinint data from arraylist(mylist);

		System.out.println("prininting data from arraylist:"+mylist);
	//Remove some element from arraylist
		mylist.remove(4);//here 4 is index number

	System.out.println("prininting after remove:"+mylist);

	//Insert element in the array list
	mylist.add(2,"JAVA");

	System.out.println("prininting after adding:"+mylist);

	//Modify/replace/change the element in the array list
	mylist.set(6,78);
	System.out.println("prininting after Replace:"+mylist);

	//Get a specific index element
	//mylist.get(3);
	System.out.println("prininting a specific element:"+mylist.get(3));
	System.out.println("prininting a specific element:"+mylist.get(2));

	//Reading all elements from arraylist
	//using normal for loop
	/*for (int i=0;i<mylist.size();i++)
	{
		System.out.println(mylist.get(i));
	}
	*/
	//usig for each loop reading all elements
//	for (Object x:mylist){// all type of data will be store in x using Object key
	//System.out.println(x);
	}

	//Using iterator
	/*Iterator it=mylist.iterator();
	while(it.hasNext());{
		System.out.println(it.next());
		*/
	//Check my arraylis is empty or not
	System.out.println(mylist.isEmpty());
	//remove all the elements from arraylist
	ArrayList mylist2=new Arraylist();
	mylist2.add("a");
	mylist2.add("b");
	mylist2.add("x");
	mylist.removeAll(mylist2);
	System.out.println(it.next());
	}
	}


