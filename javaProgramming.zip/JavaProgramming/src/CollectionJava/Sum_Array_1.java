package CollectionJava;

import java.util.ArrayList;
import java.util.Arrays;

public class Sum_Array_1 {

	public static void main(String[] args) {
		Integer []a= {10,30,20,50,10};
		
		ArrayList<Integer>list=new ArrayList<>(Arrays.asList(a));
		
		int sum=0;
		for(int num:list) {
		
		sum=sum+num;
		}
		System.out.println(sum);

	
	}

}
