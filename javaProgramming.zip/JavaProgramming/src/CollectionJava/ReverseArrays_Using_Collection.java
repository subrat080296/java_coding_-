package CollectionJava;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
public class ReverseArrays_Using_Collection {

	public static void main(String[] args) {
		Integer a[]= {10,20,30,40};
		
	  List<Integer> list= Arrays.asList(a);
		
		Collections.reverse(list);
		
		System.out.println(list);
	}

}
