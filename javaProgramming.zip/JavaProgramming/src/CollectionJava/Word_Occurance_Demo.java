package CollectionJava;

import java.util.HashMap;

public class Word_Occurance_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String s="hello java how are you java";
		
		String words[]=s.split(" ");
		
		HashMap <String, Integer> map=new HashMap<>();
		
		for (String word:words) {
			map.put(word, map.getOrDefault(word, 0)+1);
		}
		
		for(String word:map.keySet()) {
			if(map.get(word)>1) {
		
		          System.out.println(word+" "+map.get(word));
			}
		}

	}

}
