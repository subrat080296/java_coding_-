package CollectionJava;

import java.util.HashSet;
import java.util.*;
import java.util.Collection;

public class HashSet {

	public static void main(String[] args) {
		//Declearation
		//java.util.HashSet<E> myset=new Hashset();
		//Set myset1=new Hashset();

	     HashSet myset = new HashSet();

		//Homogenious data
	//	Hashset <String>myset=new Hashset<String>();

  //Adding elements in to the Hashset

		 myset.add(100);


		System.out.println(myset);
	}

	//private void add(int i) {
		// TODO Auto-generated method stub

	}


