package CollectionJava;

//import java.util.LinkedList;
import java.util.LinkedList;

public class Linked_List_Demo {

	public static void main(String[] args)
	{
		LinkedList l=new LinkedList();

		l.add("Ram");
		l.add(100);
		l.add('C');
		l.add(null);
		l.add(0,"SOFTWARE");
		System.out.println(l);

	}

}
