package Inheritance;

class S
{
int a=23;
void display()
{
System.out.println(a);
}
}
class D extends S
{
	int b=45;
	void show()
	{
		System.out.println(b);
	}
}
class C extends D
{
	int c=28;
			void output()
			{
				System.out.println(c);
			}
}
public class MultilevenInheritance {

	public static void main(String[] args) {
	C bobj=new C();
	System.out.println(bobj.a);
	System.out.println(bobj.b);
	System.out.println(bobj.c);
//bobj.display();
////bobj.show();
//bobj.output();

}
}

