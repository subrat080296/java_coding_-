package Inheritance;
class A
{
int a=23;
void display()
{
System.out.println(a);
}

}
class B extends A
{
	int b=45;
	void show()
	{
		System.out.println(b);
	}
}

public class Inheritance1 {

	public static void main(String[] args) {
	B bobj=new B();
	System.out.println(bobj.a);
	System.out.println(bobj.b);
bobj.display();
bobj.show();


}
}
