
public class PracticeJava {
	static int num=32434;
	static char c ='A';
	static String s ="Rohit";
	 int num1=3256789;
	 char c1 ;
	 String s1 ="David";

	 {
		 System.out.println("Raja");
	 }
	public static void m1()//Static method we can acces by the help of class name in other class
	{
	   char c4 ;
	   int i=12343;
	   String s="Chandan";
		//System.out.println(c4);
		System.out.println(i);
		System.out.println(PracticeJava.num);
		PracticeJava pv=new PracticeJava();
		System.out.println(pv.num1);
		System.out.println(pv.c1);
		System.out.println(pv.s1);
		System.out.println(num);
	}
	/*public  void m2() {
		static char c5 ='A';
		System.out.println("m2 non static method");

	}
*/
	public static void main(String[] args) {
		PracticeJava obj=new PracticeJava();//by the help of new keyword we can create an object
	//m1();



System.out.println(obj.num1);
System.out.println(obj.s1);
System.out.println(obj.c1);
//System.out.println(c);
//System.out.println(s);

	}

}

