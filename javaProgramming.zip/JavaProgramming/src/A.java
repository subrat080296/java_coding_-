
public class A {

	public static void main(String[] args) {
		PracticeJava obj=new PracticeJava();
		System.out.println(obj.num1);
		System.out.println(PracticeJava.c);//for static varriable we can  accees using class name
		System.out.println(PracticeJava.s);

		PracticeJava.m1();
		//obj.m2();



}
}
