package InterviewQuestionPractive;

public class FindDuplicateNumber {

	public static void main(String[] args) {
		// 23,9,8,9,56,34,50,23,67,50
		//int count=0;
		int[] a= {23,9,8,9,56,34,50,23,67,50,8,8,34,9,9};
		for (int i=0;i<a.length;i++) {
			for (int j=i+1;j<a.length;j++)
			{
				if (a[i]==a[j])
						{
					          System.out.print(a[i]+" "+i);

						}
			}
		}

	}

}
