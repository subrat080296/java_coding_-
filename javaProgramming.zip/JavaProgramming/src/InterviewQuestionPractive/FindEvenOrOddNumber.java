package InterviewQuestionPractive;

public class FindEvenOrOddNumber {

	public static void main(String[] args)
	{
		int num=459799314;
		int even_count=0;
		int odd_count=0;
		//even count and odd count
		while(num>0)//check number is greater than 0
		{
			int lastnumber=num%10; //for check/extract last digit reminder using num%10
			if(lastnumber%2==0)// last number is even or odd
			{
				even_count++;
			}
			else
			{
				odd_count++;
			}
			num=num/10; //this expression will delete that last number 123344431
		}

		System.out.println("eveb number count is:"+even_count);
		System.out.println("odd number count is:"+odd_count);
	}
}
