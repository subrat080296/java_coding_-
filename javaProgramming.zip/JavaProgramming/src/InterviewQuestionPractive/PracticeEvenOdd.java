package InterviewQuestionPractive;

public class PracticeEvenOdd {

	public static void main(String[] args) {
		int x=56788769;
		int even_n=0;
		int odd_n=0;
		while(x>0)
		{
			int l=x%10;
			if(l%2==0) {
				even_n++;
			}
			else
			{
				odd_n++;
			}
		x=x/10;
		}
System.out.println("even no count is:"+ even_n);
System.out.println("odd no count is:"+ odd_n);
	}

}
