package InterviewQuestionPractive;

public class SecondLargestDemo {

	public static void main(String[] args) {
		int[] a= {12,78,56,34,90};
		 int temp;
		 for (int i=0;i<a.length-1;i++)
		 {
		 for (int j=i+1;j<a.length-1;j++)

		 {
			 if(a[j]>a[i])
			 {

			 temp=a[i];
			 a[i]=a[j];
			 a[j]=temp;

		 }
		 System.out.println(a[j]);
	}

}
}
}