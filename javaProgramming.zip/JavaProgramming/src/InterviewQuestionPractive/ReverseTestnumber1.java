package InterviewQuestionPractive;

public class ReverseTestnumber1 {

	public static void main(String[] args) {
		int[] a= {23,78,65,90,};
		int first=a[0];
		int second=a[0];
		{
			for (int element : a) {
				if (element>first) {
					 second=first;
					 first=element;
				 }
				 else if(element>second) {
					 second=element;
				 }
			}
	System.out.println(second);

		}
	}

}
