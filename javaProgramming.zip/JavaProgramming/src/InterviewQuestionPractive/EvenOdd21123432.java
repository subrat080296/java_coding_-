package InterviewQuestionPractive;

public class EvenOdd21123432 {

	public static void main(String[] args) {
		// find even or odd number in 67457873
		int number=676757873;
		int even_number=0;
		int odd_number=0;
		while(number>0)
		{
			int lastnumber=number%10;
		if (lastnumber%2==0)
			{
				even_number++;
			}
			else
			{
				odd_number++;
			}
			number=number/10;
		}
System.out.println(even_number);
System.out.println(odd_number);
	}

}
