package InterviewQuestionPractive;

public class Remove_Duplicate_String {

	public static void main(String[] args) {
		String s="subratajena";
		//String duplicate=0;
		for(int i=0;i<=s.length()-1;i--) {
			for (int j=0;j<=s.length()-1;j++)
			{
				if(i==j)
				 {
					;
						//duplicate ++
//}
//s/=10;
				}

		System.out.println(i);


	}
		}
	}
}
