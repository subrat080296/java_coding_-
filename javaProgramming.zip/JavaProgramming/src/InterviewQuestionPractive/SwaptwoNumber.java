package InterviewQuestionPractive;

public class SwaptwoNumber {
//swap 2 number
	public static void main(String[] args) {
		/*int a=20;
		int b=50;
		int t=a; //Using third variable
		a=b;
		b=t;
		System.out.println(a+" "+b);

*/
		//Without using third variable
		int a=50;
		int b=60;
		a=a+b;//50+60=110
		b=a-b;//110-60=50
		a=a-b;
		System.out.println(a +" "+b);
	}

}
