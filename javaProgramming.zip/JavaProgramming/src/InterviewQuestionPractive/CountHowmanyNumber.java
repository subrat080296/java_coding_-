package InterviewQuestionPractive;

public class CountHowmanyNumber {

	public static void main(String[] args)
	{
		int num=445658;

		int count=0;

		while(num>0)
		 {
			 num=num/10;
			 count++;
		 }
			System.out.println(count);

	}

}
