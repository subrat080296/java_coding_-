package InterviewQuestionPractive;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class HowtoWriteTextinTextFile {

    public static void main(String[] args) throws IOException {

        FileWriter f = new FileWriter( "C:\\Users\\a859230\\OneDrive - Eviden\\Documents\\SEAMLESS INPUTS\\output.txt");

        BufferedWriter bw = new BufferedWriter(f);

        bw.write("Selenium Practice1");
        bw.newLine();
        bw.write("Selenium Practice2");
        bw.newLine();
        bw.write("Selenium Practice3");
        bw.newLine();
        bw.write("Selenium Practice4");

        bw.close();

        System.out.println("Finished !!!");
    }
}