package InterviewQuestionPractive;

import java.io.BufferedReader;
import java.io.FileReader;

public class ReadTextFile {

    public static void main(String[] args) throws Exception {

        FileReader fr =
                new FileReader("C:\\Users\\a859230\\OneDrive - Eviden\\Documents\\GR.txt");

        BufferedReader br = new BufferedReader(fr);

        String str;

        while ((str = br.readLine()) != null) {
            System.out.println(str);
        }

        br.close();
        fr.close();
    }
}