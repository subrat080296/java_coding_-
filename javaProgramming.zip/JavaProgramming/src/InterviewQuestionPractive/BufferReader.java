package InterviewQuestionPractive;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class BufferReader {

    public static void main(String[] args) throws IOException {

        FileReader fr = new FileReader(
            "C:\\Users\\a859230\\OneDrive - Eviden\\Documents\\GR.txt");

        BufferedReader br = new BufferedReader(fr);

        String str;

        while ((str = br.readLine()) != null) {
            System.out.println(str);
        }

        br.close();
        fr.close();
    }
}