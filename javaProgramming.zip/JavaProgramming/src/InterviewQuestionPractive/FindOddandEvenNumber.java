package InterviewQuestionPractive;

public class FindOddandEvenNumber {

	public static void main(String[] args) {
		int num=876474;
		int even_no=0;
		int odd_no=0;
		while (num>0)
		{
			       int rem=num%10;
					if (rem%2==0)
					{
						even_no++;
			}
			else
			{
				odd_no++;

			}
					num=num/10;
		}
		System.out.println(even_no);
	System.out.println(odd_no);
	}

}
