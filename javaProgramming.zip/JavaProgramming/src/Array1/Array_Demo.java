package Array1;

public class Array_Demo {

	public static void main(String[] args) {
		int []a= {10,20,30};
		
		for(int a1:a) {
		
		System.out.print(a1+" ");
		}

	}

}
