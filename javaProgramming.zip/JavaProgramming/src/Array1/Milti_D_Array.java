package Array1;

public class Milti_D_Array {

	public static void main(String[] args) {
		int a[][]= { {56,89,90},{76,83,23},{43,75,38} };
		
		for (int i=0;i<a.length;i++) {
			for (int j=0;j<a[i].length;j++) {			
				{
					System.out.print(a[i][j]);
				}
			}
		}

	}

}
