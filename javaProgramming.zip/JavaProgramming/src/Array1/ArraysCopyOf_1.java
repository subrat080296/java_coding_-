package Array1;

import java.util.Arrays;

public class ArraysCopyOf_1 {

	public static void main(String[] args) {
		int a[]= {10,20,30,40,50};
		System.out.println(Arrays.toString(Arrays.copyOf(a, a.length)));

	}

}
