package Array1;

public class Single_D_Array {

	public static void main(String[] args) {
		int [] a= {12,6,89};
		
		for(int i=0;i<a.length;i++) {
			System.out.println(i);
		}

	}

}
