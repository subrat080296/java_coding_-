package Array1;

import java.util.Arrays;

public class ArraysBinarySearch_1 {

	public static void main(String[] args) {
		int a[]= {12,89,45,23,90,28,10};
		//Arrays.sort(a);
	System.out.print(Arrays.binarySearch(a,45));

	}

}
