package Array1;

import java.util.Arrays;

public class CopyOfRange_1 {

	public static void main(String[] args) {
		int a[]= {10,20,30,40,50,80,90,60,40};
		System.out.println(Arrays.toString(Arrays.copyOfRange(a,5,9)));

	}

}
