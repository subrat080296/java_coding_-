package Array1;

import java.util.Arrays;

public class ArraysFill_1 {

	public static void main(String[] args) {
		int a[]=new int[5];
		Arrays.fill(a, 100);		
		System.out.println(Arrays.toString(a));// for fill same number mutiple times

	}

}
