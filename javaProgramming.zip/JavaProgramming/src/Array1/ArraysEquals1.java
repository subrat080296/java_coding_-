package Array1;

import java.util.Arrays;

public class ArraysEquals1 {

	public static void main(String[] args) {
		int a[]= {10,20,3,30,40};
		int b[]= {10,30,50,30,60};
		System.out.println(Arrays.equals(a,b));//false A and B are not Equal.

	}

}
