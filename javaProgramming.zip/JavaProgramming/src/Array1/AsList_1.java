package Array1;

import java.util.Arrays;

public class AsList_1 {

	public static void main(String[] args) {
		String s[]= {"ram","hori","jena","word"};
		System.out.println(Arrays.asList(s));

	}

}
