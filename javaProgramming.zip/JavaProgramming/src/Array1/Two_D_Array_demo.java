package Array1;

public class Two_D_Array_demo {

	public static void main(String[] args) {
		int a[][]= {{10,20,30},
				{40,50,60},
				{70,80,90}
				};
		
		
		System.out.println(a[1][2]);
		System.out.println(a[2][1]);

	}

}
