package Array1;

public class Array_Length {

	public static void main(String[] args) {
		int a[]= {10,20,30,80};
		System.out.println(a.length);

	}

}
