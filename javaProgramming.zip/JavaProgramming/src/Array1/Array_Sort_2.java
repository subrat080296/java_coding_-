package Array1;

import java.util.Arrays;

public class Array_Sort_2 {

	public static void main(String[] args) {
		int a[]= {50,30,20,10};
		Arrays.sort(a);
		System.out.println(Arrays.toString(a));// to String is Used for readable formate
	}

}
