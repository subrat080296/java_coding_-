package Array1;

public class Two_D_Array {

	public static void main(String[] args) {
		
		
		int [][]a= {{12,90,87,56},{15,87,93,25,67}};
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[i].length;j++) {
				System.out.print(a[i][j]+ " ");
			}
		}
		
	}

}
