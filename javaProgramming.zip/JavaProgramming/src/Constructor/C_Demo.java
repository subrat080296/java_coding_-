package Constructor;

public class C_Demo {
	
	int age;
	String name;
	int rollno;
	String title;
	int mark;
	
	C_Demo (){
		age=20;
		name="Rohit";
		rollno=12;
		title="jena";
		mark=590;
	}
        void display() {
	System.out.println(age);
	System.out.println(name);
	System.out.println(rollno);
	System.out.println(title);
	System.out.println(mark);
}

	public static void main(String[] args) {
		C_Demo  s= new C_Demo();
		s.display();

	}

}
