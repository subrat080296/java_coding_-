package Constructor;

public class Constructor_Practice_1 {
	
	String name;
	String tittle;
	int mobileno;
	int pin;
	String mail;
	String male;
	String female;
	String sex;
	String add;
	
	Constructor_Practice_1(){
		
		this.name="Raj";
		this.tittle="das";
		this.mobileno=868667623;
		this.pin=75689;
		this.mail="jenas42567@gmail.com";
		this.male="M";
		this.female="F";
		this.sex="male";
		this.add="uplat";
		
	}
	void display() {
		System.out.println(name);
		System.out.println(tittle);
		System.out.println(mobileno);
		System.out.println(mail);
		System.out.println(male);
		System.out.println(female);
		System.out.println(sex);
		System.out.println(add);
	}
	


	public static void main(String[] args) {
		Constructor_Practice_1 v=new Constructor_Practice_1();
		v.display();

	}

}
