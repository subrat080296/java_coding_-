package Constructor;

public class Practice_Constructor {
	int xx;
	int zz;
	
	Practice_Constructor(){
		 xx=30; 
	      zz=10;
	}
	void sum()
	{
		System.out.println(xx+zz);
	}


	public static void main(String[] args) {
		Practice_Constructor pc=new Practice_Constructor();
		pc.sum();

	}

}
