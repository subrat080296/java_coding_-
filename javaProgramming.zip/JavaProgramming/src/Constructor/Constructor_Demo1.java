package Constructor;

public class Constructor_Demo1 {
	
	int age;
	String name;
	boolean mark;
	
	Constructor_Demo1(int ag,String nam,boolean marks){
		this.age=ag;
		this.name=nam;
		this.mark=marks;
	}
		void display() 
		{
			System.out.println(age+""+ name +""+mark);
			
		}
		
	

	public static void main(String[] args) {
		
		Constructor_Demo1 d= new Constructor_Demo1(18, "Ram" ,true);
		d.display();
		

	}

}
