package Constructor;

public class Default_Constructor_1 {
	
	int x , y;
	
	Default_Constructor_1(){
		this.x=10;
		this.y=50;
	}
 void Display() {
	 System.out.println(x+y);
 }
	public static void main(String[] args) {
		
		Default_Constructor_1 d=new Default_Constructor_1();
		d.Display();
	}

}
