package Constructor;

public class P_constructor {
	
	int loginId;
	String pass;
	
	 P_constructor(int id, String p) {
		this .loginId=id;
		this.pass=p;
	}
	 void display() {
		 System.out.println(loginId);
		 System.out.println(pass);
	 }
	

	public static void main(String[] args) 
	{
		P_constructor p=new P_constructor(8675786, "Satra");
		P_constructor p1=new P_constructor(867573, "Satrachaha");
		P_constructor p2=new P_constructor(867526, "SatraNath");
		P_constructor p3=new P_constructor(867546, "Satrajit");
		
		
		p.display();
		p1.display();
		p2.display();
		p3.display();
		

	}

}
