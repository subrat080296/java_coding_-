package Constructor;

public class Parameterizes_Constructor1 {
	int age;
	String name;
	String add;
	Parameterizes_Constructor1(int ag, String nam , String ad){
		this.age=ag;
		this.name=nam;
		this.add=ad;
	}
	void display() {
		System.out.println(age +" "+name +" "+ add);
	}

	     public static void main(String[] args) 
	     {
		Parameterizes_Constructor1 f=new Parameterizes_Constructor1(18 , "rohim" ,"kolkata");
		Parameterizes_Constructor1 f1=new Parameterizes_Constructor1(19 , "rohon" ,"delhi");
		
		f.display();
		f1.display();
		

	}

}
