package FullJava;

public class String_revAutatomation {

	public static void main(String[] args) {
		String s="Automation Learning";
	//	String []s1=s.split(" ");
		for (int i=s.length();i>=0;i--) {
			for (int j=0;j<s.length();j++) {
				System.out.println(s.charAt(i)+ " "+s.charAt(j));
			}
		}
	}

}
