package FullJava;

import java.util.Arrays;

public class Shorting_Arrays {

	public static void main(String[] args) {
	int a[]= {10,30,20,10,80,50,60};
	{
		System.out.println(Arrays.toString(a));//10,30,20,10,80,50,60
	}

      Arrays.sort(a);

	System.out.println(Arrays.toString(a));
	}
}
