package FullJava;

import java.util.Scanner;

public class Input_Scanner {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Name");
		//String s=sc.next();
		String ch=sc.next();
	    Double d=sc.nextDouble();

		System.out.println(ch);
	}

}
