package FullJava;

public class Replace_Words {

	public static void main(String[] args) {
		String s="Welcome to slenium";
		System.out.println(s.contains("Wel"));
		System.out.println(s.contains("to"));
		System.out.println(s.contains("slenium"));
		System.out.println(s.contains("wel"));
	}

}
