package FullJava;

public class Upper_to_Lower {

	public static void main(String[] args) {
		String s="HELLO";
		String s1="HOW R YOU";
		System.out.println(s.toLowerCase());
		System.out.println(s1.toLowerCase());
	}

}
