package FullJava;

public class FullJavaCurse {

	public static void main(String[] args) {


	}

}
