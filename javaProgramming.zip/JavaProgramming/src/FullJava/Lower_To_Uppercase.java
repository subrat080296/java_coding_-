package FullJava;

public class Lower_To_Uppercase {

	public static void main(String[] args) {
		String s="hello how r you";
		String s1="Subrata jena";
		System.out.println(s1.toUpperCase());

	}

}
