package FullJava;

import java.util.Scanner;

public class Multiple_Inputs {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
	      int i=sc.nextInt();
	      System.out.println("Given the number" +i);
	      String s=sc.next();
	      System.out.println("Enter your name"+ s);
	      Double d=sc.nextDouble();
	      System.out.println(" the Decimal number" + d);
	}

}
