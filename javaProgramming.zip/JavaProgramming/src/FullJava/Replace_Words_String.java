package FullJava;

public class Replace_Words_String {

	public static void main(String[] args) {
		String s="Well come to java";
		System.out.println(s.replace('e','x'));

		String s1="Namita Jena";
  System.out.println(s1.replace('N', 'S'));
	}

}
