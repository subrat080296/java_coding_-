package FullJava;

public class SingleDimensional_Array {

	public static void main(String[] args) {
		int a[]= {23,89,67,45,9};
		for(int x:a)
		{
			System.out.println(x);
		}


	}

}
