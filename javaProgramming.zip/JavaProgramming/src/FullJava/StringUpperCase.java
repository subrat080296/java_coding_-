package FullJava;

public class StringUpperCase extends String_Input {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Hello Java";
		//s=s.toUpperCase();
		//s=s.toLowerCase();
		System.out.println(s.length());
		System.out.println(s.substring(0,9));
		System.out.println(s.contains("Java"));
		System.out.println(s.charAt(9));
		String newS=s.replace("Java","World");
		System.out.println(newS);
		//System.out.println(s);

	}

}
