package FullJava;

public class Test_Claas_Demo {
	//Variables
	int eid;
	String ename;
	String job;
	int sal;

	//Methods
	void display(){
		System.out.println(eid);
		System.out.println(ename);
		System.out.println(job);
		System.out.println(sal);
	}

	public static void main(String[] args) {

		Test_Claas_Demo emp=new Test_Claas_Demo();
		emp.eid=101;
		emp.ename="ram";
		emp.job="Manager";
		emp.sal=1000;
		emp.display();


	}

}
