package FullJava;

public class Length_Array {

	public static void main(String[] args) {
		//int a[]= {12,89,90,56};
		//for(int x:a) {
		//System.out.println(x);

		String s="Hello";
		String s2="Java";
		String s3="How are you";
		//System.out.println(s+" "+s2);
		//System.out.println(s.concat(s2).concat(s3));
         System.out.println("Hello"+"Java"+"How are you");
	}
	}


