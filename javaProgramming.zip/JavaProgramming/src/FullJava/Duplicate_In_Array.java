package FullJava;

public class Duplicate_In_Array {
	public static void main (String[] args) {
		int a[]= {20,80,55,40,20,80,34,56};
		int num=80;
		int count=0;
		for(int x:a)
		{
			if(x==num)
			{
				count++;
			}
		}
			System.out.println(count);

	}

}

