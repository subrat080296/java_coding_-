package FullJava;

public class String_Methods {

	public static void main(String[] args) {
		String s="  Hello   ";
		System.out.println("before trim:" + s.length());
		System.out.println("After Trim:" +s.trim().length());


	}

}
