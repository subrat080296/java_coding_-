package FullJava;

public class Substring_1 {

	public static void main(String[] args) {
		String s="Satrajit Nath";
		System.out.println(s.substring(0,4));
		System.out.println(s.substring(4,13));

	}

}
