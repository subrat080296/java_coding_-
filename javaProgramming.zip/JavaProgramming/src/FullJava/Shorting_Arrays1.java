package FullJava;

import java.util.Arrays;

public class Shorting_Arrays1 {

	public static void main(String[] args) {
		int a[]= {34,78,56,90,98,67,22,10};
		{
			System.out.println(Arrays.toString(a));
			Arrays.sort(a);
			System.out.println(Arrays.toString(a));
		}

	}

}
