package FullJava;

import java.util.Arrays;

public class Sorting_String {

	public static void main(String[] args) {
		String s[]= {"abc","xyz","hgb","kjl","omk","rft"};
		{
			System.out.println(Arrays.toString(s));
			Arrays.sort(s);
			System.out.println(Arrays.toString(s));
		}
	}

}
