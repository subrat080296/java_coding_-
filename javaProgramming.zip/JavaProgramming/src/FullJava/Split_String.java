package FullJava;

public class Split_String {

	public static void main(String[] args) {
		String s="abc@gmail.com";
		String a[]=s.split("@");//it is divited int 2 parts abc and gmail.com
		System.out.print(a[0]);
		System.out.println(a[1]);



	}

}
