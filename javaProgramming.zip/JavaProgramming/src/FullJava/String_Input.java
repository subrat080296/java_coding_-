package FullJava;

import java.util.Scanner;

public class String_Input {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your city name");
		String s=sc.next();
		System.out.println("Your city name is:" + s);

	}

}
