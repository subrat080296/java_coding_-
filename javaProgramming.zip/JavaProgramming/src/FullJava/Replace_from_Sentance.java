package FullJava;

public class Replace_from_Sentance {

	public static void main(String[] args) {
		String s="How are you";
		//System.out.println(s.replace('w', 'O'));
		System.out.println(s.replace("How", "Who"));
	}

}
