package FullJava;

import java.util.Arrays;

public class Sorting_char {

	public static void main(String[] args) {
		char ch[]= {'A','B','X','D','K','E'};
		{
			System.out.println("Before soting" + Arrays.toString(ch));
			Arrays.sort(ch);
			System.out.println("Atfer sorting"+Arrays.toString(ch));
		}

	}

}
