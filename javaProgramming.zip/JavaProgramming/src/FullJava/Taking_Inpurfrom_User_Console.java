package FullJava;

import java.util.Scanner;

public class Taking_Inpurfrom_User_Console {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
	int number=sc.nextInt();

System.out.println(number);
	}

}
