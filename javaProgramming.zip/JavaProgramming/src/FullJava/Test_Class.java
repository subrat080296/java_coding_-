package FullJava;

public class Test_Class extends OOPS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
