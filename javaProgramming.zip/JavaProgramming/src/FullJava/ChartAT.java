package FullJava;

public class ChartAT {

	public static void main(String[] args) {

        String s="HELLO WORLD";
        System.out.println(s.charAt(8));
	}

}
