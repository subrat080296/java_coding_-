package FullJava;

public class Array_Program {
//find any specific element or number
	public static void main(String[] args) {
	int a[]= {10,20,30,70,50,80};
	int search_element=30;
	for (int i=0;i<=a.length;i++) {
		if(a[i]==search_element)
		{
			System.out.println("Element found"+ a[i]);
			break;
		}

	}

	}

}
