package FullJava;

import java.util.Scanner;

public class Array_Length_Trim {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your words");
		String s=sc.next();
		System.out.println(sc);
	}

}
