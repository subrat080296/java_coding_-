package FullJava;

import java.util.Scanner;

public class Input_Double_Decimalnumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any decimal number");
		double d=sc.nextDouble();
		System.out.println("Given no is" + d);

	}

}
