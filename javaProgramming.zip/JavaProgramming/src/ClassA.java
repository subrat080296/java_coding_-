
public class ClassA {
	static int b=20;//static variable
	int c=30;//Instance variable

	public static void main(String[] args) {
		int a =10;//local variable
//to print local varible just use print statement
		System.out.println(a);
		// For access the Static varible just use class name and obj
		ClassA.b=30;
		System.out.println(ClassA.b);

		//For acces instance Variable access we can create an abject
		ClassA A=new ClassA();
		System.out.println(A.c);
	}

}
