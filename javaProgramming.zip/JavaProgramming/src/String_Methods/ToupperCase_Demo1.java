package String_Methods;

public class ToupperCase_Demo1 {

	public static void main(String[] args) {
		String s="HellO";
		System.out.println(s);
		System.out.println(s.toLowerCase());

	}

}
