package String_Methods;

public class Length_demo {

	public static void main(String[] args) {
		String s="cssssssssssssssdhdhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh";
		System.out.println(s.length());

	}

}
