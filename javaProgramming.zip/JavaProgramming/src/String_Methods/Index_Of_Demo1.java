package String_Methods;

public class Index_Of_Demo1 {

	public static void main(String[] args) {
		String s="how are you";
		
		System.out.println(s.indexOf('r'));

	}

}
