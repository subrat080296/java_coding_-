package String_Methods;

public class ValueOf_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="Hello";
		
		//int a=100;
		
		
		System.out.println(String.valueOf(2));

	}

}
