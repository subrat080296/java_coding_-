package String_Methods;

public class Replace_Demo1 {

	public static void main(String[] args) {
		String s="how are you";
		System.out.println(s.replace("r","R"));

	}

}
