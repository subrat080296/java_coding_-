package String_Methods;

public class Trim_Demo1 {

	public static void main(String[] args) {
		String s="    Hello    ";
		System.out.println(s);
		System.out.println(s.length());
		
		System.out.println(s.trim().length());
		String s3=s.trim();
		System.out.println(s3);

	}

}
