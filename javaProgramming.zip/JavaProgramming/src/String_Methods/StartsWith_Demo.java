package String_Methods;

public class StartsWith_Demo {

	public static void main(String[] args) {
		String s="java selenium python ruby";
		
		System.out.println(s.startsWith("java"));

	}

}
