package String_Methods;

public class EqualsIgnoreCase_Demo {

	public static void main(String[] args) {
		String s="hello";
		String s2="Hello";
		if(s.equalsIgnoreCase(s2)) {
			System.out.println("True");
		}

	}

}
