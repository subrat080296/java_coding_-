package String_Methods;

public class EndsWith_demo {

	public static void main(String[] args) {
		String s="ruby python java Math";
		System.out.println(s.endsWith("Math"));

	}

}
