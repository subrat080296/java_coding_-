package String_Methods;

public class SubString_Demo1 {

	public static void main(String[] args) {
		String s="Java selenium";
		
		System.out.println(s.substring(0,9));

	}

}
