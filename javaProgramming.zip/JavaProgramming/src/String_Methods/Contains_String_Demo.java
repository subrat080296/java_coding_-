package String_Methods;

public class Contains_String_Demo {

	public static void main(String[] args) {
		String s="abcdefghijakl";
		
		System.out.println(s.contains("j"));

	}

}
