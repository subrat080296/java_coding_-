package String_Methods;

public class ChartAt_Index_demo {

	public static void main(String[] args) {
		String s="abcdefghi";
		System.out.print(s.charAt(2));

	
	}

}
