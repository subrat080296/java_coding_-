package String_Methods;

public class LastIndexOf_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="Hello java";
		
		System.out.println(s.lastIndexOf('j'));

	}

}
