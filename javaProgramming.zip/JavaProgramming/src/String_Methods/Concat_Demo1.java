package String_Methods;

public class Concat_Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="hello";
		String s2="Java";
		System.out.println(s.concat(s2));

	}

}
