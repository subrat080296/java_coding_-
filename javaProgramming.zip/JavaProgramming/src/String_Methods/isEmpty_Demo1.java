package String_Methods;

public class isEmpty_Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="Hello java";
		String s1="";
		
		System.out.println(s.isEmpty());
		
		System.out.println(s1.isEmpty());

	}

}
