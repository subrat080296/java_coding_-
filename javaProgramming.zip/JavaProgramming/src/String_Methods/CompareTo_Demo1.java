package String_Methods;

public class CompareTo_Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="java";
		String s2="selenium";
		
		System.out.println(s.compareTo(s2));

	}

}
