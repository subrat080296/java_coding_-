package String_Methods;

public class Equals_Demo1 {

	public static void main(String[] args) {
		String s="hello";
		String s2="hello";
		
		if(s.equals(s2)) {
			System.out.println("true");
		}
		else {
			System.out.println("false");
		}
		

	}

}
