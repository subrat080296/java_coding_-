package String_Methods;

public class Split_Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="hellojava";
		
		System.out.println(s.length());
		
		String [] ar=s.split(" ");
		for(String s4:ar) 
		{	
		
		System.out.println(s4);
		
		System.out.println(s4.length());

	}

}
}