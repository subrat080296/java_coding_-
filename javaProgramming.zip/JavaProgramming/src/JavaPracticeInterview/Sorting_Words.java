package JavaPracticeInterview;

import java.util.Arrays;

public class Sorting_Words {
public static void main(String[] args) {

	String s[]= {"xcg","hbf","jkl","abc","hjd","knm"};

	{
            System.out.println("Before sorting"+ Arrays.toString(s));
            Arrays.sort(s);
            System.out.println("After sorting"+ Arrays.toString(s));
}

}
}
