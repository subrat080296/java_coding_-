package JavaPracticeInterview;

public class ConstructurePractice {

public ConstructurePractice(int a,int b)
			{
				System.out.println(a + b);
				System.out.println(a - b);
				System.out.println(a * b);
				System.out.println(a / b);
			}

public ConstructurePractice(int o,char k)
			{
		           System.out.println(o+""+k);
			}
public ConstructurePractice()
{
       System.out.println("no argumets");
}

public static void main(String[] args) {
ConstructurePractice s=new ConstructurePractice(90,80);
//ConstructurePractice s1=new ConstructurePractice(90,'A');
//ConstructurePractice s2=new ConstructurePractice();


}

}



