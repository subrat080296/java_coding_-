package JavaPracticeInterview;

public class StringBufferReverse {

	public StringBufferReverse(String name) {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		String name="Subrta";
		StringBufferReverse s=new StringBufferReverse(name);
		System.out.println(s.reverse());
	}

	private char[] reverse() {
		// TODO Auto-generated method stub
		return null;
	}

}
