package JavaPracticeInterview;

public class C extends B {
	public void divide(int a, int b) {
		int c=(a%b);

			System.out.println("divide of a and b ="+c);

	}


	public static void main(String[] args) {
		C v=new C();
		v.add(15,24);

	}

}
