package JavaPracticeInterview;

public class Duplicatein_Array {

	public static void main(String[] args) {
		int a[]= {12,27,26,78,90,27,87,27,35,27,36,27};
		int dublicate=27;
		int count=0;
		for (int x:a) {
			if(x==dublicate) {
				count++;
			}
		}
		System.out.println(count);

	}

}
