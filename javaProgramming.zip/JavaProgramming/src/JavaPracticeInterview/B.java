package JavaPracticeInterview;

public class B extends A{
	public void multiply(int a, int b) {
		int c=(a*b);

			System.out.println(" multiply of a and b ="+c);

	}
	public static void main(String[] args) {
		B v=new B();
		v.add(15,24);

	}
}
