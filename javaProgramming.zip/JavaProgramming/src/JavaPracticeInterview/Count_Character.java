package JavaPracticeInterview;

public class Count_Character {
public static void main (String[] args) {
	String s="Java is a Object Oriented Language";
	int count=0;
	for (int i=0;i<=s.length()-1;i++)
	{
	       count=s.length();
	      System.out.println(count);
	      break;
	}

}
}
