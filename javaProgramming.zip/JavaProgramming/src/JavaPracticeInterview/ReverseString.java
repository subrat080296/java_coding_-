package JavaPracticeInterview;

public class ReverseString {
public static void main (String[] args) {
	String name="Subrata";
	StringBuilder s=new StringBuilder(name);
	{

	System.out.println(s.reverse());

	}
}
}


