package JavaPracticeInterview;

public class Find_Duplicate_Array {

	public static void main(String[] args) {
		int a[]= {100,700,500,100,600,700,80,700};
		int dublicate=100;
		int count=0;
		for (int x:a)
		{
			if (x==dublicate)
			{
			count++;
			}
		}
				System.out.println(count);

		}


	}


