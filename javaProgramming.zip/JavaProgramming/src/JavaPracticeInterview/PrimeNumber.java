package JavaPracticeInterview;

public class PrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int number=9;

 for (int i=2;i<=number;i++)
 {
 if (number%i==0)

			 {
		 System.out.println(i+ "number is prime");
		// return;
			 }

		 }

			 }


	}


