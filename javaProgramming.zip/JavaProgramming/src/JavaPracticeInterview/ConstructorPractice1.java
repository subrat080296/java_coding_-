package JavaPracticeInterview;

public class ConstructorPractice1 {
public ConstructorPractice1(int a,int b)
{
	System.out.println(a+b);
}
public ConstructorPractice1() {
	System.out.println("no constructor");
}
	public static void main(String[] args) {
		ConstructorPractice1 c=new ConstructorPractice1();
		//System.out.println();
		// TODO Auto-generated method stub

	}

}
