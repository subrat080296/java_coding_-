package JavaPracticeInterview;

public class EcapsulationPractice {
	class A{
		private int value;//data hiding
		public void setValue(int x)//data abstraction
{
			value=x;
		}
		public int getvalue() {
			return value;
		}
	}
class B{

	public static void main(String[] args) {
		EcapsulationPractice r =new EcapsulationPractice();
		r.setValue(100);
		System.out.println(r.getvalue());
	}

	}
public char[] getvalue() {
	// TODO Auto-generated method stub
	return null;
}
public void setValue(int i) {
	// TODO Auto-generated method stub

}

}
