package JavaPracticeInterview;

public class Polymorphisim_MethodOverLoading {

	//Number of argument different(string and int arguments)
	void bark(String dog, int leg)
	{
		System.out.println("dog bark");
		System.out.println(dog);
		System.out.println(leg);
	}
	//type of argument different( int and string arguments)
	void bark(int leg, String hen)
	{
		System.out.println("hen bark");
	}
	//order of argument different(string and int arguments)
	void bark(String cow, int leg, String lanja)
	{
		System.out.println("Monky bark");
	}
	void bark()
	{
		System.out.println("Rabbit bark");
	}

	public static void main(String args[])
	{
		Polymorphisim_MethodOverLoading obj=new Polymorphisim_MethodOverLoading();
		//Polymorphisim_MethodOverLoading obj1=new Polymorphisim_MethodOverLoading();
		obj.bark("cow",4,"yes");
	}
}
