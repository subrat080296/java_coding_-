package JavaPracticeInterview;

public class A {
public void add(int a, int b) {
	int c=(a+b);

		System.out.println("addition od a and b ="+c);

}
}
