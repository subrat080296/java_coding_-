package JavaPracticeInterview;

public class Find_Duplicate {

	public static void main(String[] args) {
		int a[]= {31,56,23,31,76,31,87,78,31,76,31,31};
		int dublicate=31;
		int count=0;
		for(int x:a) {
			if(x==dublicate) {
				count++;
			}
		}
System.out.println(count);
	}

}
