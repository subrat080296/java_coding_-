package Exception_Handle_Demo;

import java.util.Scanner;

public class Exception_Handle_demo1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your input");
		int number=sc.nextInt();
		System.out.println(100/number);

	}

}
