package Day11;

public class P_Constructor {
	int x,y,z;
	P_Constructor(int a,int b,int c){
		x=a;
		y=b;
		z=c;		
	}
	void sum() {
		System.out.println(x+y+z);
	}
	

	public static void main(String[] args) {
		P_Constructor p=new P_Constructor(100,20,30);
		p.sum();

	}

}
