package Day11;

public class Default_Consutructor {
	int x,y;
	
	Default_Consutructor()
	{
		x=100;
		y=200;
		
	}
	void sum()
	{
		System.out.println(x+y);
	}
	


	public static void main(String[] args) {
		Default_Consutructor dc=new Default_Consutructor();
		dc.sum();
	}
	
}
