package Day11;

public class Metthod_Object {

	public static void main(String[] args) {
				//No Parameter but Returning Value
				
				String s="welcome";
				System.out.println(s.length());
				String sb=s.substring(2,5);
				System.out.println(sb);

			}

		}
