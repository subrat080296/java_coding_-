package Day11;

public class Student_Main {

	public static void main(String[] args) {
		//Student std1=new Student(); 
		//Using object reference variable
		/*
			std1.sid=101;
			std1.sname="Mohon";
			std1.grad='A';
			std1.printStudentdata();
			*/
		//Approach 2 Using Method
		//std1.setStudentdata(101, "Hulk", 'A');
	//	std1.printStudentdata();
	
	
		//}
	 //Using constructor
	Student std1=new Student(101,"raj",'A');
	std1.printStudentdata();
	}
}


	


