package Day11;

public class Default_cons_addFirstandLastName {
	String Fname;
	String Lname;
	
	Default_cons_addFirstandLastName(String FirstName,String LastName)
	{
		Fname=FirstName;
		Lname=LastName;
	}
	void printaddFirstandLastName() {
		System.out.println(Fname+" "+Lname);
	}

	public static void main(String[] args) {
		Default_cons_addFirstandLastName FN=new Default_cons_addFirstandLastName("Harish","Chandra");
		FN.printaddFirstandLastName();

	}

}
