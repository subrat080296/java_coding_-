package Day11;

public class Constructor_Practice {

	
		int salary;
		int age;
		int number;
		String jhname;
		boolean b;
		double d;
	   char graded;
	   void printConstructor_Practice()
	   {
		   System.out.println(salary+" " +age+" " +number+" "+jhname+" "+ b+" "+ d+" "+graded);
	   }
	   Constructor_Practice(int sal,int ag,int num,String name,boolean btrue,double dsal,char gr)
	   {
		   sal=salary;
		   ag=age;
		   num=number;
		   name=jhname;
		   btrue=b;
		   dsal=d;
		   gr=graded;
	   }


              public static void main(String[] args)
{
	Constructor_Practice cp=new Constructor_Practice(1010,23,8826920,"Kohit",true,10.5,'C');
	cp.printConstructor_Practice();

}
}
