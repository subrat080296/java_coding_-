package Day11;

public class Def_Const 
{
	
	static int age1;
	static String naming;
	
	
	Def_Const(int age1,String naming)
	{
		age1=18;
		naming="Rahuld";	
	}
	void printDef_Const() 
	{
		System.out.println(age1+ " "+naming);
	}

	public static void main(String[] args)
	{
		
		Def_Const dc1=new Def_Const(age1,naming);
		dc1.printDef_Const();
	}
}
			
		

