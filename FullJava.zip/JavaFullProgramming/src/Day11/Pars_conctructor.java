package Day11;

public class Pars_conctructor {
	String nam;
	int age;
	char c;
	
	Pars_conctructor(String uname,int ag,char grade)
	{
		nam=uname;
		age=ag;
		c=grade;	
	}
	void printPars_conctructor() {
		System.out.println(nam+" "+age+" "+c);
	}
	public static void main(String[] args) {
		Pars_conctructor p1=new Pars_conctructor("Virat",18,'D');
		
		p1.printPars_conctructor();

	}

}
