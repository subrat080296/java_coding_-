package Day11;

public class Paramaterise_Constructor {
	int x,y;
	
	Paramaterise_Constructor(int a,int b)
	{
		x=a;
		y=b;
		
	}
	void sum()
	{
		System.out.println(x+y);
	}

	public static void main(String[] args) {
		Paramaterise_Constructor cd1=new Paramaterise_Constructor(10,30);
		cd1.sum();

	}

}
