package Day11;

public class Student {
	int sid;
	String sname;
	char grad;
	
	void printStudentdata() 
	{
		System.out.println(sid +"  "+sname+"  "+grad);
	}
	//another approach 
	void setStudentdata(int id,String name,char gr)
	{
		sid=id;
		sname=name;
		grad=gr;
	}
   //Using Constructor
	
	Student(int id,String name,char gr)
	{
		sid=id;
		sname=name;
		grad=gr;
	}
}
