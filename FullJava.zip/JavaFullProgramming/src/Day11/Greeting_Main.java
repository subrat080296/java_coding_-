package Day11;

public class Greeting_Main {

	public static void main(String[] args) {
		//Create object to access greeting clss
		Greeting gr=new Greeting();
	
		gr.m1();
     String str= gr.m2();//for returning an value so we need store in an object and print that object
     System.out.println(str);
       
     
     gr.m3("Ram");
      String s=  gr.m4("Krushna");
     System.out.println(s);
     
     
	}

}
