package Day11;

public class D_constructor {
	int x,y;
	D_constructor(){
		x=200;
		y=300;
	}
	void sum()
	{
		System.out.println(x+y);
	}

	public static void main(String[] args) {
		D_constructor d= new D_constructor();
		d.sum();

	}

}
