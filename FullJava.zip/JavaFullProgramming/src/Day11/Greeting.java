package Day11;

public class Greeting {
//No parameter no return value
	void m1()//void represent no any return value
	{
		System.out.println("hello....");
	}
	//No parameter but Return value
	String m2()
	{
		
		return("hello how are you");
	}
		//Takes parameter but no returns value
	void m3(String name1)
	{
		System.out.println("Hello"+ name1 );
	}
	
	//Takes parameter and returns the value
	String m4(String name)
	{
		return("Hello"+name);
	}
	
	
	
}
