package Day18;

public class ExceptionHandling_ex3 {

	public static void main(String[] args) {
		// null point exception
		
		String s=null;
		System.out.println(s.length());
		

	}

}
