package Day18;
import java.util.Scanner;

public class ExceptionHandling_ex2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s="18928";//If we will add "welcome" letter in this filed its showing number formatException error
	int num=(Integer.parseInt(s));
	System.out.println(num);
		
		
	}

}
