package Day18;
import java.util.Scanner;

public class Exception_Handling {

	public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter a number");
	int num=sc.nextInt();
	System.out.println(100/num);
	
	
	System.out.println("Program is executed succesfully");
	System.out.println("close the the cxecution");

	}

}
