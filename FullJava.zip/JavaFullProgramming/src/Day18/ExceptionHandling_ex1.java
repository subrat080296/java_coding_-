package Day18;
import java.util.Scanner;

public class ExceptionHandling_ex1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a[]=new int[5];
		System.out.println("enter the position(0-4)");
		int pos=sc.nextInt();
		System.out.println("enter a value");
		int value=sc.nextInt();
		a[pos]=value;
		System.out.println(a[pos]);


	}

}
