package Day18;

public class Try_Catch_eg3 {

	public static void main(String[] args) {
		String s=null;
			
		try
		{
			System.out.println(s.length());
		}
		catch(NullPointerException r)
		{
			System.out.println("Invalid");
		}
		System.out.println("Done");

	}

}
