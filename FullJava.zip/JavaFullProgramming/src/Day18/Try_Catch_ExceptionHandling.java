package Day18;
import java.util.Scanner;
public class Try_Catch_ExceptionHandling {

	public static void main(String[] args) {
		// Exception handling using try and catch statement
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number");
		int num=sc.nextInt();
		try
		{
			System.out.println(100/num);
			
		}
		
		catch(ArithmeticException a) 
		{
			System.out.println("invalid input");
		}
		System.out.println("Program is executed ");
		


	}

}
