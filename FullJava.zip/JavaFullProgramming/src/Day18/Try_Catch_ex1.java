package Day18;
import java.util.Scanner;
public class Try_Catch_ex1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your input");
		String s=sc.nextLine();
		try
		{
			System.out.println(s);	
		}
		catch(NullPointerException n)
		{
			System.out.println("Invalid input");
		}
		System.out.println("Completed");
	}
}


