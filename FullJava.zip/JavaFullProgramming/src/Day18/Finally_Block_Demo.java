package Day18;

public class Finally_Block_Demo {

	public static void main(String[] args) {
		String s="null";
		try {
			System.out.println(s.length());
		}
		catch(Exception e) {
			System.out.println("Catch Handled exception") ;
			System.out.println("done");
			
		}
		finally {
			System.out.println("you are enetered in to final blcok");
			
		}
		System.out.println("program is finished");

	}

}
