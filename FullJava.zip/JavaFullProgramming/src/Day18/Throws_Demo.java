package Day18;

public class Throws_Demo {

	public static void main(String[] args) throws InterruptedException {
		String s="null";
		Thread.sleep(500) ;
		
			System.out.println(s.length());

			System.out.println("Catch Handled exception") ;
			System.out.println("done");
			
		
		System.out.println("program is finished");

	
		

	}
}