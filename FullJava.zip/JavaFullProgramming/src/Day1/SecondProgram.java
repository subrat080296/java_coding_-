package Day1;

public class SecondProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome");
		System.out.println("to java");

	}

}
