package Day1;


public class DataTypes_demo {
	public void method1() {
		int j=90;
	}
	public void m2() {
		String s="hello";
	}
	public void m3() {
		Character ch='A';
	}
	public void m4() {
		boolean b=true;
		System.out.println(b);
	}
	public void m5() {
		double d=10.5;
		System.out.println(d);
	}
	public void m6() {
		float f=10f;
		System.out.println(f);
	}
	
	public static void main(String[] args) {
		
		DataTypes_demo data=new DataTypes_demo();
	//	System.out.println(data.method1());
		data.m5();
		data.m6();
		data.m4();
		

	}

}
