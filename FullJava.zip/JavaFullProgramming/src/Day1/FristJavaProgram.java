package Day1;

public class FristJavaProgram {

	public static void main(String[] args) {
		System.out.println("out put is" +"Started Practice Java");
		System.out.println(10+20);
	}

}
