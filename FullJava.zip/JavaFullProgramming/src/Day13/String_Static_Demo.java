package Day13;

public class String_Static_Demo 
{


		static String s="hello java how are you";
	

}
