package Day13;

public class SetData_Demo {
	int x;
	int y;
	
	void setData(int x, int y)
	{
	this.x=x;
	this.y=y;
		
	}
	void display() {
		System.out.println(x);
		System.out.println(y);
	}
	

	public static void main(String[] args) {
		SetData_Demo sd= new SetData_Demo();
		sd.setData(12,87);
		sd.display();

	}

}
