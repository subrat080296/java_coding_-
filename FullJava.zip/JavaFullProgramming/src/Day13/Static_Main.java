package Day13;

public class Static_Main {

	public static void main(String[] args) {
		System.out.println(Static_Keyword_Practice.rollno);
		Static_Keyword_Practice.m1();

	}

}
