package Day13;

public class Static_Keyword_Practice {
	static String s="hony";//Static variable
	int age=20;//non static
	static int rollno=12; //Static variable
	static void m1() {
		System.out.println("Static value");
	}
	void m2() {
		System.out.println("Non static value");
	}

	

}
