package Day13;

public class Static_Demo {
	static int a=20;
	int b=30;
	static void m1() {
		System.out.println("this an static value.......");
	}
	void m2() {
		
		System.out.println("This a non static value");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(a);
		m1();
		Static_Demo sd=new Static_Demo();
		System.out.println(sd.b);
		sd.m2();
		

	}

}
