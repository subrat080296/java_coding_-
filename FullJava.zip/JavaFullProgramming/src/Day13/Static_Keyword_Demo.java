package Day13;

public class Static_Keyword_Demo {

	
	 static int a=10;
	 int b=30;
	 
	 static void m1()
	 {
		 System.out.println("This is static menthod");
	 }

	
	void m2() 
	{
		System.out.println("This is Non- static menthod");
	}
	public static void main(String[] args) {
		
		System.out.println(a);
		m1();
		
	}

}
