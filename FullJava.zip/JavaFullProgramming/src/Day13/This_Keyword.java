package Day13;

public class This_Keyword {
	int x,y;//This is class variable
	
	This_Keyword(int x, int y)//this is local variable
	{
		this.x=x;
		this.y=y;	
	}
	void display()
	{
		System.out.println(x);
		System.out.println(y);
	}
	
	
	public static void main(String[] args) 
	{
		
		This_Keyword tk=new This_Keyword(200,100);
		
		
		tk.display();
	
	}

}
