package Day13;

public class Static_Practice {
	static String s="welcome"
;
	/*public static void main(String[] args) {
		System.out.println(s);
		System.out.println("Length is : " + s.length());

	}
*/
}
