package Day13;

public class ThisKeyword {
	int x,y;
	void setdata(int a, int b) 
	{
		x=a;y=b;
	}
	void getdata()
	{
		System.out.println(x);
		System.out.println(y);
	}
	

	public static void main(String[] args) 
	{
		ThisKeyword th=new ThisKeyword();
		th.setdata(10,200);
		th.getdata();
		
		

	}

}
