package Day13;

public class Main_Static {

	public static void main(String[] args) {
		System.out.println(Static_Practice.s);
		System.out.println(Static_Practice.s.length());

	}

}
