package Day13;

public class Main_Class_of_String {

	public static void main(String[] args) {
		System.out.println(String_Static_Demo.s.length());

	}

}
