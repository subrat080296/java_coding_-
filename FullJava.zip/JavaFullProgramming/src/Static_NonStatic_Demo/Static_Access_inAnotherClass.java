package Static_NonStatic_Demo;

public class Static_Access_inAnotherClass {
	
	public static void m7() {
		String name="chanchal";
		int age=23;
		boolean b=true;
		char c='A';
	//System.out.println(name+ age+ b+c);
	}

}
