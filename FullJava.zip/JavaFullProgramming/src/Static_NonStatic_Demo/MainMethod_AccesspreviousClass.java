package Static_NonStatic_Demo;

public class MainMethod_AccesspreviousClass {

	public static void main(String[] args) 
	
	{
		Static_Access_inAnotherClass.m7();

	}

}
