package Static_NonStatic_Demo;

public class Static_Variable_demo {
	
		static String name="Rohon";

	public static void main(String[] args) {
		System.out.println(name);

	}

}
