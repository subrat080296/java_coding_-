package Static_NonStatic_Demo;

public class Static_Method_demo {
	
	public static void m2() {
		System.out.println("HOW Q");
	}

	public static void main(String[] args) {
		m2();

	}

}
