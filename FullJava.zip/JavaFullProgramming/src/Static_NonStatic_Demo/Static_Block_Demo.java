package Static_NonStatic_Demo;

public class Static_Block_Demo {
	
	static {
		System.out.println("Static block no need to do anything just print");
	}

	public static void main(String[] args) {
		System.out.println();

	}

}
