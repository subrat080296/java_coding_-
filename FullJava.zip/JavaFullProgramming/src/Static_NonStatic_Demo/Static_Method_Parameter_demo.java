package Static_NonStatic_Demo;

public class Static_Method_Parameter_demo {
	
	public static void m5(String name, int age) {
		System.out.println(name+age);
	}

	public static void main(String[] args) {
	          m5("raj", 13);//  pass the parameter what ever declare in methods like string and integer

	}

}
