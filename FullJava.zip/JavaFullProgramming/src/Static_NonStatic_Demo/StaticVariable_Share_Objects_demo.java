package Static_NonStatic_Demo;


public class StaticVariable_Share_Objects_demo {
	static String Name="rihs";
	String name;

	public static void main(String[] args) {
		
		StaticVariable_Share_Objects_demo d=new StaticVariable_Share_Objects_demo();
		StaticVariable_Share_Objects_demo d1=new StaticVariable_Share_Objects_demo();
		d.name="rohul study";
		d1.name="rohon study";
		
		System.out.println(d.Name);
		System.out.println(d1.Name);

	}

}
