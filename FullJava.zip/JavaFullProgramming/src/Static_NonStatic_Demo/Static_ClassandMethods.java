package Static_NonStatic_Demo;

public class Static_ClassandMethods {
	
	public static void m1() {
		System.out.print("static cls and method");
	}

	public static void main(String[] args) {
		Static_ClassandMethods.m1();
		

	}

}
