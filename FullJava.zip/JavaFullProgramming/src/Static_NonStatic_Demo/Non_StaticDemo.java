package Static_NonStatic_Demo;

public class Non_StaticDemo {
	public void m6() 
	{
		System.out.println("non static need create an object of the class and call to the method");
	}

	public static void main(String[] args) {
		Non_StaticDemo n=new Non_StaticDemo();
		n.m6();
		

	}

}
