package Day10_OOPS;

public class Polymorphism_Demo {
	int x=10;
	int y=20;
	void m1() {
		System.out.println(x+y);
	}
	void m1(int x,int y) 
	{
		System.out.println(x+y);
	}
	void m1(int x,String y) {
		System.out.println(x+y);
	}
	void m1(int x, double y) {
		System.out.println(x+y);
	}
	void m1(int a,int b, int c ) {
		System.out.println(a+b+c);
	}

	public static void main(String[] args) {
		Polymorphism_Demo d1=new Polymorphism_Demo();
		d1.m1(19,"ram");
		d1.m1(10,20,30);
		d1.m1(10,5.6);

	}

}
