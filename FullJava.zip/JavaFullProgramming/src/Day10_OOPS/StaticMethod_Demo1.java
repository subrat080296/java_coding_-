package Day10_OOPS;

public class StaticMethod_Demo1 { 
  static void m1()// Static methods
 {
	 System.out.println("hello");
 }
	public static void main(String[] args) {
		m1();

	}

}
