package Day10_OOPS;

public class Variables_demo {
	
	int studentid;
	int age;
	char grad;
    String name;
    
    void print_StudentData() 
    {
    	System.out.println(studentid+" "+age+ " "+grad+" "+name);
    }
    
    void setStudentdata(int sid ,int age,char grd , String name) {
    	this.studentid=sid;
    	this.age=age;
    	this.grad=grd;
    	this. name=name;
    	
    }
    
    
    //Using constructor
    Variables_demo(int sid ,int age,char grd , String name){
    	this.studentid=sid;
    	this.age=age;
    	this.grad=grd;
    	this. name=name;
    }
  
    	
    

}
