package Day10_OOPS;

public class Class_Demo_Mainclass {

	public static void main(String[] args) {
		Class_Demo cd=new Class_Demo() ;
		cd.age=18;
		cd.name="rohon";
		cd.amount=54;
		cd.display();
			
		}

	}


