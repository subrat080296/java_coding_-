package Day10_OOPS;
class Teacher1{
	private String Tname;
		private int Tage;
	public void setName(String name)	{
		this.Tname=name;	
	}
	public void setAge(int age) {
		this.Tage=age;
	}
	public String getName() {
		return Tname;
	}
	public int getAge() {
		return Tage;
	}
}
public class Encapsulation_Demo_1 {

	public static void main(String[] args) {
		Teacher1 t=new Teacher1();
		t.setName("Rohit");
		t.setAge(28);
		System.out.println(t.getName());
		System.out.println(t.getAge());

	}

}
