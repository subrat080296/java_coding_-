package Day10_OOPS;

class Bus{
	void forest_kingson() 
	{
	System.out.println("Tiger");
}
}

class minu_bus extends Bus{
	void Forestking() {
	System.out.println("king of jungle");
}
}

class bus_bus extends minu_bus{
	
	void bus_t() {
		System.out.println("trvl");
	}
}
public class Inheritance_Single_1 {

	public static void main(String[] args) {
//		minu_bus c=new minu_bus();
//		c.forest_kingson();
//		c.Forestking();
		
		bus_bus b=new bus_bus();
	b.forest_kingson();
	b.Forestking();
	b.bus_t();

	}
}
