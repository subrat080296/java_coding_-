package Day10_OOPS;

public class Constructor_Overloading_1 {
	int a,b,c;
	Constructor_Overloading_1(){
		System.out.println(a+b+c);
	}
	Constructor_Overloading_1(int a,int b,int c ){
		System.out.println(a+b+c);
		
	}
	Constructor_Overloading_1(String name, int age){
		System.out.println(name +" "+age);
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Constructor_Overloading_1 cd=new Constructor_Overloading_1();
		Constructor_Overloading_1 cd1=new Constructor_Overloading_1(10,20,30);
		Constructor_Overloading_1 cd2=new Constructor_Overloading_1("Ram",30);

	}

}
