package Day10_OOPS;

public class Main_Method_Valiables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		Variables_demo vd=new Variables_demo();
//		vd.studentid=100;
//		vd.age=23;
//		vd.grad='A';
//		vd.name="kalia";
//		
//		vd.print_StudentData();
//		
//		vd.setStudentdata(101,20,'V',"smit");
//		vd.print_StudentData();
//		
		
		Variables_demo vd=new Variables_demo(100,23,'G',"Sja");
		vd.print_StudentData();
		
		
	}

}
