package Day10_OOPS;

public class SISO_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(args.length);
		
		for(String s:args) {
			System.out.println(s);
		}

	}

}
