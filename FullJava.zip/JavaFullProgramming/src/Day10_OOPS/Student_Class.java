package Day10_OOPS;

public class Student_Class {

int sid;
String sname;
int grad;
void printdata()
{
	System.out.println(sid+" "+sname+" "+grad);
}

	

}
