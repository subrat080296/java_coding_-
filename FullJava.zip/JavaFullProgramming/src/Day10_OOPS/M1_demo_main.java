package Day10_OOPS;

public class M1_demo_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		M1_Demo ob=new M1_Demo();
		ob.m1();
		String variable=ob.m2();
		
		System.out.println(variable);
		ob.m3("raj");
		
		String st=ob.m4("jhon", 20);
		System.out.println(st);

	}

}
