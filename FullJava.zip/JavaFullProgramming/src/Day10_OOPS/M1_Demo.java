package Day10_OOPS;

public class M1_Demo {
  //no parameter no returns value
	
	 void m1()
	 {
		System.out.println("hello");
	}
	 
	 //no parameter return value
	 
	 String m2() {
		 return ("how are you ");
		 
	 }
	 
	 //takes parameter no return value
	 
	     void m3(String name) {
	    	  System.out.println("hello"+" "+ name);
		 
	 }
	     
	     //Takes parameter n returns valu
	     
	   String  m4(String name, int age){
		   return ("name"+" "+ age);
	    	 
	     }
}
