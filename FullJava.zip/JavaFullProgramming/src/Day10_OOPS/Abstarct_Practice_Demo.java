package Day10_OOPS;

abstract class Jungle{
	

	abstract void forest() ;
	
		void tree() {
		System.out.println("Mango Tree");
	}
}
	
class Tree extends Jungle{
	 void T()
	{
		System.out.println("Apple tree");
	}
	 void forest() {
		 System.out.println("Tree is full in jungle");
	 }
}
public class Abstarct_Practice_Demo {
	public static void main(String[] args) {
		Jungle j=new Tree();
		j.forest();
		j.tree();

	}
}


