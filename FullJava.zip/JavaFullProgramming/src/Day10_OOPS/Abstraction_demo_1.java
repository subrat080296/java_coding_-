package Day10_OOPS;

abstract class Vehicle {
    abstract void run();
}

class Car1 extends Vehicle {
    void run() {
        System.out.println("Car is running");
    }
}
public class Abstraction_demo_1 {

	public static void main(String[] args) {
        Vehicle v = new Car1();  // abstraction + polymorphism
        v.run();
	}

}
