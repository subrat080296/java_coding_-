package Day10_OOPS;

public class Student_mainclass {

	public static void main(String[] args) {
	Student_Class s1=new Student_Class();
	s1.sid=123;
	s1.sname="jhon";
	s1.grad='A';
	s1.printdata();

	}

}
