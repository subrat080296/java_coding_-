package Day10_OOPS;

public class Class_Demo12 {
	
//variables
		int age;
		int money;
		String name;
		
	//method
    void display() {
	System.out.println(age);
	System.out.println(money);
	System.out.print(name);
}
	
	//main method
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Class_Demo12 d=new Class_Demo12();
		d.age=19;
		d.money=200;
		d.name="debabrat";
		d.display();

	}

}
