package Day10_OOPS;

public class Class_Demo {
	 int age;
	 String name;
	 int amount;
	 
	 void display(){
		 System.out.println(age+" "+ name+" "+amount);
		 
	 }
	 

}
