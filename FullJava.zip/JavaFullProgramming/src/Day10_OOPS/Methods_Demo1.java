package Day10_OOPS;

public class Methods_Demo1
{
public void demo(String s ,int a)
{
	System.out.println(s+a);
}
	public static void main(String[] args) {
		Methods_Demo1 d=new Methods_Demo1();
		
		d.demo("subrata", 10);
             


	}

}
