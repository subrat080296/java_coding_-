package Day10_OOPS;
class Student{
	public void Name() {
		System.out.println("Student name is Ramchndra");
	}
}
class Teacher extends Student{
	public void Name() {
		System.out.println("Krusha sir");
	}
}
public class Polymorpism_demo {

	public static void main(String[] args) {
	Student s=new Student();
	s.Name();
	Teacher t=new Teacher();
	t.Name();

	}

}
