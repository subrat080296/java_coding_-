package Day10_OOPS;

public class Main_Method_Overloaded {
	void main(int x) {
		System.out.println(x);
	}
	void main(int x , int y) {
		System.out.println(x);
	}
	void main(String s, int x) {
		System.out.println(x);
	}
	void main(String s ,double d, int x) {
		System.out.println(x);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Main_Method_Overloaded md=new Main_Method_Overloaded();
		md.main("ram", 59);

	}

}
