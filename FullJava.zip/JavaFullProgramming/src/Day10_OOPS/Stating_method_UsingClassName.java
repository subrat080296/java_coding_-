package Day10_OOPS;


public class Stating_method_UsingClassName {
	
	static void m2() {
		System.out.println("how are you ?");
	}
	


	public static void main(String[] args) {
		Stating_method_UsingClassName.m2();

	}

}
