package Day10_OOPS;

public class Method_Practice_1 {
	//No parameter no returns value
	void m1(){
		System.out.println("hello");
	}
	//no parameter return value
	String m4(){
		return("Hi java");
	}
	//Takes parameter  No return value
	String m5(String name)
	{
		return("name");
		
	}
	
	//Takes parameter and return value
	
String	m6(String s,int a){
		return(s +" "+a);
	}

	public static void main(String[] args) {
		
		Method_Practice_1 mp=new Method_Practice_1();
		mp.m1();
		String s=mp.m4();
		System.out.println(s);
		String s0=mp.m5("name");
 	System.out.println(s0);
 	String s9=mp.m6("Rohit", 67);
 	System.out.println(s9);
		
	}

}
