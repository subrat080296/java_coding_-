package Day10_OOPS;

public class OOOPs_Demo {

	public static void main(String[] args) {
		System.out.println("A class Main Method");

	}

}
class a{
	public static void main(String[] args) {
		System.out.println("A class Main Method");
	}
}
class B{
	public static void main(String[] args) {
		System.out.println("B class Main Method");
	}
}
		class C{
			public static void main(String[] args) {
				System.out.println("C class Main Method");
				
			}
		}