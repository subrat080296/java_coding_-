package Day10_OOPS;

public class OOPS_Class {
	//VARIABLE  just created variable not assign in any data
	int eid;
	String ename;
	int sal;
	String job;
	
	//Method 1  
	void display()//void is nothing but not return value and Display is method
	{
		System.out.println(eid);
		System.out.println(ename);
		System.out.println(sal);
		System.out.println(job);
	}
	

	/*public static void main(String[] args) {
		OOPS_Class emp1=new OOPS_Class();// create object for employee
		emp1.eid=101;
		emp1.ename="hori";
		emp1.job="private";
		emp1.sal=10000;
		System.out.println("Diplay emp1 data");
		emp1.display();
		
		OOPS_Class emp2=new OOPS_Class();
		emp2.eid=102;
		emp2.ename="Ram";
		emp2.job="Manager";
		emp2.sal=12000;
		System.out.println("Diplay emp2 data");
		System.out.println(emp2.eid);
		emp2.display();
		
		

	}
*/

}

