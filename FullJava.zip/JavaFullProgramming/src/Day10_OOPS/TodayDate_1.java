package Day10_OOPS;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
public class TodayDate_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(LocalDate.now());
		
		System.out.println(LocalTime.now());
		
		System.out.println(LocalDateTime.now());

	}

}
