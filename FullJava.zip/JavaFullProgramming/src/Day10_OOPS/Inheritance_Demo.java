package Day10_OOPS;
class Animal{
	public void dog() {
		System.out.println("dog is running");
	}
}
	class Tiger extends Animal{
		public void Tiger1() {
			System.out.println("tiger is king");
		}
		
		
	}
	class Lion extends Animal{
		public void Lion1() {
			System.out.println("Lion is don");
		}
	}


public class Inheritance_Demo {

	public static void main(String[] args) {
		Animal a=new Animal();
		a.dog();
		
		Tiger t=new Tiger();
		t.Tiger1();
		t.dog();
		
		Lion l=new Lion();
		l.dog();
		l.Lion1();
		

	
	}
}
