package Day10_OOPS;

public class Constructor_demo3 {
	
	int x;
	int y;
	String name;
	int age;
	
	Constructor_demo3(){
		x=5;
		y=10;
	}
	Constructor_demo3(String s,int b){
		
		this.name=s;
		this.age=b;
	}
	void display() 
	{
		System.out.println(name+""+ age);
	}
	void desplay() 
	{
		System.out.println(x+y);
	}

	public static void main(String[] args) 
	{
		Constructor_demo3 dm=new Constructor_demo3();
		
		dm.desplay();
		
		Constructor_demo3 dm1=new Constructor_demo3("sai", 19);
		dm1.display();

	}

}
