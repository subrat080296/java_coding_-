package Day14;

class G{
	int x=20;
	void show() {
		System.out.println(x);
	}
}

class B extends G{
	int y=90;
	void display() {
		System.out.println(y);
	}
}


public class Singlee_Inheritance {

	public static void main(String[] args) {
		B ob=new B();
		ob.display();
		ob.show();


	}

}
