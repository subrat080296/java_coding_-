package Day14;

class s{
	int d=20;
	void display()
	{
		System.out.println(d);
	}
	public void show() {
		// TODO Auto-generated method stub

	}
	public void print() {
		// TODO Auto-generated method stub

	}
}
class m extends s{
	int e=10;
	@Override
	public void show() {
		System.out.println(e);
	}

}
class n extends s{
	int f=30;
	@Override
	public void print() {
		System.out.println(f);
	}
}

public class Hirarchy_Inheritance {

	public static void main(String[] args) {
		m obm=new m();
		n obn=new n();
		obn.print();
		obm.show();



	}

}
