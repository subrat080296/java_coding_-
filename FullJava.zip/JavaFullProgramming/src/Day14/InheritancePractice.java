package Day14;
class j{
	int s=100;
	void display() {
		System.out.println(s);
	}
}
class t extends j{
	int i=200;
		void show() {
		System.out.println(i);
	}
}
public class InheritancePractice {
	public static void main (String[] args) {

		t jt=new t();
		jt.display();
		jt.show();
		System.out.println(jt.s);
		System.out.println(jt.i);

	}

}
