package Day14;

class x{
	int a=10;
	void show()
	{
		System.out.println(a);
	}

}
class y extends x{
	int b=20;
	void display()
	{
		System.out.println(b);
	}

}
class z extends y{
	int c=30;
	void print()
			{
		System.out.println(c);
	}

}

public class MultiLevel_INH {

	public static void main(String[] args) {
		z obj=new z();
		obj.display();
		obj.print();
		obj.show();
	//	System.out.println(obj.c);
	//	System.out.println(obj.a);
	//	System.out.println(obj.a);

	}

}
