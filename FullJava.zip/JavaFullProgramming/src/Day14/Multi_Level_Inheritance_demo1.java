package Day14;

class d{
 String name="Ram";
 int age=18;
 int study=8;
 
 void display() {
	 System.out.println(name);
	 System.out.println(age);
	 System.out.println(study);
 }
	
}
class e extends d{
	String bname="rohit";
	int age=19;
	int study=9;
	void show() {
		System.out.println(bname);
		System.out.println(age);
		System.out.println(study);
	}
}

class f extends e{
	int age=20;
	String name="fakira";
	int study=10;
	
	void returns() {
		System.out.println(age);
		System.out.println(name);
		System.out.println(study);
	}
}

public class Multi_Level_Inheritance_demo1 {

	public static void main(String[] args) {
		f f1=new f();
		f1.returns();
		f1.show();
		f1.display();

	}

}
