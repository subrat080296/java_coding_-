package Day14;

public class Passingparameterinto_Mainmethod {

	public static void main(String[] args) {

		//System.out.println("Testing....");
		System.out.println(args.length);//Right click=>Run as=>Run configuration=>arguments=>Pass the value
		for (String value:args)
		{
			System.out.println(value);
		}

	}

}
