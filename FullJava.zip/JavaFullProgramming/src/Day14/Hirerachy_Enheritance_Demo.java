package Day14;

class w{
	int p=60;
	void display() {
		System.out.println(p);
	}
}
class g extends w{
	int c1=40;
	void display1() {
		System.out.println(c1);
	}
}

class h extends w{
	int c2=30;
	void display2() {
		System.out.println(c2);
	}
}

public class Hirerachy_Enheritance_Demo {

	public static void main(String[] args) {
		h obj1=new h();
		obj1.display();
		
		g g1=new g();
		g1.display1();

	}

}
