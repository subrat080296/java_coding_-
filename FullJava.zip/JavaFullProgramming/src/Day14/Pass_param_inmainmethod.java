package Day14;

public class Pass_param_inmainmethod {

	public static void main(String[] args) {
		System.out.println(args.length);
  for (String s: args) {
	  System.out.println(s);
  }
	}

}
