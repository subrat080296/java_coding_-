package Day14;

class Car{
	int price_car=6000;
	String modelname="thar";
	
	void show() 
	{
		System.out.println(price_car);		
		System.out.println(modelname);
	}
	
}

class car1 extends Car {
	
	
		int suzki_price=80000;
		String carname="suv";
	
	void display() 
	{
		System.out.println(suzki_price);
		System.out.println(carname);
	}
	
}

public class Single_Inheritance_demo1 {

	public static void main(String[] args) {
		car1 c1=new car1();
		c1.show();
		c1.display();

	}

}
