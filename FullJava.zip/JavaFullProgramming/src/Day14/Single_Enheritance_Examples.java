package Day14;


class A1{

	int a=40;
	String s="hello";
	Double d=10.5;
	float f= 10.5f;
	long l=345678;
	boolean b=true;

	void show(){
		System.out.println(a);
		System.out.println(s);
		System.out.println(d);
		System.out.println(f);
		System.out.println(l);
		System.out.println(b);
	}

}

class B1 extends A1{
	int age=90;

	void display() {
		System.out.println(age);
	}

}

public class Single_Enheritance_Examples {

	public static void main(String[] args) {
		B1 ob=new B1();
		ob.show();
		ob.display();

	}

}
