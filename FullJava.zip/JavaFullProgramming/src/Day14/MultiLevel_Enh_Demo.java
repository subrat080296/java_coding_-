package Day14;

class T{
int s=20;
 void M()
 {
	 System.out.println(s);
 }
 }
 class U extends T{
	 int N=90;
	 void m2() {
		 System.out.println(N);
	 }
 }
	 class V extends U{

		 int O=25;

		 void m3()
		 {
			 System.out.println(O);
		 }

	 }


public class MultiLevel_Enh_Demo {

	public static void main(String[] args) {
		V object=new V();
		object.M();
		object.m2();
		object.m3();
	}
}


