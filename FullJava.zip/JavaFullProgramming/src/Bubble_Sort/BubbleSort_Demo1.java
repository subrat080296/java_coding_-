package Bubble_Sort;

import java.util.Arrays;

public class BubbleSort_Demo1 {

	public static void main(String[] args) {
	int b[]= {2,7,8,4,3,1,9};
	for (int i=0;i<b.length-1;i++) {
		for (int j=0;j<b.length-1;j++) {
			if (b[j]>b[j+1]) {
				int temp=b[j];
				b[j]=b[j+1];
				b[j+1]=temp;
				
						
			}
			 
		}
	}
	      System.out.println(Arrays.toString(b));
	    

	}

}
