package Bubble_Sort;

import java.util.Arrays;

public class Bubble_Sort_Demo {

	public static void main(String[] args) {
	int a[]= {2,97,2,3,4,5,7,3,9};
	
	System.out.println("before sorting:"+ Arrays.toString(a));
	//int n=a.length;
	for (int i=0;i<a.length-1;i++) 
	{
		for(int j=0;j<a.length-1;j++)
		{
			if(a[j]>a[j+1]) {
				int temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
				
			}
			}
		}
		System.out.print(Arrays.toString(a));
	}
	}

