package Day4;

public class Check_Number_positive_negative_zero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//check number is positive negative or zero
		int n=-10;
		if(n>0 ) {
			System.out.println("number is positive");
		}
		else if(n<0) {
			System.out.println("number is negative");
		}
		else {
			System.out.println("number id zero");
		}

	}

}
