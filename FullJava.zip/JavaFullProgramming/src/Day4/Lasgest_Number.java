package Day4;

public class Lasgest_Number {

	public static void main(String[] args) {
		 int a=23,b=89,c=400;
		 
		 if(a>b && a>c) {
			 System.out.println("a is largest");
		 }
		 else if(b>c && b>a) {
			 System.out.println("b is largest");
		 }
		 else {
			 System.out.println("c is largest");
		 }

	}

}
