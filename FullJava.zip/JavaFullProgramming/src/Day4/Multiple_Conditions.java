package Day4;

public class Multiple_Conditions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 if(true)
 {
	 if(true) 
	 {
		 System.out.println("abc");
		 
	 }
	 else
	 {
		 System.out.println("xyz");
	 }
 }
	 
 else {
	 System.out.println("123");
 }
	}
}

