package Day4;

public class NestedIf_Else {

	public static void main(String[] args) {
		int age=22;
		boolean license=false;
		
		if(age>=18) {
			if(license) {
				System.out.println("He can drive");
			}
			else {
				System.out.println("He can't drive be don't have license");
			    }
			}
		else {
			System.out.println("he cant drive bec..he is beloew 18");
		}
		

	}

}
