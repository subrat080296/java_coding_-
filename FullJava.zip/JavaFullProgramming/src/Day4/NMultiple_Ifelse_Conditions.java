package Day4;

public class NMultiple_Ifelse_Conditions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int weekno=10;
		
		if (weekno==1) {
			System.out.println("Sunday");
		}
		else if(weekno==2) {
			System.out.println("monday");
		}
		else if(weekno==3) {
			System.out.println("Tuesday");
		}
		else if(weekno==4) {
			System.out.println("wednesday");
		}
		else if(weekno==5) {
			System.out.println("friday");
		}
		else if(weekno==6) {
			System.out.println("Saturday");
		}
		else if(weekno==7) {
			System.out.println("Sunday");
		}
		else if(weekno>7) {
			System.out.println("Invalid week no");
		}
		

	}

}
