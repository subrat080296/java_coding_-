package Day4;
import java.util.Scanner;
public class Switchcase_WeekName {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("weeknumber");
		int weeknumber=sc.nextInt();
		//int weeknumber=1;
		switch (weeknumber)
		{
			case 1:System.out.println("Sunday");break;
			case 2:System.out.println("monday");break;
			
			case 3:System.out.println("Tuesday");break;
			case 4:System.out.println("Wednesday");break;
			case 5:System.out.println("Thursday");break;
			case 6:System.out.println("Friday");break;
			case 7:System.out.println("Saturday");break;
			default: System.out.println("Not an week days");
			
		}
		}
	}



