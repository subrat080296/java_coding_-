package Day4;

public class Conditional_Statement_demo {

	public static void main(String[] args) {
	//String s="hero";
//	int i=10;
//	if(s==1) {
//		System.out.println("its true ");// this comparision is no tposiible bec both are in diffecy data types
//	}
//	else {
//		System.out.println("false");
//	}
//	
	
//	
//	if(s.equals("hero") ){
//		System.out.print("true");
		
              //    String s="ram";
                //   String s1="hori";
                   
             //      System.out.println(s+s1);

                   String s="hero34567890uwytfsghgauebdnhjkdm";
                   
                int count=0;
                   for(int i=0;i<s.length();i++) {
                	   char ch=s.charAt(i); 
            
                   if (ch=='i'||ch=='e'||ch=='i'||ch=='i'||ch=='u')
                   {
                	   count++;
                   System.out.print(ch);
                //   System.out.print(count);
                   }
                   }
                   System.out.println("total count is:"+ count);
	}

}
