package Day4;

import java.util.Scanner;

public class Switch_Case_Demo {

	public static void main(String[] args) {
		int mon=2;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter month number");
		int sc2=sc.nextInt();
		
		switch (mon)
		{
			case 1: System.out.println("january");
			break;
			
			case 2: System.out.println("febeuary");break;
			
			case 3: System.out.println("march");break;
		}

	}

}
