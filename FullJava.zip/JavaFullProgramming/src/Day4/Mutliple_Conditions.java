package Day4;

public class Mutliple_Conditions {

	public static void main(String[] args) {
		int number=10;
		if(number>0) {
			System.out.println("number is positive");
		}
		else if(number<0) {
			System.out.println("numbber is negative");
			
		}
		else
			System.out.println("number is zero");
			
		}
	}


