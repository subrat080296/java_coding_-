package Day4;

import java.util.Scanner;

public class ConditionalDemo1 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner (System.in);
		System.out.println("enter you number");
		int sc1= sc.nextInt();
		if(sc1>=90) {
			System.out.println("Grade A");
		}
		else if(sc1<90 && sc1>=80) {
			System.out.println("Grade B");
		}
		else if(sc1<70 && sc1>=50) {
			System.out.println("Grade c");
		}
		else if(sc1>100) {
			System.out.println("not valid number");
		}
      	else if(sc1<=29) {
      		System.out.print("failed ");
      	}
		

	}

}
