package Day4;

public class Smallest_Number {

	public static void main(String[] args) {
		int a=90,b=80,c=100;
		if(a<b && a<c) {
			System.out.println("a is smallest");
		}
		
			else if(b<c && b<a) {
			
			System.out.println("b is smallest");
		}
			else {
				System.out.println("c is smallest");
			}
	}
		
	}


