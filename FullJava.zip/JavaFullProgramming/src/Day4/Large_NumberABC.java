package Day4;

public class Large_NumberABC {

	public static void main(String[] args) {
		int a=9,b=60,c=50;
		if(a>b)
		{
			System.out.println("a large" +a);
		}
		else if(b>c) {
			System.out.println("b large"+ " "+b);
			
		}
		else if(c>a) {
			System.out.println("c large "+c);
		}
	}

}
