package Day4;

public class Ifcondition {

	public static void main(String[] args) {
	int person_age=12;
	if(person_age>=18)
	{
		System.out.println("Elegible for vote");
	}
	     else
	     {
		System.out.println("not Elegible for vote");
	}
	}

}
