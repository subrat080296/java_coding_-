package Day4;

public class Check_nois_PositiveorNot {

	public static void main(String[] args) {
		
		/*
		int no=-10;
		if(no>0) {
			System.out.println("no is positove");
		}
		else {
			System.out.print("no is negative");
		}
		*/
		
		//Check the persion is  elisible for vote or not ?
		 
		int a=14;
		String village="India";
		String voterid="avialeble";
		String live="Living";
		
		
		
		if (a>=18  && village.equalsIgnoreCase("india") && voterid.equals("avialeble")  && live.equalsIgnoreCase("Living"))
		{
			System.out.print("Elligible for vote");
			
		}
		else {
			System.out.println("not elligible");
		}

	}

}
