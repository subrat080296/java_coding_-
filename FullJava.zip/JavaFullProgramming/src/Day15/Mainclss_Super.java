package Day15;

public class Mainclss_Super {

	public static void main(String[] args) {
		
         caw c=new caw();
         c.display();
	}

}
