package Day15;
 class parent{
	 int page=60;
 }
 class clild extends parent{
	 int page=50;
 }
 
 class clild1 extends parent{
	 int page=40;
 
 void m1() {
	 System.out.println(super.page);
 }
 }


public class Super_Cls_Demo {

	public static void main(String[] args) {
		clild1 c1=new clild1();
		
		c1.m1();

	}

}
