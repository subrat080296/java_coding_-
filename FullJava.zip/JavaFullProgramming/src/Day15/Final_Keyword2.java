package Day15;


final class test1{
	final void m1()
	{
		System.out.println("hello");
	}
}
class test2 extends test1{ // test1 can not extended because its declare as a final
	void m1() {
		System.out.println("How are you ");
	}
}
public class Final_Keyword2 {

	public static void main(String[] args) {
		
	}

}
