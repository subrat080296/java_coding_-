package Day15;

public class Super_Animal 
{
	String colour="Red";
}
class dog extends Super_Animal
{
	String colour="white";
	
}
	class caw extends Super_Animal{
		String colour="brown";
	
	void display()
	{
		System.out.println(super.colour);
		System.out.println(colour);
		System.out.println(colour);
	}
}

