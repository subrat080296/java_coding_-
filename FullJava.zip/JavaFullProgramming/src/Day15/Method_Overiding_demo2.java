package Day15;


class Animal 
      {
	void dog()
	{
		System.out.println( "bite");
	}
}
class tiger extends Animal{
	void tigers() {
		System.out.println("running");
	
		
	}
	
}

public class Method_Overiding_demo2 {

	public static void main(String[] args) {
		tiger t=new tiger();
		t.dog();
		t.tigers();
	
	

	}

}
