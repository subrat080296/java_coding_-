package Day15;

//public class Superkeyin_Method_Animal {
	class Superkey_Method_Animal{
	String colour="Red";
	
	void eat()
	{
		System.out.println("Eating Grass");	
}
}

class Tiger extends Superkey_Method_Animal{
	String colour="Browen";
	void display()
	{
		System.out.println(colour);
	}

void eat()
{
	System.out.println("Eating Chicken");
}

public class Superkeyin_Method_Animal {
	
}
	public static void main(String[] args) {
		Tiger t=new Tiger();
		t.eat();
		

	}
}



