package Day15;



class demotest{
	final void m7() 
	{
		int a=10,b=30;
		System.out.println(a+b);
	}
}
class d2 extends demotest{
	 void m7()
	 {
		 
		 System.out.println(a+b);
	 }
}

public class FinalMethod_Demo1 {

	public static void main(String[] args) {
		demotest t= new demotest();
		t.m7();
		
		d2 d=new d2();
		d.m7();

	}

}
