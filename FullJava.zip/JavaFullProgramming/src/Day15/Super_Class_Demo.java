package Day15;

class bike{

	String colour="white";
	}


class car  extends bike{
	
		String colour="black";


void display() {
	System.out.println(super.colour);
	System.out.println(colour);
}
}

public class Super_Class_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		car c=new car();
        c.display();

	
}

}
