package Day15;

class D{
	int age=10;
	void display() {
		System.out.println(age);
		}
}
class b extends D
{
	int age=20;
	void show() {
		System.out.println(age);
	}
}

class c extends b{
	int age=30;
	void print()
	{
		System.out.println(age);
	}
}
class xyt extends c{
	void  m1(int age) {

		System.out.println(age+age);
	}
}
class str extends xyt{
	void m2(int a , int b) {
		System.out.println(a*b);
	}
	
}

public class MethodOverriding_vs_OverLoading {

	public static void main(String[] args) {
		str st=new str();
		st.m2(10, 20);
		st.m1(10);
		

	}

}
