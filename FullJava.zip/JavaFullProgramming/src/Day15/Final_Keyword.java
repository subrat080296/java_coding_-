package Day15;

class Test{
	int x=100;//Its changeable the value 
	//final int x=10;//Its changeable the value
}

public class Final_Keyword {

	public static void main(String[] args) {
		Test t=new Test();
		
		t.x=100;//not change value because we have use final keyword
		
		System.out.println(t.x);

	}

}
