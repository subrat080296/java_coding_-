package Day15;
class Bank{
	double roi()
	{
		return 0	;
		}
}
class ICICI extends Bank{
	@Override
	double roi()
       {
		return(10.5);
		}
}
class SBI extends Bank{
	@Override
	double roi(){
		return (9.5);
	}
}

public class Method_OverRiding_Demo {

	public static void main(String[] args) {
		ICICI obj=new ICICI();
		System.out.println(obj.roi());
		SBI sb=new SBI();

		System.out.println(sb.roi());

	}

}
