package Day15;

class a{
	void display(int a,int b) {
		System.out.println(a+b);
	}
}


class x extends a{
	void display(int a,int b)
	{
		System.out.println(a*b);
	}
}

class y extends x{
	void display(int a,int b,int c) {
		System.out.println(a+b+c);
	}
}

class z extends y{
	void display(int a,int b,int c) {
		System.out.println(a+b+c);
	}
}
public class OverLoading_OverRiding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		z d1=new z();
		d1.display(10, 15,0);
		d1.display(1, 2, 3);

	}

}
