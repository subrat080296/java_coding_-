package Day8;

import java.util.Arrays;

public class String_Class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Hello";
		String s1=new String("welcome");
		System.out.println(s.length());
		System.out.println(s1.length());
		
		//Concat= using to add two or more Strings
		String s3="How are you";
		String s4="I am fine";
		String s5="who are you";
		System.out.println(s3+s4);
		System.out.println(s3.concat(s4));
		System.out.println(s3.concat(s4).concat(s5));
		
		
		//Trim:= Its Removed Spaces from left and right hand site
		String s6="   Hello   ";
		System.out.println(s6);
		System.out.println("Before trim:  " + s6.length());
		System.out.println(s6.trim());
		System.out.println("After trim:  " + s6.trim().length());
		
		//CharAt()= Used to Find actual character from Index
		String s7= "Hello world";
		System.out.println(s7.charAt(7));
		System.out.println(s7.charAt(9));
		//Contains():= To determine the particular character is the part of the main string or not ,It will show the result of True or False
		String s8="Welcome to Java";
		System.out.println(s8.contains("to"));
		System.out.println(s8.contains("java"));
		System.out.println(s8.contains("WELCOME"));
		
		//equal or EqualIgnore case();Used to compare Strings
		String s9="Ram is good boy";
		String s10="Ram is good boy";
		System.out.println(s9==s10);
		System.out.println(s9.equals(s10));
		System.out.println(s9.equalsIgnoreCase("Ram is good boy"));
		
		//Replace single or Multiple  character in an String;
		String s11="Welcome to java Selenium java python";
		System.out.println(s11.replace('e','x'));//for character replace
		System.out.println(s11.replace("java","C##"));//for String Replace
		
		//Substring;= Used to find specific character in an sting = s.substring(index number)
		String s12="What is you name";
		System.out.println(s12.substring(0,8));
		System.out.println(s12.substring(0,2));
		
		String s13="abcaacc";
		System.out.println(s13.replace('a', 'x').replace('c', 'y'));
		
		
		//toUpperCase()                  toLowerCase()
		
		String s14="Going to puri";
		String s15="GOING FOR PURI";
		System.out.println(s14.toUpperCase());
		System.out.println(s15.toLowerCase());
		
		//Split= split the string in to multiple parts
		/*String s16="welcometo Odisha";
		String a[]=s16.split(" ");
		System.out.println(a[0]);
		System.out.println(a[1]);
		*/
		/*String s17="abc@gmail.com";
		String a[]=s17.split("@");//divided in to two parts abc and gmail.con
		System.out.println(a[0]);
		System.out.println(a[1]);
		*/
		//Example1 =Split method
		String s18="$12,78,89";
		System.out.println(s18.replace("$", " "));
		System.out.println(s18.replace("$", " ").replace(",", ""));
		
	/*	//Example2=Split method
		String s19="abc,123@xyz";//  abc 123 xyz
		String arr1[]=s19.split(",");//abc 123@xyz
		System.out.println(Arrays.toString(arr1));
		String arr2[]=arr1[1].split("@");//123 xyz
		System.out.println(Arrays.toString(arr2));
		
		System.out.println(arr1[0]);
		System.out.println(arr2[0]);
		System.out.println(arr2[1]);
		*/
		//ex=3
		String name="Jhon Kandy";
		System.out.println(name.replace('J', 'j').contains("jhon"));
		System.out.println(name.toLowerCase().contains("jhon"));
		
	
		
		

	}

}
