package Day8;

public class String_Join_Using_Concat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="Hello";
		String s1="How are you?";
		String s3="I am fine";
		
		System.out.println(s.concat(s1)+" ".concat(s3)+"  ");
		
	//	System.out.println(s+s1+s3);
		
		System.out.println(s.concat(s1+s3));

	}

}
