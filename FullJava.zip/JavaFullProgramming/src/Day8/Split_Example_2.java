package Day8;

import java.util.Arrays;

public class Split_Example_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="abc,xzx@gmail.com";
		String arr[]=s.split(",");
		System.out.println(Arrays.toString(arr));
	String a[]=	s.split("@");
	System.out.println(Arrays.toString(a));
	System.out.println(arr[0]);
	System.out.println(a[1]);
	System.out.println(a[2]);

	}

}
