package Day8;

public class Trim_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="    Hello   ";
		System.out.println(s);
		System.out.println(s.length());
		System.out.println(s.trim().length());//trim is used to remove the space in both left and right side of the string
		
		

	}

}
