package Day8;

public class String_ex2 {

	public static void main(String[] args)
	
	{
	String str=new String("Hello");
	str=str.toUpperCase();
	System.out.println(str);
	
	int length=str.length();
	System.out.println(length);
	
	
	//System.out.println(str+" "+"Length is "+str.length());
	}

}
