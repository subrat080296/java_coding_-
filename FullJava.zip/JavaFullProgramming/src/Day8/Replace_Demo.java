package Day8;

public class Replace_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Welcome to java selenium python automation";
	System.out.println(	s.replace('e', 'x'));
	System.out.println(	s.replace("java", "ruby"));
	// replace is used to replace single or multiple character in a string
	

	}

}
