package Day8;

public class Substring_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String s="Subrata";
		System.out.println(s.substring(0,6));
		System.out.println(s.substring(5,6));
		System.out.println(s.substring(3,7));

	}

}
