package Day8;

public class String_exm {

	public static void main(String[] args) {
		
	String str="java";
	System.out.printf("%20s",str);

	}

}
