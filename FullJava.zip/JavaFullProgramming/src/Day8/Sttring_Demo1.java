package Day8;

public class Sttring_Demo1 {

	public static void main(String[] args) {
		String s="Hello ja ja ja aj aj aja aja a";
		String s2="hello";
		
		//if(s.equals(s2))
		System.out.println('r'+0);// TO find asky value print the number with single quote and + 0 add with it
		if(s.equalsIgnoreCase(s2))
		{
			System.out.println("ture");
		}else {
			System.out.println("false");
		}
		
		System.out.println(s.substring(1,3));
		System.out.println(s.replace("ja" ,"all"));
		
		System.out.println(s.startsWith("o"));
		
		int name=s.indexOf("a");
		System.out.println(name);
	}

}
