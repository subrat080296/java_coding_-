package Day8;

public class Replace_Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String amount="$15,12,89";
	System.out.println	(amount.replace("$", ""));
	System.out.println	(amount.replace("$", " ").replace(",", " "));

	}

}
