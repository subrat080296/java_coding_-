package Day8;

public class String_Demo1 {

	public static void main(String[] args) {
		
		int a=10;
		float b=10.5f;
		char c='A';
		String str="java program";
		
		System.out.printf("%1$d %1$f %3$s ",a,b,str);

	}

}
