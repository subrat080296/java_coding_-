package Day8;

public class Split_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Split is used for separate the character
		
		String s="abc@gmail.com";
		 String a[]=s.split("@");
		 System.out.println(a[0]);
		 System.out.println(a[1]);
		

	}

}
