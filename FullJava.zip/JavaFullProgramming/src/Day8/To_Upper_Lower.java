package Day8;

public class To_Upper_Lower {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="hello";
		System.out.println(s.toUpperCase());
		
		String s1="HELLO";
		
		System.out.println(s1.toLowerCase());

	}

}
