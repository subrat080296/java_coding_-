package Day8;

public class Equals_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	//	String s="Welcome";
	//	String s2="Welcome";
	//	System.out.println(s.equals(s2));
		
		String s="Welcome";
		String s2="WelcomE";
		System.out.println(s.equalsIgnoreCase(s2));// equalsIgnoreCase is followed any ksensitivity

	}

}
