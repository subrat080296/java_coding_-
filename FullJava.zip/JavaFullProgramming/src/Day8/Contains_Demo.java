package Day8;

public class Contains_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="Helcome to javaautomation";
		String s2="to";
		
		System.out.println(s.contains(s2));
		System.out.println(s.contains("Helcome"));
		System.out.println(s.contains("TO"));
		

	}

}
