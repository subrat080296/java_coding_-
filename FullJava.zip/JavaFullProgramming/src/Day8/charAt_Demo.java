package Day8;

public class charAt_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String s="sbadert";
		 System.out.println(s.charAt(6));// charAt return the Index  of a string

	}

}
