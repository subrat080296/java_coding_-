package Day17;

public class String_Int_Demo {

	public static void main(String[] args) {
		String s="20";
		String s1="23";
		
		
		//s+s1=?
		
		int i=Integer.parseInt(s);
		int i1=Integer.parseInt(s1);
		System.out.println(i+i1);
	}

}
