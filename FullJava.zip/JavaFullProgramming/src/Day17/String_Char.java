package Day17;

public class String_Char {

	public static void main(String[] args) {
		
	//NOte= String to char convert is not possible  

	}

}
