package Day17;

public class AnyData_String {

	public static void main(String[] args) {
		 int a=10;
		 
		 String s=String.valueOf(a);
		 
		 System.out.println(s);
		 

	}

}
