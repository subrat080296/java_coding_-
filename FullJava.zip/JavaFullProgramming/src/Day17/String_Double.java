package Day17;

public class String_Double {

	public static void main(String[] args) {
		
		String s3="10.5";
		String s4="10.6";
		
	//	s3+s4=?
		Double d=Double.parseDouble(s3);
		Double d1=Double.parseDouble(s4);
		
		System.out.println(d+d1);
				

	}

}
