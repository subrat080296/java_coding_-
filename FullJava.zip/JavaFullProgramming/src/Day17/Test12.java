package Day17;

public class Test12 {

	public static void main(String[] args) {
		Test11 t1=new Test11();
		System.out.println(t1.x);
		t1.m1();

	}

}
