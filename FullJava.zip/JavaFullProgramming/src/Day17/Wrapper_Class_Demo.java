package Day17;

public class Wrapper_Class_Demo {

	public static void main(String[] args) {
	//String to Integer
		//String s="Welcome";//Cannot convert
	//	String s1="10";
	//	String s2="20";
	//	System.out.println(s1+s2);//without wrapper its con cating 
	//	System.out.println(Integer.parseInt(s1)+Integer.parseInt(s2));

	//}
         //String ==>Double
/*	String s3="10.7";
	String s4="42.9";
	
	System.out.println(Double.parseDouble(s3)+Double.parseDouble(s4));
}
	*/
		//String== boolean
		/*String s5="Welcome";//other than true if you pass any value it will returns false
		System.out.println(Boolean.parseBoolean(s5));
		*/
		
		//int,double,char,boolean,double==>String
		
		int a=1009080;
		double d=10.5;
		char c='A';
		boolean b=true;
		
		String s=String.valueOf(a);
		String s1=String.valueOf(d);
	     String s2=String.valueOf(c);
		String s3=String.valueOf(b);
		System.out.println(s);
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		
	}
}