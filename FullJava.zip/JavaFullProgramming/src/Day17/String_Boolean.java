package Day17;

public class String_Boolean {

	public static void main(String[] args) {
		
		String s5="false";
		
		System.out.println(Boolean.parseBoolean(s5));
		
		

	}

}
