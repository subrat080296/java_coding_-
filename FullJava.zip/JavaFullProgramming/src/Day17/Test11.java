package Day17;

public class Test11 {
	//Private
	/*private int x=100;
	void m1()
	{
		System.out.println("This is private clss test");
	}
	*/
	//Default
	int x=100;
	void m1()
	{
		System.out.println("This is private clss test");
	}


}
