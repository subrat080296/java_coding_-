package Day_3;

public class Logical_Operator_Demo {

	public static void main(String[] args) {
		// Logical Operator also returns Boolean value= True or False
		boolean x=true;
		boolean y=false;
		System.out.println(x && y);//false
		System.out.println(x || y);//true
		System.out.println( !x );//false
		System.out.println(! y);//true
		
		boolean b1=10>20;
		System.out.println(b1);
		
		boolean b2=30>20;
		System.out.println(b2);
		
		System.out.println(b1 && b2);//false
		System.out.println(b1 || b2);//true
		
		System.out.println(10<20 && 40>30);//true

	}

}
