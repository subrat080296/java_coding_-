package Day_3;

public class Operator_Demo {

	public static void main(String[] args) {
		//Arithmetic operator  +, *, -,/,%
		int a=60,b=20;
		System.out.println("Sum of a and b is:"+(a+b));
		System.out.println("difference of a and b is:"+(a-b));
		System.out.println("multiplication of a and b is:"+(a*b));
		System.out.println("division of a and b is:"+(a/b));
		System.out.println("modulo of a and b is:"+(a%b));
		
		
		//Relational Operator

	}

}
