package Day_3;

import java.util.Scanner;

public class Loops_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your age");
		
		int age=sc.nextInt();
		
		if(age>=18 && age<=180) {
			System.out.println("Elligible for vote");
		}
		else if(age<18 && age>0) {
			System.out.println("note elligible for vote");
		}
		else
		{
			System.out.println("Invalid age");
		}

	}

}
