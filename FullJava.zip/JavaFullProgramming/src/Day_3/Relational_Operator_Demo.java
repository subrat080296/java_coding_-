package Day_3;

public class Relational_Operator_Demo {

	public static void main(String[] args) {
		
		//Relational Operator
		//> ,>=,<,<=,!=,==
		
		int a=70,b=30;
		System.out.println(a>b);
		System.out.println(a>=b);
		System.out.println(a<b);
		System.out.println(a<=b);
		System.out.println(a!=b);
		System.out.println(a==b);
		
		//Relation Operator returns only Boolean value +True or False

	}

}
