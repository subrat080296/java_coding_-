package Day_3;

public class Continue_Condition_demo {

	public static void main(String[] args) {
		int a=10;
		
		
		for(int i=0;i<a;i++) {
			if(i==5  || i==8) {
				continue;
			}
			System.out.print(i);

		}

	}

}
