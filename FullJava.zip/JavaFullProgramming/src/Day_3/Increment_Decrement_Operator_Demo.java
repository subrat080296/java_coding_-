package Day_3;

public class Increment_Decrement_Operator_Demo {

	public static void main(String[] args) {
		// ++ increment operator
		//case-1
	/*	int a=10;
		System.out.println(a);
          	a++;	//a=a+1;
		System.out.println(a);
		*/
		
		
		//case-2  post increment
	/*	int a1=10;
		int res=a1++;
		System.out.println(res);
		System.out.println(a1);
		*/
		//Case-3  pre increment
		int a=10;
		int res=++a;
		System.out.println(res);
	//	System.out.println(a1);

	}

}
