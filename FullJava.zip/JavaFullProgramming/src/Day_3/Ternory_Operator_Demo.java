package Day_3;

public class Ternory_Operator_Demo {

	public static void main(String[] args) {
		// 
		/*
		int a=200,b=100;
		int x=(a<b)? a:b;
		System.out.println(x);
		*/
		
		int age=30;
		String eglligble=(age>18)?"elligble":"not elligble";
		System.out.println(eglligble);

	}

}
