package Day_3;

public class Assignment_Operator_Demo {

	public static void main(String[] args) {
		
		// ==, +=,-=,*=,/=,%=
		/*	
		int a=10;
            
	           a+=5;//a=a+5;
	    	   a-=5;//a=a-5;
	    	*/
		
		/*
		int a=20;
     	a*=2 ; //	a=a*2;
		*/
		
		/*
		int a=10;
		a/=2;  //a=a/2;
		*/
		
		int a=21;
	a%=2;    //a=a%2;
		
		System.out.println(a);
		
		

	}

}
