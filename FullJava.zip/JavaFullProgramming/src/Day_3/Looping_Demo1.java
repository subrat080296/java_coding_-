package Day_3;

public class Looping_Demo1 {

	public static void main(String[] args) {
		/*int a=5;
		 while(a<10) {
			 System.out.println(a);
			 a++;
		 }
		 System.out.println(a);
*/
		
		String s="heloo";
		while(s!=null) {
			System.out.println(s);
			break;
			
		}
	}

}
