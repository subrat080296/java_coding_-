package Day_3;

public class Decrement_Operator_Demo {

	public static void main(String[] args) {
		// Decrement operator
		
		int a=10;
		System.out.println(a);
	//	int res=a--;
	//	System.out.println(res);
		//System.out.println(a);
		int res11=--a;
		System.out.println(a);

	}

}
