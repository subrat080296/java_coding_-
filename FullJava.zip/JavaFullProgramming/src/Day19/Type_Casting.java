package Day19;

public class Type_Casting {

	public static void main(String[] args) {
		//Up casting ==>converting data from smaller to higher
	/*	int x=100;
		long l=x;
		System.out.println(l);
		*/
		
		/*float f=9.8f;
		double d=f;
		System.out.println(d);
		*/
		//Downcasting
		long l=1000000000;
		
		int i=(int)l;
		System.out.println(i);
	}

}
