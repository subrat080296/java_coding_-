package Day19;

class parent{
	int x=100;
	void m1() {
		System.out.println("its parent");
		
	}
}
class child extends parent{
	int y=200;
	void m2()
{
		System.out.println("its child");
}
}

public class Typecasting_Object1 {

	public static void main(String[] args) {
		/*
	child c =new child();
	c.m1();
	System.out.println(c.x);
	c.m2();
	System.out.println(c.y);
	*/
		/*
	parent p=new child();//up casting
	p.m1();
	System.out.println(p.x);
	p.m2();// we can not access from child class
	System.out.println(p.y);//we can not access from child class
*/
		//Downcasting
		
		parent p=new parent();
		child c=(child)p;
		System.out.println(c.x);
		
		
	}

}
