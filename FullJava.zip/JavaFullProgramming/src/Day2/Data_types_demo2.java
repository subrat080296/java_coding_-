package Day2;

public class Data_types_demo2 {

	public static void main(String[] args) {
		Integer a=200;
		Integer b=200;
		if(a==b) {
			System.out.println("true");
			
		}
		else {
			System.out.println("false");
		}

	}

}
