package Day2;

public class TypeCasting_demo {

	public static void main(String[] args) {
//	double d=10.6;
//	int a=(int)d;
//	System.out.println(a);
		 
		
		long l=10000000;
		int i=(int)l;
		System.out.println(l);

	}

}
