package Day2;

public class DataTypes_Demo {

	public static void main(String[] args) {
		int a=10;
		int b=90;
		System.out.println(a+b);
		int c=60,d=20;
		System.out.println(c+d);
	
		byte b1=124;
		System.out.println(b1);
		
		short s1=1287;
		System.out.println(s1);
		
		long l1=234567899;
		System.out.println(l1);
		
		
		float f1=23.6f;
		System.out.println(f1);
		
		
		 double d1=343.8;
		 System.out.println(d1);
		 
		 char c1='A';
		 System.out.println(c1);
		 
		 String s7="Sriram";
		 System.out.println(s7);
		 
		 String ch="A";
		 System.out.println(ch);
		 
		 boolean b11="true";// not valid
		 System.out.println(b11);

	}

}
