package Day2;

public class VariableDemo1 {

	public static void main(String[] args) {
		String s="Hello";
		Character ch='A';
		int i=10;
		double d=10.5;
		System.out.println(s+" "+ch+" "+i+" "+d);

	}

}
