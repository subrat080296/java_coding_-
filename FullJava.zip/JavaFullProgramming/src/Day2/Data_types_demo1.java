package Day2;

public class Data_types_demo1 {

	public static void main(String[] args) {
		byte b=10;
		System.out.println(b);

	}

}
