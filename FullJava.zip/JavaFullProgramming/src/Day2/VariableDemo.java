package Day2;

public class VariableDemo 
{
	public static void main (String[] args)
	{
		

int a=100;
int b=90;
int c=80;
System.out.println(a);
	a=200;
	System.out.println(a);
	System.out.println(a+" "+b+" "+c);

	}
}
