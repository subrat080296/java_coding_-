package Day5;

public class Hello_10Times 
{
	public static void main (String[] args) {
	int i=1;
	
	while (i<=10) {
		System.out.println("Hello");
		i++;
	}
			
}
}
