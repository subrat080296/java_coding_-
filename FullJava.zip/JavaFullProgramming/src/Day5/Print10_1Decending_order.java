package Day5;

public class Print10_1Decending_order {

	public static void main(String[] args) {
	for (int i=10;i>=1;i--) {
		System.out.println(i);
	}
	}

}
