package Day5;

public class DecendingOrder_10to1 {

	public static void main(String[] args) {
	int i=10;
	while (i>=1)
	{
	System.out.println(i);
	i--;
	}
		
	}

	}


