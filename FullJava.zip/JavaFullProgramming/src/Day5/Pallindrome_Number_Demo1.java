package Day5;

public class Pallindrome_Number_Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1=121;
		int pn=0;
		
		int originalnumber=num1;
		while(num1!=0) 
		{
			pn=num1%10+pn*10;
			
			num1=num1/10;
		}
		if (originalnumber==pn) 
		{
			System.out.println("Pallindrome number");
		}
		else 
		{
			System.out.println("Not pallindrome number");
		}

	}

}
