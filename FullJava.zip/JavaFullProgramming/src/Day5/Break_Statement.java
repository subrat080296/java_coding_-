package Day5;

public class Break_Statement {

	public static void main(String[] args) {
	//int i=1;
	for(int i=1;i<=10;i++) {
		if(i==5) {
			break;
			
		}
		System.out.println(i);
	}

	}

}
