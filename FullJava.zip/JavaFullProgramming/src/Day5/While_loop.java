package Day5;

public class While_loop {

	public static void main(String[] args) 
	{
		int i=1;
		while(true)
		{
			System.out.println("hello");
			i++;		
		
		if(i==10)
		{
			break;
		}

	}

	}
}
