package Day5;

public class Specify_evenOdd {

	public static void main(String[] args) {
		int i=1;
		while(i<+10) {
			if(i%2==0) {
				System.out.println("Eeven number" +i);
			}
			
		else {
			System.out.println("Odd Number" +i);
		}
i++;
	}
	}

}
