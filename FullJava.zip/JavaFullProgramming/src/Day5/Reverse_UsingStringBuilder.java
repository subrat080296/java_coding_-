package Day5;

public class Reverse_UsingStringBuilder {

	public static void main(String[] args) {
	int num=12345678;
	StringBuilder sbl=new StringBuilder();
	sbl.append(num);
	StringBuilder rev=sbl.reverse();
	System.out.println(rev);

	}

}
