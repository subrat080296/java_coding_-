package Day5;

public class Sum_numberinanDigits {

	public static void main(String[] args) {
		int num=81241;
		int sum=0;
		while(num>0) {
			sum=sum+num%10;
			num=num/10;
		}
		System.out.println(sum);

	}

}
