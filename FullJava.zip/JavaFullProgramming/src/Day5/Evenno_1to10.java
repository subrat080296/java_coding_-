package Day5;

public class Evenno_1to10 {

	public static void main(String[] args) {
		int i=2;
		while (i<=10) {
			if(i%2==0) {
				System.out.println(i);
			}
				i++;
			
		}

	}

}
