package Day5;

public class Assignment_Reverse_Demo {

	public static void main(String[] args) {
		// TOD
		
		int number=12345;
		
		int rev=0;
		while(number!=0) 
		{
		rev=number%10+rev*10;
	
	      number=number/10;
		}
	

			System.out.println(rev);
			
		}
	
}

	


