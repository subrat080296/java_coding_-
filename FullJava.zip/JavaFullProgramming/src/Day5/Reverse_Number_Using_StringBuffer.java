package Day5;

public class Reverse_Number_Using_StringBuffer {

	public static void main(String[] args) {
		int num=123456;
		StringBuffer sb=new StringBuffer(String.valueOf(num));//Converting number to String format
		StringBuffer rev=sb.reverse();
	
	     System.out.println(rev);


		
	}

}
