package Day5;

public class Count_Number_1233422 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=1234323;
		int count=0;
		while(n!=0) 
		{
			
		
			n=n/10;
			count++;
		}
		System.out.println(count);

	}

}
