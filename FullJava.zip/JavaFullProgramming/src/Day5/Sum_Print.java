package Day5;

public class Sum_Print {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int nomber=1234563;
		int sum=0;
		while(nomber!=0) {
			 sum=sum+nomber%10;
			 nomber=nomber/10;
			 
		}
		System.out.print(sum);

	}

}
