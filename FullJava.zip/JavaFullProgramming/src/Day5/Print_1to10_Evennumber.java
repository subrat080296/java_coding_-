package Day5;

public class Print_1to10_Evennumber {

	public static void main(String[] args) {
	for(int i=1;i<=10;i++) 
	if(i%2==0)
	{
		System.out.println(i);
	}

	}

}
