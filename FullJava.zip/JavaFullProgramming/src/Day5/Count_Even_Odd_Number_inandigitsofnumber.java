package Day5;

public class Count_Even_Odd_Number_inandigitsofnumber {

	public static void main(String[] args) {
		int num=123047891;
		int even_count=0;
		int odd_count=0;
		while(num>0) {
			
			
			int rem =num%10;
			if(rem%2==0)
			{
			even_count++;
			}
			else
			{
				odd_count++;
			}
			num=num/10;
		}
        System.out.println("number of Even count is " + even_count);

	
	 System.out.println("number of odd count is " + odd_count);
	}

}
