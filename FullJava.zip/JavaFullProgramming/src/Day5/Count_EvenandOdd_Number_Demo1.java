package Day5;

public class Count_EvenandOdd_Number_Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number=12376549;
		int evenc112=0;
		int oddc112=0;
		
		while(number!=0) 
		{
			int remen=number%10;
			if(remen%2==0) 
			{
				evenc112++;
			
				
				}
		
		             else {
			              oddc112++;
		             }
			              number=number/10;
			
			
		}
			System.out.println(evenc112);
			System.out.println(oddc112);

	}

}

