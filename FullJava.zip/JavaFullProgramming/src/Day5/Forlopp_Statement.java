package Day5;

public class Forlopp_Statement {

	public static void main(String[] args) {

		for(int i=1;i<=10;i++) 
		{
			System.out.println(i);
		}

	}

}
