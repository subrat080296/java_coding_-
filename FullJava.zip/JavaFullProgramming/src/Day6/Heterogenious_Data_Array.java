package Day6;

public class Heterogenious_Data_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Object a[]= {200,"Subrata",65,'A' , 10.5,true};
		
		for(Object x:a)
		
		
		System.out.println(x);

	}

}
