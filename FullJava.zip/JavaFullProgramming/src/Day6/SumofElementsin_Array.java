package Day6;

public class SumofElementsin_Array {
	public static void main(String[] args) {
		int a[]= {1,7,8,9,2,3,7,1,1,1};
		int sum=0;
		for(int i=0;i<=a.length-1;i++) {
			sum=sum+a[i];
		}
		System.out.println(sum);
	}

}
