package Day6;

public class Enhanced_Forloop {

	public static void main(String[] args) {
		Object a[]= {100,9,9.0,true,"welcome",'A'};
		{
			/*for(Object x:a) {
		
		System.out.println(x);
			}
			*/


//Another way to got an Normal For loop
			
			for (int i=0;i<a.length;i++) {
				System.out.println(a[i]);
			}
		}

		}
	}