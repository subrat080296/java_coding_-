package Day6;

public class Single_Dimensional_Array {

	public static void main(String[] args) {
		//Approach-1
	/*	int a[]=new int[5];//Declaration
		a[0]=100;//Assign the value in to the Index
		a[1]=200;
		a[2]=300;
		a[3]=400;
		a[4]=500;
	}

}*/

//Approach-2
      /* int a[]= {100,200,300,400,500,700,9};
      // find the length of the array?
       System.out.println(a.length);
       System.out.println(a[3]);
       */
		int a[]= {100,200,300,400,500,700,9};
		//for(int i=0;i<=a.length-1;i++)
			for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
}
}
}