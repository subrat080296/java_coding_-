package Day6;

public class Even_Odd_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {12,87,90,45,32,65};
	int	evencount1=0;
	int oddcount1=0;
		
		for(int x:a) {

			if(x/2==0) {
			
				evencount1++;
				
			}
			
			else {
				oddcount1++;
			}
			System.out.print(evencount1++);
			System.out.print("odd count is"+ oddcount1++);
			System.out.println();
		
		}

	}

	}


