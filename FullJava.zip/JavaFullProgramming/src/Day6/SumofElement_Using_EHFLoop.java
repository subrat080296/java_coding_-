package Day6;

public class SumofElement_Using_EHFLoop {

	public static void main(String[] args) {
		int a[]= {7,2,3,5,5,1,8,6,};
		int sum=0;
		for (int x:a) {
			sum=sum+x;
		}
		System.out.println(sum);

	}

}
