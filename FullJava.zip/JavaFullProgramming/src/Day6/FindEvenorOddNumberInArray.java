package Day6;

public class FindEvenorOddNumberInArray {

	public static void main(String[] args) {
		int a[]= {1,5,2,4,7,8,4,9};
		//int even_number=0;
		//int odd_number=0;
		/*for(int i=0;i<=a.length;i++) {
			if(a[i]%2==0) {
				System.out.println("even_number"+a[i]);
			}
			else {
				System.out.println("odd_number"+a[i]);
			}*/
		for(int x:a) {
			if(x%2==0) {
				System.out.println(x);
			}
		}
	}

}
