package Day6;

public class Sum_Elementsa_123456 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {1,2,3,4,5,6,4};
		
		int sum=0;
		for (int i=0;i<a.length;i++) {
			
			sum=sum+a[i];
		}
		System.out.println(sum);

	}

}
