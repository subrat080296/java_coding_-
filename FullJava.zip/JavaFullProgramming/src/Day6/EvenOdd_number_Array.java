package Day6;

public class EvenOdd_number_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {12,87,90,45,32,65};
		int rem=0;
		for(int x:a) {
			rem=x%10;
			if(rem==0) {
				System.out.println("Even number:"+ x);
			}
			else {
				System.out.println("odd number"+ x);
			}
		}

	}

}
