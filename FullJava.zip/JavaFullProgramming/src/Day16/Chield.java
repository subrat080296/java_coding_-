package Day16;

public class Chield implements I1,I2
{
	public void m1() {
		System.out.println(x);
	}
	public void m2() {
		System.out.println(y);
	}

	public static void main(String[] args) {
		Chield objc1=new Chield();
		objc1.m1();
		objc1.m2();

	}

}
