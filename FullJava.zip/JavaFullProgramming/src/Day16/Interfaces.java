package Day16;
interface shape{
	int length();
	int width();
	void circle();//Abstract class ;not Implemented
	
    default void square() {
	System.out.println("This default class..........");
    }
	
	static void rectangle() 
	{
		System.out.println("This is Static class ");
	}
}
         public class Interfaces implements shape
       {
	       public void circle()
	{
		System.out.println("circle is sbstract menthhod...");
	}

	public static void main(String[] args) {
		
		Interfaces ifc=new Interfaces();
		ifc.circle();
		shape.rectangle();
		ifc.square();

	}

	@Override
	public int length() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int width() {
		// TODO Auto-generated method stub
		return 0;
	}

}
