package Day7;
import java.util.Arrays;
import java.util.Scanner;
public class InputArraysValuefromConsoleWindow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int[5];
		Scanner sc=new Scanner(System.in);
		
		for(int i=0;i<a.length;i++) {
			
			System.out.println("Enter Value for the position of a[i] ");
		
			a[i]=sc.nextInt();
					
			System.out.println(Arrays.toString(a));

	}
		//System.out.println(a[i]);

}
}
