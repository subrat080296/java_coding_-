package Day7;

public class Sortling_Array_UsingLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {12,78,20,34,8,32,56,98,39};
		for (int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]>a[j]) {
                    int temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
				}
				
			}
			System.out.print(a[i]+" ");
		}
	
	}

}
