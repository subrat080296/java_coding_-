package Day7;

import java.util.Arrays;

public class Sorting_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           // String s[]= {"x","B","D","M","A"};
            String s[]= {"ram","chandan","abc","xyz"};
            System.out.println(Arrays.toString(s));// Arrays.toSting()=> used to print all element
            Arrays.sort(s);
            System.out.println(Arrays.toString(s));
	}

}
