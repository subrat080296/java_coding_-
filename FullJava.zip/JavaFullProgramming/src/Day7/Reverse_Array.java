package Day7;

public class Reverse_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,67,24,87,34,23,500};
		for (int i=a.length-1;i>=0;i--) {
			System.out.print(a[i]+" ");
		}

	}

}
