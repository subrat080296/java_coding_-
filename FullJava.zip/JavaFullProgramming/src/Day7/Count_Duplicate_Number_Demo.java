package Day7;

public class Count_Duplicate_Number_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {12,67,23,90,12,30,90,70,56,30};
		int count=30;
		for (int i=0;i<a.length;i++) {

				if(a[i]==count)
					
				{
					count++;
				
				}
			}
			
		}
				

	}


