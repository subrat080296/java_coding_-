package Day7;

import java.util.Arrays;

public class Sorting_Character_Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char s[]= {'Z','S','U','Z','A','E'};
		System.out.println("Before shorting all print: "+Arrays.toString(s) );
		
		Arrays.sort(s);
		System.out.println("After shorting all print: "+Arrays.toString(s) );
		
		
		

	}

}
