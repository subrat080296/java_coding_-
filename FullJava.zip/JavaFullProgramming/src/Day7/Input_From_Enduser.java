package Day7;

import java.util.Scanner;

public class Input_From_Enduser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		
		int num=sc.nextInt();
		

	}

}
