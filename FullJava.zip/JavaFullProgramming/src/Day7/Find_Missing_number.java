package Day7;

public class Find_Missing_number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {1,3,4,5};
		

	}

}
