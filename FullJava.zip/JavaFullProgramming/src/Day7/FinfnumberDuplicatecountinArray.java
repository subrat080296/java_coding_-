package Day7;

public class FinfnumberDuplicatecountinArray {

	public static void main(String[] args) {
		int a[]= {12,90,87,56,40,30,12,67,40,56,40};
		int num=40;
		int dub_count=0;
		for (int i=0;i<=a.length-1;i++) {
			if(a[i]==num) 
				dub_count++;
			}
			System.out.println(dub_count);
		}
		
	}


