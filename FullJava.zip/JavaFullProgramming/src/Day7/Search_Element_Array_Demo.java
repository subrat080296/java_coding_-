package Day7;

public class Search_Element_Array_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {12,20,19,2,90,45,81,28,90};
		int S_element=90;
		for (int i=0;i<a.length;i++) 
		{
			if(a[i]==S_element)
				
			{
				System.out.println(a[i]);
				break;
			}

			}
		
		            
			System.out.println("element not found");
		
		
		

	}

}
