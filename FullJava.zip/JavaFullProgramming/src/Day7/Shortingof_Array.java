package Day7;

import java.util.Arrays;

//import java.util.Arrays;
//import java.lang.reflect.Array;

public class Shortingof_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,80,70,32,76,45};
		for (Object value:a) {
		System.out.println("Before sorting.........."+ value);
		System.out.println(Arrays.toString((long[]) value));
          Arrays.sort((int[]) value);
	}
	}

}
