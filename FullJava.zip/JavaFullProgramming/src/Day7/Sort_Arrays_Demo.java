package Day7;

import java.util.Arrays;

public class Sort_Arrays_Demo {

	public static void main(String[] args) {
		int a[]= {12,89,67,35,73,9,29};
		  // to print all elements
		
		//System.out.println(Arrays.toString(a));//used for printing porpose
		Arrays.sort(a);		
		System.out.println(Arrays.toString(a));

	}

}
