package Day7;

import java.util.Scanner;

public class Input_String_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the city");
		String s=sc.next();
		System.out.println(s.length());

	}

}
