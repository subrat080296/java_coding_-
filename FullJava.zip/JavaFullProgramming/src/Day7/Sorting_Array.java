package Day7;

import java.util.Arrays;

public class Sorting_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {12,90,67,35,27,18};
		System.out.println("Before sorting...");
		
		System.out.println(Arrays.toString(a));
		
		Arrays.sort(a);
		
		System.out.println("After sorting...");
		
		System.out.println(Arrays.toString(a));
		
		
		
		
		
		
		
		
		/*for (int x:a) {
			System.out.println(x);
			*/
		}

	}


