package Day7;

public class FindRepeatednumberibArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,20,60,50,10,30,20,60,30};
		//int repeated_count=0;
		
			for (int i=0;i<=a.length-1;i++) {
				for(int j=i+1;j<a.length;j++) {
					if (a[i]==a[j]) {
			
					System.out.print(a[i]+" ");
				}
			
		}
			}
	}
	
	}

	



