package Day7;

public class Duplicate_Number_Demo_1 {

	public static void main(String[] args) {
	int a[]= {10,70,30,20,40,30,10,60,70,90,83,29,56,70};
	int count=0;
	for (int i=0;i<a.length-1;i++) {
		for (int j=i+1;j<a.length;j++) 
		{	
			if(a[i]==a[j]) {
			System.out.print(a[i]+" ");	
			count++;
			break;
			}
		
		}
	}
	
	
	System.out.println("Duplicate number count is: "+ count);
	}

	

}
