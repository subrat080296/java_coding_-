package Day7;

public class SearchNumberinArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {12,90,30,35,60,30};
		int Search_number=30;
		for (int i=0;i<=a.length-1;i++) {
			if(a[i]==Search_number) {
				System.out.println(a[i]);
				break;
			}
		}

	}

}
