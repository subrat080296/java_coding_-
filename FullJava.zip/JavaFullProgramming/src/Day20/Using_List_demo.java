package Day20;
import java.util.ArrayList;
public class Using_List_demo {

	public static void main(String[] args) {
		String s="Hello";
		ArrayList<String > list=new ArrayList<>();
		
		for(int i=0;i<=20;i++) {
			list.add(s);
		}
		for(String str:list)
		System.out.println(str);

	}

}
