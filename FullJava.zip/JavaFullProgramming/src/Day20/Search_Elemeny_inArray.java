package Day20;

public class Search_Elemeny_inArray {

	public static void main(String[] args) {
		int []a= {10,15,20,25,30,40};
		int searchelement=20;
		for(int i=0;i<a.length;i++) {
			if(a[i]==searchelement) {
				System.out.println("searchelement" + a[i]);
			}
		}

	}

}
