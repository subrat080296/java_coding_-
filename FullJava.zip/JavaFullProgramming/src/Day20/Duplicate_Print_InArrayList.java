package Day20;

import java.util.HashSet;

public class Duplicate_Print_InArrayList {

	public static void main(String[] args) {
		int a[]= {10,20,20,30,10,40};
		HashSet<Integer>set=new HashSet<Integer>();
		for(int num:a) {
			if(!set.add(num)) {
		
		System.out.print(" "+ num);
		}
		}

	}

}
