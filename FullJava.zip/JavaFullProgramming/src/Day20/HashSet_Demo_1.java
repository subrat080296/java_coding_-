package Day20;

import java.util.HashSet;
import java.util.Set;

public class HashSet_Demo_1 {

	public static void main(String[] args) {
		
		//Declearation
		
	  HashSet myset=new HashSet<>();
	  
	//  Set myset=new HashSet();
	  
	 // HashSet<Integer> myset=new HashSet<>();// for specific data type<>
	  myset.add(100);
	  myset.add(10.5);

	  myset.add("abc");

	  myset.add('A');

	  
	  myset.remove(10.5);//10.5 is value not index
	  System.out.println(myset);
	  

	}

}
