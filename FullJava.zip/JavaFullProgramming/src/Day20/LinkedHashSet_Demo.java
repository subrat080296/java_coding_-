package Day20;

import java.util.LinkedHashSet;

public class LinkedHashSet_Demo {

	public static void main(String[] args) {
		LinkedHashSet<Integer>set=new LinkedHashSet<>();
		set.add(100);
		set.add(50);
		set.add(50);
		set.add(10);
		set.add(20);
		set.add(10);
		System.out.print(set);

	}

}
