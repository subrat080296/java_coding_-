package Day20;

import java.util.HashMap;

public class HashMap_Practice {

	public static void main(String[] args) {
		String s="cccaaasssbbbgg";
		HashMap<Character , Integer>map=new HashMap<>();
		for(char ch:s.toCharArray()) {
			map.put(ch, map.getOrDefault(ch, 0)+1);
			System.out.print(map);
		}

	}

}
