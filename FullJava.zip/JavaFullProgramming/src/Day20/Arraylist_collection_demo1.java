package Day20;

import java.util.ArrayList;
import java.util.Iterator;

public class Arraylist_collection_demo1 {
	

	public static void main(String[] args) {
		
		
		ArrayList mylists=new ArrayList();
		
		mylists.add(100);
		mylists.add(10.5);
		mylists.add(true);
		mylists.add(null);
		mylists.add("Ram");
		mylists.add(null);
		mylists.add(100);
		mylists.add('A');
		
		
		System.out.println(mylists);
		System.out.println(mylists.size());
		
		//Remove the elements 
		
		mylists.remove(5);
		
		System.out.println(mylists);
		System.out.println(mylists.size());
		
		//Insert element
		
		mylists.add(3,30);
		System.out.println(mylists);
		System.out.println(mylists.size());
		
		//modyfy or  replace or change
		
		mylists.set(2,"python");
		System.out.println(mylists);
		System.out.println(mylists.size());
		
		//get a specific element
		
		System.out.println(mylists.get(7));
		
		//Redeaing all elements in an Arrayslist
		
		//using for each loop
		
		for (Object ob:mylists) {
			System.out.print(ob+" ");
		}
			
			
			//Using for loop
			for (int i=0; i<mylists.size();i++) {
				System.out.println(mylists.get(i));
			}
			//using Iterator
			
			Iterator<Integer> it=mylists.iterator();// if there is some specific date type the <Integer> or<String>
			
			while(it.hasNext()){
			System.out.println(	it.next());
				
			}
			
			
			//Remove all element
			
//			Arraylist mylist5=new Arraylist();
//			
//			mylist5.add(null);
//			mylist5.add("welcome");
//			mylist5.add(100);
//			mylists.remove(mylist5);
//			System.out.println(mylists);
			
			
			mylists.clear();
			System.out.println(mylists);
	}
			
			
			
			
		}
	
	
		
		
	

	


