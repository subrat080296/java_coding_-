package Day20;
import java.util.*;
public class ArrayList_Practice_Demo {

	public static void main(String[] args) {
		ArrayList mylist=new ArrayList();
		mylist.add(null);
		mylist.add(100);
		mylist.add('A');
		mylist.add("subrata");
		mylist.add(10.5);
		mylist.add(true);
		mylist.add(10.5);
		mylist.add(null);
	//	System.out.println(mylist.size());
	//replace and reomve	
		//mylist.set(2,"Replaced by A");
	//	for(Object x:mylist) {
		//	System.out.println(x);
			//modify
		//	mylist.remove(3);
		//mylist.add(4,"abcdef");//add element
			//System.out.println(mylist);
		//	
		mylist.remove(2);
		
     //   mylist.clear();
		

			for (int i=0;i<mylist.size();i++)
			{
				System.out.println(mylist.get(i));
			}
			
		
			System.out.println(mylist.isEmpty());
			System.out.println(mylist.isEmpty());
		}
		

	}

