package Day20;

import java.util.HashSet;

public class HashSet_Test2 {

	public static void main(String[] args) {
		int a[]= {10,20,20,30,10,40,50,20,30,40,50};
		HashSet<Integer>set=new HashSet<Integer>();
		for (int i:a) {
			set.add(i);
		}
		set.remove(40);
			System.out.println(set);
		}
	}

