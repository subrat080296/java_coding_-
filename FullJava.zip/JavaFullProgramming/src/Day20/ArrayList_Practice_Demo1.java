package Day20;

import java.util.Arrays;
import java.util.HashSet;

public class ArrayList_Practice_Demo1 {

	public static void main(String[] args) {
		int a[]= {10,20,20,30,10,40};
		Arrays.sort(a);
		HashSet<Integer> set=new HashSet<Integer>();
		for(int num:a) {
			 set.add(num);
		}
		System.out.println(set);

	}

}
