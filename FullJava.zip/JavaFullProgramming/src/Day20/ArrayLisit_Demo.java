package Day20;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayLisit_Demo {

	public static void main(String[] args) {
		//Decleration
		
		ArrayList mylist1=new ArrayList();
		
	//	List mylist=new ArrayList();
	//	ArrayList<Integer> mylist=new ArrayList();
		
	//	ArrayList<String> name=new ArrayList();
		
		//ArrayList mylist;
		//add data in to arraylist
		
		
		mylist1.add(100);
		mylist1.add("Ram");
		mylist1.add('A');
		mylist1.add(10.5);
		mylist1.add(true);
		mylist1.add(null);
		mylist1.add(100);
		mylist1.add(null);
		mylist1.add(null);
		
		System.out.println(mylist1);
		System.out.println(mylist1.size());
		
		//remove the data from the arraylist
		
		mylist1.remove(8);
		
		System.out.println("new list after removing:"+ mylist1);
		
		//Insert value in to arraylist middile
		mylist1.add(2,"java");
		System.out.println("After insert the java value"+ mylist1);
		
		//modify the data in the arraylist
		
		mylist1.set(8, "python");
		System.out.println("After modify the  value"+ mylist1);
		
		//acces a target value from the array lsit
		
		mylist1.get(4);
		System.out.println("Target data is "+ mylist1.get(4));
		
		// Read all data from an arraylsit using forloop
		
		for (int i=0;i<=mylist1.size();i++) {
		//System.out.println("All arralist1 value is "+ mylist1.get(i));
		}
		
		//Get arraylist all value using for each loop
		
		for (Object x: mylist1) 
		{
	//		System.out.println(x);
		}
		
		// Read data using Iterator method
		
		Iterator it=mylist1.iterator();
		
		 while(it.hasNext())
		 {
			System.out.println(it.next()) ;
		 }
		 
		 //Checking Arraylist is Empty or not?
		 
		System.out.println( "No value is present in my array list?" + mylist1.isEmpty());
		
		

	}

}
