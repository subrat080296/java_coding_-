package Day20;

import java.util.ArrayList;
import java.util.HashSet;

public class Set_ArrayList_convert {

	public static void main(String[] args) {
		String s="ccbbsnnanns";
		HashSet<Character> set=new HashSet<>();
	
		for (char ch:s.toCharArray()) {
			System.out.print(ch);
			set.add(ch);
	
		}
		set.clear();
		System.out.println(set);
	//	System.out.println(set);
	//	ArrayList al=new ArrayList(set);
	//	System.out.println(al.get(4));
		//Clear all elements from hashset
		
		

	}

}
