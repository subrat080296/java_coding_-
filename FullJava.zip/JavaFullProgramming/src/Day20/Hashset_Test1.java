package Day20;
import java.util.*;
public class Hashset_Test1 {

	public static void main(String[] args) {
		String s="aabbccddeeffgghhii";
		HashSet<Character>myset=new HashSet<Character>();
		for(char ch:s.toCharArray()) {
			myset.add(ch);
		}
		System.out.println(myset);

	}

}
