package Day20;


import java.util.ArrayList;

public class Arraylist {

	public static void main(String[] args) {
		//Hetro genious data
		
		
		ArrayList mylist=new ArrayList();
		mylist.add(100);
		mylist.add("welcome");
		mylist.add(true);
		mylist.add('A');
		mylist.add(100);
		mylist.add(null);
		mylist.add(100);
		mylist.add(null);

	//	System.out.println(mylist.size());
		// System.out.println(mylist);
		mylist.remove(4);
		System.out.println(mylist);
		mylist.add(4,"Math");
		System.out.println(mylist);
		
	}

}
