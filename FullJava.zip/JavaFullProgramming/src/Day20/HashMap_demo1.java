package Day20;

import java.util.HashMap;

public class HashMap_demo1 {

	public static void main(String[] args) {
		// Declearation
		
		HashMap<Integer, String> hm=new HashMap<Integer, String>();
		hm.put(101, "rohon");
		hm.put(102, "rohon1");
		hm.put(103, "rohon2");
		hm.put(104, "rohon3");
		hm.put(106, "rohon4");
		hm.put(109, "rohon5");
		System.out.println(hm);
		System.out.println(hm.size());
		hm.remove(104);
		System.out.println(hm.size());
		System.out.println(hm.get(102));
		
		System.out.println(hm.keySet());//only keys
		System.out.println(hm.values());//only value
		System.out.println(hm.entrySet());//all value both key and value
	}

}
