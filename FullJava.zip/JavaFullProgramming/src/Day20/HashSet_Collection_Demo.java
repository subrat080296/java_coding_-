package Day20;
import java.util.*;
public class HashSet_Collection_Demo {

	public static void main(String[] args) {
		//Delearation
		HashSet myset=new HashSet();
		  //for String type
	//	HashSet<String> myset1=new  HashSet<String>();
		myset.add(null);
		myset.add(10.0);
		myset.add(100);
		myset.add("String");
		myset.add('A');
		myset.add(100);
		myset.add(null);
		System.out.println(myset);

	}

}
