package Day9;

public class Assignment_3_RemoveWhiteSpace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="hello java   how are you  ";
		
		String s1=s.replaceAll("\\s+","");
		//String s3=s.trim();
		System.out.println(s1);

	}

}
