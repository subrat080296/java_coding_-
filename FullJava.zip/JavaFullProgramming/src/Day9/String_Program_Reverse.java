package Day9;

public class String_Program_Reverse {

	public static void main(String[] args) {
	 String s="welcome";
	 String rev=" ";
	char a[]= s.toCharArray();
	for(int i=s.length()-1;i>=0;i--) 
	{
		rev=rev+a[i];
	}
		System.out.println(rev);
	

	}

}
