package Day9;

public class Assignment_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Remove special char
		
		String s="csvd$541&^##@#avdjn";
		
		String s3=s.replaceAll("[^a-zA-Z]","");
		
		System.out.println(s3);

	}

}
