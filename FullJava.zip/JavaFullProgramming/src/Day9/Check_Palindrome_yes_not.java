package Day9;

public class Check_Palindrome_yes_not {

	public static void main(String[] args) {
		
		
		String s="MADAM";
		String rev="";
		for (int i=s.length()-1;i>=0;i--)
		{
			rev=rev+s.charAt(i);
			

		}
		System.out.println(rev);
		if(rev.equals(s)) {
			System.out.println("pallindrome");
		}
		else {
			System.out.println("not a pallindrome");
		}

	}

}
