package Day9;

public class Reverse_String_1 {

	public static void main(String[] args) {
		
		
		String s="Hello";
		StringBuilder sb=new StringBuilder(s);
		System.out.println(sb.reverse());

	}

}
