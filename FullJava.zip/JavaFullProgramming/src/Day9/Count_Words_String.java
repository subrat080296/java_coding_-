package Day9;

public class Count_Words_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="hello  java  automation selenium";
		System.out.println(s.length());
		

	}

}
