package Day9;

public class Assignments_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//palindrome
		String s="MADAM";
		
		String s1=s.toLowerCase();
		String rev="";
		for (int i=s1.length()-1;i>=0;i--) {
			rev=rev+s1.charAt(i);
		}
		if(rev.equals(s1)) {
			System.out.println("pallindrome");
		}
		else {
			System.out.println("not pallindrome");
		}

	}

}
