package Day9;

public class Reverse_String_Stringbuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="olleH";
		StringBuffer sb1= new StringBuffer(s);
	System.out.println(	sb1.reverse());

	}

}
