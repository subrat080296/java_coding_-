package Day9;

public class Equals_Doubleequal_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//case-1
		String s="Welcome";
		String s1="Welcome";
		
		System.out.println(s==s1);
		System.out.println(s.equals(s1));
		
		
		//case 2
		
		String s2=new String("welcome");
		String s3=new String("welcome");
		
		System.out.println(s2);
		System.out.println(s3);
		
		System.out.println(s2==s3); //false  //used to compare the objects
		System.out.println(s2.equals(s3));// true  //used to compare the value of objects

	}

}
