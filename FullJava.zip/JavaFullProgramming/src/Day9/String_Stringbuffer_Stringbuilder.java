package Day9;

public class String_Stringbuffer_Stringbuilder {

	public static void main(String[] args) {
		  
		
	//	String s="Hello Java";
	//	s.concat(s);
	//	System.out.println(s);
		
		
		StringBuffer sbf=new StringBuffer("Hello");
		sbf.append("to java");
		System.out.println(sbf);

	}

}
