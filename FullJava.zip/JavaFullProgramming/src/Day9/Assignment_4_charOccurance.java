package Day9;

import java.util.HashMap;

public class Assignment_4_charOccurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="aaaabbbcccddeefs";
		HashMap<Character, Integer>map=new HashMap<>();
		
		for (char ch:s.toCharArray()) {
			map.put(ch, map.getOrDefault(ch, 0)+1);
		}
		System.out.println(map);

	}

}
