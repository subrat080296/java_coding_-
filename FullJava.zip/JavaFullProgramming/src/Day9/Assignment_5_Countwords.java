package Day9;

public class Assignment_5_Countwords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//words count
		
		String s="hello java how are you";
		String s1[]=s.split(" ");
		//for (int i=0;i<=s1.length-1;i++)
		
			System.out.print(s1.length);
		
	

	}

}
