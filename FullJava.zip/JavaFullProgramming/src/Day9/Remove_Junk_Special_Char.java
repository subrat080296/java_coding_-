package Day9;

public class Remove_Junk_Special_Char {

	public static void main(String[] args) {


		String s="s37u8*&6   b423r2a@   #$t";
		
		String s2= s.replaceAll("[^a-zA-Z]", "");
		
		System.out.println(s2);

	}

}
