package Day9;

public class Remove_White_Space {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="svb fgr  vgf  bhnj kl";
		String s1=s.replaceAll("\\s+","");
		System.out.println(s1);

	}

}
