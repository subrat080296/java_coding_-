package Day12;

public class Constructor_Demo {



	

}
