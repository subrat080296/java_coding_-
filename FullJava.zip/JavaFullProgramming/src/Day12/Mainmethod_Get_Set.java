package Day12;

public class Mainmethod_Get_Set {

	public static void main(String[] args) {
		Get_Set_Value GS=new Get_Set_Value() ;
		
			GS.setRollno(101);
			GS.setName("Mohan");
			GS.setSalaray(19909);
			
			System.out.println(GS.getRollno());
			System.out.println(GS.getName());
			System.out.println(GS.getSalaray());
			
		}
	}

	
