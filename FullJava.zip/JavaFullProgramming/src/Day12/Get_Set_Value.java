package Day12;

public class Get_Set_Value {
	private int rollno;
	private String name;
    private double salaray;
    
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalaray() {
		return salaray;
	}
	public void setSalaray(double salaray) {
		this.salaray = salaray;
	}
     

}
