package Day12;

public class Method_ov_demo {
	
	int a=90,b=10;
	
	void method1()
	{
		System.out.println(a+b);
	}
	void method1(int x, int y)
	{
		System.out.println(x+y);
	}
	void method1(int y,double x)
	{
		System.out.println(y+x);
	}
	void method1(double x, int y)
	{
		System.out.println(x+y);
	}
	

}
