package Day12;

public class Main_Account {

	public static void main(String[] args) {
		Encapsulation_Account EA=new Encapsulation_Account();
	//	EA.accno=19829;
	//	EA.name="Harisha";
	//	EA.balance=100.9;
		
		//EA.setaccno(100);
//System.out.println(EA.getaccno());
	//}
    //  EA.setname("Harish");
     // System.out.println(EA.getname());
      EA.setdouble(90000000);
     System.out.println( EA.getbal());
}
}
