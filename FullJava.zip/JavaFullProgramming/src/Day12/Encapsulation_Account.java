package Day12;

public class Encapsulation_Account 
{

	private int accno;
	private String name;
	private double balance;
	
	void setaccno(int accountnumber) {
		accno=accountnumber;
	}
		int getaccno() 
		{
			return accno;
		}
void setname(String nam) {
	name=nam;
	
}
String getname() {
	return name;
}
void setdouble(double bal) {
	bal=balance;
}
	double getbal() 
	{
		return balance;
		
	}

}
