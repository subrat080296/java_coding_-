package Day12;

public class Plymorphism {
	//Method Overloading
	
int x=10,y=20;
void sum() {
	System.out.println(x+y);
}
void sum(int x, int y) {
	System.out.println(x+y);
}
void sum(int x, double y) 
{
	System.out.println(x+y);
}
void sum(double x,int y) {
	System.out.println(x+y);
}
	public static void main(String[] args) {
		
		Plymorphism om=new Plymorphism();
		om.sum();//1
		om.sum(100,200);//2
		om.sum(20,9.5);
		om.sum(10.5, 10);

	}

}
