package Day12;

public class Main_Method {

	
	public static void main(String[] args) {
		Method_ov_demo md=new Method_ov_demo();
		md.method1();
		md.method1(10, 3);
		md.method1(6.0, 5);

	}

}
