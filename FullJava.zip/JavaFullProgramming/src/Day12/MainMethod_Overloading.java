package Day12;

public class MainMethod_Overloading {
	
	void main(int x) {
		System.out.println(x);
	}
	void main (String s)
	{
		System.out.println(s);
	}
	void main(String s1, String s2)
	{
		System.out.println(s1+s2);
	}

	public static void main(String[] args)
	{
		MainMethod_Overloading mo=new MainMethod_Overloading(); 
		
			mo.main(100);
			mo.main("raja");
			mo.main("subrata" +" Jena" );
		
	}
}
	


