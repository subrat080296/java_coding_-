package Day12;

public class Method_Overloadting_using_con {
	
	double height,width,depth;
	
	Method_Overloadting_using_con(){
		height=0;
		width=0;
		depth=0;
		//height=width=depth=0;
	
	}
	
	Method_Overloadting_using_con(double h,double w,double d ){
		height=h;
		width=w;
		depth=d;
		
	}
	Method_Overloadting_using_con(double len)
	{
	height=width=depth=len;
	}
	double volume() 
	{
		return(height*width*depth);
	}

	public static void main(String[] args) 
	{
		Method_Overloadting_using_con box=new Method_Overloadting_using_con();
		System.out.println(box.volume());

	}

}
