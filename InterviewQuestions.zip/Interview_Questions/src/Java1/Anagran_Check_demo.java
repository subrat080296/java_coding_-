package Java1;

import java.util.Arrays;

public class Anagran_Check_demo {

	public static void main(String[] args) {
		String s="listen";
		String s2="silent";
		char []ch=s.toCharArray();
		char[] ch1=s2.toCharArray();
		Arrays.sort(ch);
		Arrays.sort(ch1);
		System.out.println(Arrays.equals(ch,ch1));


	}

}
