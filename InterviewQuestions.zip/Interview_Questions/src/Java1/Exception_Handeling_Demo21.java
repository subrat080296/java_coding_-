package Java1;

public class Exception_Handeling_Demo21 {
	int a=10;
	int b=0;
	
          void display() {
          try{
       
		System.out.println(a/b);
	}
          catch(ArithmeticException e)
          {
        	  System.out.println("Exception caught: " + e.getMessage());
          }
          
          }

	public static void main(String[] args) {
		
		Exception_Handeling_Demo21 d=new Exception_Handeling_Demo21 ();
		 d.display();


	}

}
