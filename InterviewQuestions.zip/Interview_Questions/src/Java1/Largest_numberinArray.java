package Java1;

public class Largest_numberinArray {

	public static void main(String[] args) {
		int b[]= {10,23,45,67,13,89,90};
		int largest=b[0];
		for (int i=1;i<b.length;i++)
		{

			if (largest<b[i])	{
				largest=b[i];
			}
		}

				System.out.println(largest);
			}
		}






