package Java1;

public class Class_Test12
{
	int i;
	void m1() {
		for (int i=1;i<=10;i++)
		{
			System.out.print(i);
		}
	}

	void m2()
	{
		for (int i=11;i<=20;i++)
		{
			System.out.print(i);
		}
	}

	public static void main(String[] args) {
		Class_Test12 t4=new Class_Test12 ();
		t4.m1();
		t4.m2();
	//	Thread t1=new Thread((Runnable) t4);
		//Thread t2=new Thread((Runnable) t4);
		//t1.start();
	//	t2.start();


	}
	}

