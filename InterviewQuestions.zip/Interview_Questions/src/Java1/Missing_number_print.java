package Java1;
import java.util.Arrays;

public class Missing_number_print {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[]= {7,2,3,5,1,6,8};

		Arrays.sort(a);

	int missingno= a.length+1;

		for(int i=0;i<a.length;i++) {

			if(a[i]!=i +1) {
				missingno=i+1;
				break;
			}
		}
			System.out.println(missingno);


	}

}
