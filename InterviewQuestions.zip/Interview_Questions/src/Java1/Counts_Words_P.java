package Java1;

public class Counts_Words_P {

	public static void main(String[] args) {
		String s="qwertyufghj     kjhghj";
		//String count="";


		System.out.println(s.length());

	}

}
