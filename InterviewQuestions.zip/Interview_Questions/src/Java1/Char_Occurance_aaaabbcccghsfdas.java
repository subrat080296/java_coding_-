package Java1;
import java.util.HashMap;
public class Char_Occurance_aaaabbcccghsfdas {

	public static void main(String[] args) {
	  String s="aaaabbcccghsfdas";
	  
	  HashMap<Character, Integer> map=new HashMap<>();
	  
	  for(char ch:s.toCharArray()) {
		  map.put(ch, map.getOrDefault(ch, 0)+1);
	  }
	  System.out.println(map);

	}

}
