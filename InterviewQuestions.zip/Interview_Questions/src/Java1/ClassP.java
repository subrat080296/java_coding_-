package Java1;

class parent{

	String s="Parent";
}
class c extends parent
{
	String c="Child";
}
public class ClassP {

	public static void main(String[] args)
	{
		parent p2=new parent();
		System.out.println(p2.s);
		c c2=new c();
		System.out.println(c2.c);

	}

}
