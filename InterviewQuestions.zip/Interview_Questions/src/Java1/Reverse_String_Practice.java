package Java1;

public class Reverse_String_Practice {

	public static void main(String[] args) {
		String s="Selenium";
		String returnrev="";
		for(int i=s.length()-1;i>=0;i--)
		{
			returnrev=returnrev+s.charAt(i);

		}
		System.out.println(returnrev);

//	}

	StringBuffer sb= new StringBuffer(s);
	System.out.println(sb.reverse());


	StringBuilder sb1= new StringBuilder(s);
	System.out.println(sb1.reverse());

}
}