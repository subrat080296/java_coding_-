package Java1;

public class Bank_Cashwithdraw {

	public static void main(String[] args) {
		int cb=10000;
		int wb=4000;
		try {

		if(cb<wb) {
			throw new ArithmeticException();
		}
		cb=cb-wb;
		System.out.println("Transction Successfull");
		System.out.println("Current Balance:" + cb);

		}
		catch(ArithmeticException e1) {

		}


	}

}
