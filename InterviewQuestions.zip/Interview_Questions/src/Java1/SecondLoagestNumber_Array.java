package Java1;

public class SecondLoagestNumber_Array {

	public static void main(String[] args) {
		int a[]= {870,90,67,345,35428,89};
		int SecondLargest3;
		for (int i=0;i<a.length;i++)
		{
			for (int j=i+1;j<a.length;j++)
			{
				if(a[i]<a[j])
				{
					SecondLargest3=a[i];
					a[i]=a[j];
					a[j]=SecondLargest3;


				}
			}
		}
		System.out.println(a[1]);
	}

}
