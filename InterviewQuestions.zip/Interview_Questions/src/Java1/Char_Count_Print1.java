package Java1;

public class Char_Count_Print1 {

	public static void main(String[] args) {
		String s="aaaabbbccd";
		int count=1;
		
		for (int i=0;i<s.length();i++) 
		{
			if(i<s.length()-1 && s.charAt(i)==s.charAt(i+1)) {
				count++;
			}
			else {
		
		        System.out.print(s.charAt(i)+""+count);
		        count=1;
			}
	
	

}
	}
}

