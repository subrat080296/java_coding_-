package Java1;

import java.util.HashMap;

public class Duplicate_Number_Print_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {10,20,30,50,10,30};
		
			
		HashMap<Integer, Integer> map=new HashMap<>();
		
		for(int b:a) {
			map.put(b, map.getOrDefault(b, 0)+1);
		}
		for (int b:map.keySet()) {
			if(map.get(b)>1) 
			{
				System.out.println(b+"="+map.get(b));
			}
		}

	}

}
