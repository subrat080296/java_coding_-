package Java1;

import java.util.Arrays;

public class Find_2nd_largest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[]= {56,89,90,76,45,89,100};

		for (int i=0;i<a.length;i++) {
			Arrays.sort(a);
		}
			System.out.println(a[a.length-2]);
		}



}
