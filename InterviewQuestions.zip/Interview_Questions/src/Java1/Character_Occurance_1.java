package Java1;

public class Character_Occurance_1 {

	public static void main(String[] args) {
		String s1="aaassssffffghhh";
		int count=1;
		for (int i=0;i<s1.length();i++)
		{
			if(i<s1.length()-1 && s1.charAt(i)==s1.charAt(i+1)) {

				     count++;
			    //    i++;
			}

		else
		{
            System.out.println(s1.charAt(i) + " occurs " + count + " times");
            count = 1;

		//System.out.print(s1.charAt(i)  +  " occurs " + count + " times ");

		}
	}

	}
}


