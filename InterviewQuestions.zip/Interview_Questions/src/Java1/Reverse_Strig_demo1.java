package Java1;

public class Reverse_Strig_demo1 {

	public static void main(String[] args) {
		String s="Subrata";
		//String Reverse="";
		for (int i=s.length()-1;i>=0;i--){
		System.out.print(s.charAt(i));
	}

	}
}

