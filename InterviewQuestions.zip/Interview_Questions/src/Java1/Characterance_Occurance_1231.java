package Java1;
import java.util.HashMap;
public class Characterance_Occurance_1231 {

	public static void main(String[] args) {
		String s="aaaabbbccd";

		String s2=s.toLowerCase();
		HashMap<Character ,Integer> map=new HashMap<>();

		for (char ch:s2.toCharArray())
		{
			map.put(ch, map.getOrDefault(ch, 0)+1);
		}
		System.out.println(map);

	}

}
