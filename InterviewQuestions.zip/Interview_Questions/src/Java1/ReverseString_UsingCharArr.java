package Java1;

public class ReverseString_UsingCharArr {

	public static void main(String[] args) {
	String str1="Hello  JAVA";
	char[] chArr1=str1.toCharArray();
	
	
	for(int i=chArr1.length-1;i>=0;i--)
	{
		System.out.print(chArr1[i]);
	}

	}

}
