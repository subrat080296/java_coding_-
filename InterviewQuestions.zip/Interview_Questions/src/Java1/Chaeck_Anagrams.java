package Java1;

import java.util.Arrays;

public class Chaeck_Anagrams {

	public static void main(String[] args) {
		String s1="listen";
		String s2="silent";
        s1= s1.toLowerCase();
        s2 = s2.toLowerCase();
		char[] charArray1=s1.toCharArray();//Converting string to arrays
		char[] charArray2=s2.toCharArray();// do
		Arrays.sort(charArray1);//sorting the arrays
		Arrays.sort(charArray2);
		System.out.println(Arrays.equals(charArray1,charArray2));//compare both and print

	}

}
