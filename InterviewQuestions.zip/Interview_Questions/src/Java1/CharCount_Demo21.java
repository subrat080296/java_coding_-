package Java1;

public class CharCount_Demo21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="zzzzxxxvvb";
		int count=1;
		for (int i=0;i<s.length();i++) {
			if(i<s.length()-1 && s.charAt(i)==s.charAt(i+1)) {
				count++;
				
			}
			else {
				System.out.print(s.charAt(i)+"=" +count);
				count=1;
			}
		}

	}

}
