package Java1;

public class Abstart_Method {
class p{
	public void m1()
	{

	}
	abstract class d extends p{
		@Override
		public abstract void m1();
		{

		}
	}
}
}
