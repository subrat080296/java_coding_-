package Java1;

public class Divide_theSting {

	public static void main(String[] args) {
		String s="asdf8765456@#$F^^%$F#^F/???++Kjh";

	s=	s.replaceAll("[^a-zA-Z0-9]", "");

      	System.out.println(s);

     s=	s.replaceAll("[^0-9]", "");
   	System.out.println(s);

  s=s.replaceAll("[a-zA-Z0-9]","");
  System.out.println(s);
 	System.out.println(s.length());



	}

}
