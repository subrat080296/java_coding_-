package Java1;

public class SecondLargest_Element1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,20,30,40,500,70};
		int second=0;
		int first=0;
		for (int element : a) {
			if (first<element) {
				first=element;
				second=first;
			}
		}
		System.out.println(second);
	}

}
