package Java1;

public class Overloaded_1 {
	public void m1(int i)
	{
		System.out.println("Integer Method for single value");
	}
	public void m1(int...i) {
		System.out.println("Integer method for multiple value");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Overloaded_1 ob1=new Overloaded_1();
		ob1.m1(10,12,20,67);
		ob1.m1();
		ob1.m1(10);

	}

}
