package Java1;

import java.util.HashSet;

public class Remove_Duplicates_Demo121 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="abcdefabscs";
		
		HashSet<Character>set=new HashSet<>();
		
		for(char c:s.toCharArray()) {
			set.add(c);
		}
		System.out.println(set);

	}

}
