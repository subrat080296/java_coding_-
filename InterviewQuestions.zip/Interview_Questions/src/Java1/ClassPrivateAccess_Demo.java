package Java1;

public class ClassPrivateAccess_Demo {
	private int mic;
	private int cam;
	void setValue() {
		mic=2;
		cam=5;
	}
	void display(){
		System.out.println(mic);
		System.out.println(cam);
	}

	public static void main(String[] args) {
		ClassPrivateAccess_Demo cd=new ClassPrivateAccess_Demo();
		cd.setValue();
		cd.display();

	}

}
