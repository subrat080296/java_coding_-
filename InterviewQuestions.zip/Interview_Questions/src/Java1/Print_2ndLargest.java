package Java1;

import java.util.Arrays;

public class Print_2ndLargest {

	public static void main(String[] args) {
		int a[]={89,78,24,30,100};
		for (int i=0;i<a.length;i++){
		Arrays.sort(a);
		}
		System.out.println(a[a.length-2]);
		System.out.println(a[a.length-1]);

	}

}
