package Java1;

import java.util.Arrays;

public class Number_Occurance {

	public static void main(String[] args) {
		int [] arr= {4,2,5,7,4,2,5,8,91,9,3,2,3,5,18};
		int count =0;
		Arrays.sort(arr);
		for (int i=0;i<arr.length;i++) {
            while (i < arr.length - 1 && arr[i] == arr[i + 1]) {
                count++;
                i++;
		}
            System.out.println(arr[i] + " occurs " + count + " times");



				}
			}
}




