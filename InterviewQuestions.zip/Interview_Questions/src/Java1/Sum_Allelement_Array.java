package Java1;

public class Sum_Allelement_Array {

	public static void main(String[] args) {
		int a[]= {10,20,5,3,1};
		int sum=0;
		for (int element : a) {
			sum=sum+element;


			}

	System.out.println(sum);


	}

}