package Java1;

public class Check_Pallindrom {

	public static void main(String[] args) {
		String s="madam";
		String p="";
		for(int i=s.length()-1;i>=0;i--)
		{
			p+=s.charAt(i);
		}
		if(p.equals(s)) {
			System.out.print("pallinrome ");
		}
		else {
			System.out.println("not pallindrome");
		}

	}

}
