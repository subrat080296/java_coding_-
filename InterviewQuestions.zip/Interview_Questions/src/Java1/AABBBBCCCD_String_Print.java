package Java1;

public class AABBBBCCCD_String_Print {

	public static void main(String[] args)
	{


		String s="ssssssssssssssddddddddddhhhhhhhhhhllllllllllloooooooooo";
		int count=1;
		for (int i=0;i<s.length();i++)// study full first-last

		{
			if(i<s.length()-1 && s.charAt(i)==s.charAt(i+1))
			{
				count++;
				//i++;

			}
			else {


				System.out.println(s.charAt(i)  +  " occurs " + count + " times ");
				count=1;
		}

	}
}
}
