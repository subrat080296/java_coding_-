package Java1;
import java .util.Scanner;
public class ReverString_Practice {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter you Sentence");
		String s=sc.nextLine();
		char[] chArr=s.toCharArray();

		for(int i=s.length()-1;i>=0;i--)
		{
		System.out.print(chArr[i]);
		}

	}

}
