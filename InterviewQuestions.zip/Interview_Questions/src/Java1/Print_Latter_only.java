package Java1;
import java.util.Arrays;
public class Print_Latter_only {

	public static void main(String[] args) {
		String s1="!@#               $12TR                *&$U% U                 E09sesaA_!!";
		System.out.println(s1.length());
	//	String p=s1.replaceAll("[^TU@UR!]","");
		
		String s2[]=s1.trim().split("\\s+");
		System.out.println(Arrays.toString(s2));

	}

}
