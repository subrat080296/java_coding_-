package Java1;

public class Java_OverRiding {
	public void m1()
	{
		System.out.println("Parents is final");
	}
            class c extends Java_OverRiding
            {
	         @Override
			public void m1()
	{
		System.out.println("Child is not final");
	}
}
	public static void main(String[] args) {
		Java_OverRiding f= new Java_OverRiding();
		f.m1();
		//f.m2();

	}

}
