package Java1;
import java.util.HashMap;
public class Accurance_demo10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="Automation";
		String s1=s.toLowerCase();
		HashMap<Character ,Integer>  map=new HashMap<>();

		for(char ch:s1.toCharArray()) {
			map.put(ch, map.getOrDefault(ch , 0)+1);
		}
		System.out.println(map);

	}

}
