package Java1;

public class CountWords_Withoud_Space {

	public static void main(String[] args) {
		String s="qwertyufghj         kjhghj";
		int count=0;
		for  (int i=0;i<s.length();i++)
		{
			if (s.charAt(i)!=' ')
			{
				count ++;

			}
		}
			System.out.print(count);


	}

}
