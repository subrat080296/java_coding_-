package Java1;

public class FibonacciSeries_15 {

	public static void main(String[] args) {
		int x=0,y=1;
		int count=15;
		int z;
		System.out.print(x+y);

		for(int i=2;i<count;i++) {
			z=x+y;
			System.out.print(" " +z);
			x=y;
			y=z;
		}

	}

}
