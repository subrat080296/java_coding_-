package Java1;

public class Reverse_String_12 {

	public static void main(String[] args) {
		String s="mohonlal";

		for(int i=s.length()-1;i>=0;i--)
		{
			System.out.print(s.charAt(i));
		}

	}

}
