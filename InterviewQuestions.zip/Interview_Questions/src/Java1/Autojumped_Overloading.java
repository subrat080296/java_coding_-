package Java1;

public class Autojumped_Overloading {
	public void m1() {
		System.out.println("no arg method");
	}
	public void m1(String s) {
		System.out.println("String argument");

	}
	public void m1(float f) {
		System.out.println("Float type method");
	}
	public void m1(int a) {
		System.out.println("int type method");
	}

	public static void main(String[] args) {
		Autojumped_Overloading aj=new Autojumped_Overloading();
		aj.m1();
		aj.m1(10);
		//aj.m1(10.5);
		aj.m1('a');
		aj.m1(10.5f);
		aj.m1(null);

	}

}
