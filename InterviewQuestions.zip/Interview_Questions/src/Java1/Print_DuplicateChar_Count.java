package Java1;

import java.util.HashMap;

public class Print_DuplicateChar_Count {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="Automation";
		
		String s1=s.toLowerCase();
		int count=1;
		
		HashMap<Character , Integer> map=new HashMap<>();
		
		for(char ch:s1.toCharArray()) {
			map.put(ch, map.getOrDefault(ch, 0)+1);
		}
		for(char ch:map.keySet()) {
		if(map.get(ch)>1) {
		System.out.println(ch +" "+map.get(ch));
		}
		}
	}

}
