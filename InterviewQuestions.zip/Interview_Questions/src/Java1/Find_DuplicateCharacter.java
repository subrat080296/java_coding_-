package Java1;

public class Find_DuplicateCharacter {

	public static void main(String[] args) {
		String s="Tiger running";
		int count=1;
		char[] ch=s.toCharArray();
		for (int i=0;i<s.length();i++)
		{
			if(i<s.length()-1 && s.charAt(i)==s.charAt(i+1))
			{
				count++;
			}

			System.out.print(i);

			}
		}

	}


