package Java1;

public abstract class Abstract_Method_Vachile
{
	public abstract int getNoOfWheels();


	public static void main(String[] args) {
	class bus extends Abstract_Method_Vachile{
		@Override
		public int getNoOfWheels()
		{
			return(6);
		}

	}

	}

}
