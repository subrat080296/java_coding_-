package Java1;

public class Fibonacci_Series {

//finbonacci series for first 10 digits
	public static void main(String[] args) {
		int a=0,b=1;

		System.out.print(a+" "+b);
		int c;
		for (int i=2;i<=10;i++)
		{
			c=a+b;
			System.out.print(" "+c);
			a=b;
			b=c;

		}



}

}
