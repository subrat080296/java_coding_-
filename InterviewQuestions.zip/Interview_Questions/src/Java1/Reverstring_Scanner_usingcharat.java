package Java1;
import java.util.Scanner;
public class Reverstring_Scanner_usingcharat {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter youa word");
		String name = sc.nextLine();
		char[] chArr=name.toCharArray();
		for(int i=name.length()-1;i>=0;i--) {
			System.out.print(chArr[i]);
		}

	}

}
