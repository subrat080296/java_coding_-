package Java1;

public class Overloading_Stringbuffer {
		public void m1() {
			System.out.println("string a");
		}
		public void m1(String s) {
			System.out.println("StringBuffer b");
		}


	public static void main(String[] args) {
		Overloading_Stringbuffer obf= new Overloading_Stringbuffer();
		obf.m1("Ram");
	}

}
