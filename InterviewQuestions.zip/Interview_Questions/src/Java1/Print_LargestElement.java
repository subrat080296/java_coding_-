package Java1;

public class Print_LargestElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,20,30,40,50,59};
		int max11=0;
		for (int element : a) {
		if(max11<element)
		{
			max11=element;
		}
		}
		System.out.println(max11);


	}

}
