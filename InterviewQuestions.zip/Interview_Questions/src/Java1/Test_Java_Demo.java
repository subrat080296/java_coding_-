package Java1;

import java.util.HashMap;
import java.util.Map;

public class Test_Java_Demo {
public static void m1(String s) {
//	String s="test";{

		Map<Character, Integer> hm = new HashMap<>();
		char[] ch=s.toCharArray();
		for( char hm1:ch) {
			if(hm.containsKey(hm1))
			{
				hm.put(hm1,hm.get(hm1)+1);

			}
			else {
				hm.put(hm1,1 );
			}

		}
		System.out.println(s+":"+hm);
	}
	//System.out.println(s+":"+hm);

	public static void main(String[] args) {
		m1("test");
		m1("aabbbccccddddddddddrrrrrrrrrrr");




	}

}
