package Java1;

public class Check_UniqueCharacter_Demo {

	public static void main(String[] args) {
		String s="abcdef";

		if (s.length()>128) {
			System.out.println("Not a Unique number");
		}
		for (int i=0;i<s.length();i++)
		{
			for (int j=i+1;j<s.length();j++)
			{

		  if(s.charAt(i)==s.charAt(j))
		  {
			  System.out.println("Not a Unique number");
			  return;
		  }
      	}

		}
		 System.out.println("Character is  Unique number");
	}

}
