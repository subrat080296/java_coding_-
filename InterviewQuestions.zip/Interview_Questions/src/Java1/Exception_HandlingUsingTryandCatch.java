package Java1;

import java.nio.channels.AlreadyBoundException;

public class Exception_HandlingUsingTryandCatch {

	public static void main(String[] args) {
		System.out.println("A");
		String s=null;
		try {
			System.out.println(s.length());
		}
		catch(ArithmeticException e1) {

		}
		catch(AlreadyBoundException e1) {

		}
		finally
		{

		System.out.println("b");
		}
	}

}
