package Java1;

public class Find_LargestNumberInArray {

	public static void main(String[] args) {
		int a[]= {10,89,45,230,19};
		int max=0;
		for (int element : a) {
			if(max<element)
			{
			max=element;
			}

		}
		System.out.println(max);

	}

}
