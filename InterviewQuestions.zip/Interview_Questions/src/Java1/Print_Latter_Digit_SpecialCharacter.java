package Java1;

public class Print_Latter_Digit_SpecialCharacter {

	public static void main(String[] args) {
		String s2="tf!!ghgf$$ghugDDF%%wj453427###@23162fddff";

		String Latter=s2.replaceAll("[^A-Za-z]","");
		System.out.println(Latter);
		System.out.println("Total Latter is:"+ Latter.length());
		String number1=s2.replaceAll("[^0-9]", "");
		System.out.println(number1);
		System.out.println("Total number is:"+ number1.length());
		String SPC=s2.replaceAll("[A-Za-z0-9]", "");
		System.out.println(SPC);
		System.out.println(SPC.length());

	}

}
