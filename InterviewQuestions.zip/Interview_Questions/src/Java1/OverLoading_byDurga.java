package Java1;

public class OverLoading_byDurga {
	void m1(String s) {
		//String s;
		System.out.println(s);
	}
	void m2(int x) {

		//int age;
		System.out.println(x);
	}

	public static void main(String[] args) {
		OverLoading_byDurga od=new OverLoading_byDurga();
		od.m1("ram");
		od.m2(18);



	}

}
