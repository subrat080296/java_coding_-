package Java1;
public class Accaes_Private_accesswithoutcreate_Object
{
     private static int x;
        static void f1() {
	          x=5;
	          System.out.println(x);
}

	public static void main(String[] args) {
		Accaes_Private_accesswithoutcreate_Object.f1();

	}

}
