package Java1;

public class Reverse_String123 {

	public static void main(String[] args) {
		String s="Level";
		StringBuilder reveredString=new StringBuilder(s);
		reveredString.reverse();
		System.out.println(reveredString);
		if(s.equals(reveredString))
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("else");
		}

	}

}
