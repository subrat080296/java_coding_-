package Java1;

public class Sum_Allelement_Array1 {

	public static void main(String[] args) {
	int a[]= {500,1000,2000,300};
	int sum=0;
	for (int element : a) {
		sum=sum+element;
	}
	System.out.println(sum);

	}

}
