package Java1;


import java.util.Arrays;

public class Anagram_Demo {

	public static void main(String[] args) {
		String s1="listen";
		String s2="Silentj";
		if(s1.length()!=s2.length()) {
			System.out.println("Not anagram");
		}
		s1=s1.toLowerCase();
		s2=s2.toLowerCase();
		char[] ar=s1.toCharArray();
		char[] arr1=s2.toCharArray();
		Arrays.sort(ar);
		Arrays.sort(arr1);
		System.out.println(Arrays.equals(ar, arr1));

	}

}
