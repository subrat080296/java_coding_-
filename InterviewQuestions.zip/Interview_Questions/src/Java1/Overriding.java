package Java1;

public class Overriding {

public void p1(int...i)
{

	System.out.println ("Parent");

 }
class c extends Overriding {
	public void p1(int i)
	{
		System.out.println("child");
	}

	public static void main(String[] args) {
		Overriding ob2=new Overriding();
		ob2.p1(10,20);
		//ob2.c1(10);

	}

}
}
