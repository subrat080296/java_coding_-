package Java1;

public class Vowels_Count_1 {

	public static void main(String[] args) {
		String s="ertyjvfgjbvhnauiseniusg34567";
	String	vowelcount=s.replaceAll("[^aeiouAEIOU]", "");
	System.out.println(vowelcount);
	int count=vowelcount.length();
	System.out.println("vowel count is: "+count);

	}

}
