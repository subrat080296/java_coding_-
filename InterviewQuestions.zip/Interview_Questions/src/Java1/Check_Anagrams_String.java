package Java1;
import java.util.Arrays;
public class Check_Anagrams_String {

	public static void main(String[] args) {
		String s10="listen";
		String s11="silent";
		char[] ch1=s10.toCharArray();
		char[] ch2=s11.toCharArray();
		Arrays.sort(ch1);
		Arrays.sort(ch2);
		System.out.println(Arrays.equals(ch1,ch2));

	}

}
