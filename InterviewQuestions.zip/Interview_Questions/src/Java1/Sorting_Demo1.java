package Java1;
import java.util.Arrays;

public class Sorting_Demo1 {

	public static void main(String[] args) {

		String s[]={"scr","abc","gbf","hvg","iop","rse"};

		System.out.println("Before soprting:"+ Arrays.toString(s));
		Arrays.sort(s);
		System.out.println("After soprting:" +Arrays.toString(s));

	}

}
