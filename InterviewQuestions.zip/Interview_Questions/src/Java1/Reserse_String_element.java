package Java1;

public class Reserse_String_element {

	public static void main(String[] args) {
		String s="Ramayan";

		StringBuilder reversedString=new StringBuilder(s);
		reversedString.reverse();
		//for (int i=0;i<s.length()-1;i--) {

		//int i;
	//	reversed.append(s.charAt(i));

		System.out.println(reversedString);

	}

}
