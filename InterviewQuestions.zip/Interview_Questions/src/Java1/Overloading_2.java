package Java1;

public class Overloading_2 {
	public void m1(int i ,float f) {
		System.out.println("Integer+Float value will print");
	}
	public void m1(float f,int i) {
		System.out.println("Float + Integer value will print");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Overloading_2 o=new Overloading_2();
		o.m1(10, 10.5f);
		o.m1(10.f, 10);
		//o.m1(10,10);
		//o.m1(10.f, 10.f);

	}

}
