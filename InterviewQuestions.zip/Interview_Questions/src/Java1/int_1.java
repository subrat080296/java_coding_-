package Java1;

public class int_1 {

	private static final String Parse = null;

	public static void main(String[] args) {
		String s="234567tfjdfrtygh@@56t";
		String no=s.replaceAll("[^0-9]" ,"");
		int number=Integer.parseInt(no);
		System.out.println(number);
		int sum=0;
		int digits=0;
		int rem=0;
		for (int i=0;i<no.length();i++)
		{
			rem=number%10;
			sum=sum+rem;

			number=number/10;

		}
		System.out.print("sum of all digits is: "+ sum);


	}

}
