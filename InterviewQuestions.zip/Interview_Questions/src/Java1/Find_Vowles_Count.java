package Java1;

public class Find_Vowles_Count {

	public static void main(String[] args) {
		String s="hello";
		int count=0;
		for(int i=0;i<s.length();i++)
		{
			char ch=s.charAt(i);
			if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
				System.out.print(ch+"");
				count++;


			}
		}

		System.out.println("  "+ "total vowel countis:"+count);


	}

}
