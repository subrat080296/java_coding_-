package Java1;

import java.util.HashMap;

public class PrintOnly_DuplicateChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="aAbBcCdDeEfnmhgaoFgG";
		String s2=s.toLowerCase();
		
		HashMap<Character,Integer> map=new HashMap<>();
		
		for(char ch:s2.toCharArray()) {
			map.put(ch,map.getOrDefault(ch, 0)+1);
		}
		
		for (char ch:map.keySet()) 
		{
			if(map.get(ch)>1) {
				System.out.print(ch+"="+ map.get(ch));
			}
		}

	}

}
