package Java1;

public class Count_Vowels_asdfghjkjhgfdsdfg {

	public static void main(String[] args) {
		String s="sedfughjkcazeigudao";
		int count=0;
		s=s.toLowerCase();
		for(int i=0;i<s.length();i++) {
			char ch=s.charAt(i);
			if(ch=='a'|| ch=='e'|| ch=='i'||ch=='o' ||ch=='u')

			{

				System.out.print(ch+" ");
				count++;

		             }
		           }
		            System.out.println();
			System.out.print("total vowel count is: "+ count);

	}

}

