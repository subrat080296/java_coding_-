package Java1;

public class ReverseWord_demo_123 {

	public static void main(String[] args) {
		String s="hello java python";
		 String s1[]=s.split(" ");
		 
		 for (int i=s1.length-1;i>=0;i--) {
			 System.out.println(s1[i]+"");
			 
		 }

	}

}
