package Java1;
class Test2{


 void m1() {
	 int a[]= {1,2,3,4,5};

}
void m2() {
	int b[]= {6,7,8,9,10};
}
public class Merge_twoarray {

	public static void main(String[] args) {
		Test2 t=new Test2();
		t.m1();
		t.m2();

	}



	}

}
