package Java1;

public class Doubleequal_dotequal_Compare {

	public static void main(String[] args) {
		String s=new String("Nami");
		String s1=new String("Nami");
		System.out.println(s==s1);
		System.out.println(s.equals(s1));

	}

}
