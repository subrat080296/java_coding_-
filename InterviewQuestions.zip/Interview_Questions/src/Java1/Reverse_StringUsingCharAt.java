package Java1;

public class Reverse_StringUsingCharAt {

	public static void main(String[] args) {
	String str="inabmaatiN";
	//int length=str.length();

	char[] chArr=str.toCharArray();


	for(int i=chArr.length-1;i>=0;i--)
	{
		System.out.print(chArr[i]);
		//break;
	}

	}

}
