package Java1;

public class Print_true {

	public static void main(String[] args) {
		String s1="!@#$12TR*&$U%E09_!!";

		for(int i=0;i<s1.length();i++)
		{
			if(s1.contains("TR") && s1.contains("U") && s1.contains("E"))
			{
				System.out.println(s1);

			break;
			}
		}

	}

}
