package Java1;

import java.util.Arrays;

public class AnagramCheck_1 {

	public static void main(String[] args) {
		String s1="Silent";
		String s2="Listen";

		String s3=s1.toLowerCase();
		String s4=s2.toLowerCase();

		if(s3.length() !=s4.length()) {
			System.out.println("its not a anagram");
		}

		char ch[]=s3.toCharArray();
		char ch1[]=s4.toCharArray();
		Arrays.sort(ch);
		Arrays.sort(ch1);

		if (Arrays.equals(ch ,ch1)) {
			System.out.println("its anagram");
		}


	}

}
