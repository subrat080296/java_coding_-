package Java1;

public class Char_Count1 {

	public static void main(String[] args) {
		String str="ssssssssssssssddddddddddhhhhhhhhhhllllllllllloooooooooo";
		int count1=1;
		for(int i=0;i<str.length();i++)
		{
			if (i<str.length()-1 && str.charAt(i)==str.charAt(i+1))
			{
				count1++ ;
			}
			else {
				System.out.println(str.charAt(i)  +  " occurs " + count1 + " times ");
				count1=1;
			}



		}

	}

}
