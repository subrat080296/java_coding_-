package Java1;

public class Remove_Duplicate_Char {

	public static void main(String[] args) {
		String s="subrata";
		int count=1;
		for (int i=0;i<s.length();i++) {
			if(s.charAt(i)==i) {
				count++;
			}

		System.out.println(s.charAt(i)+ count);

	}
	}
}




