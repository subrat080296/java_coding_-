package Java1;

public class Factorial_2 {

	public static void main(String[] args) {
		int nu=5;
		int factorial=1;
		for (int i=1;i<=nu;i++)
		{
			factorial=factorial*i;
		}
		System.out.println(factorial);

	}

}
