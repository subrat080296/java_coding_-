package Java1;

public class SecondLargest_Number {

	public static void main(String[] args) {
		int a[]= {56,89,35,80,820,110,100};
		int secondlargest2;
		for (int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if (a[i]<a[j])
				{
				secondlargest2=a[i];
				a[i]=a[j];
				a[j]=secondlargest2;
			}

			}
		}

       System.out.println(a[1]);
		}

}
