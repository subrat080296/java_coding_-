package Java1;

public class Summof_Array {

	public static void main(String[] args) {
		int a[]= {1,2,3,4,5,6,7};
		int sum=0;
	for (int element : a) {
		sum=sum+element;
	}
		System.out.println(sum);


		}

	}


