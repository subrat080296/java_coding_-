package Java1;

public class Missingno_Inan_Array {

	public static void main(String[] args) {
		int a[]= {1,2,4,9};
		
		for (int i=0;i<a.length-1;i++) {
			if(a[i+1]!=a[i]+1)
			{
				for(int j=a[i]+1;j<a[i+1];j++) {


				System.out.print(j);
				}
			}
		}

	}

}
