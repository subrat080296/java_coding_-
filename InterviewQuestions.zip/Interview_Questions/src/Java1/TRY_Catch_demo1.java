package Java1;

public class TRY_Catch_demo1 {
	
	int x=90;
	int y=0;
	String z="abc";
	int c=10;
	void m1() {
		try {
		System.out.println(x/y);
	}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		}
	void m2() {
		System.out.println(x/c);
	}
	
	void m3()
	{
		try {
		System.out.println(9/0);
	}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TRY_Catch_demo1 d1=new TRY_Catch_demo1();
		d1.m1();
		d1.m2();
		d1.m3();

	}

}
