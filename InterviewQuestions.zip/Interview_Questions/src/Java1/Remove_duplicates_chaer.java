package Java1;

import java.util.HashSet;

public class Remove_duplicates_chaer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="subratasass";
		
		
		HashSet<Character> set=new HashSet<>();
		for (char ch: s.toCharArray()) {
		if(	set.add(ch)) {
		
		
		System.out.print(set);
		}
		}
	
		

	}

}
