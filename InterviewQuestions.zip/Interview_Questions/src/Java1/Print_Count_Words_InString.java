package Java1;

public class Print_Count_Words_InString {

	public static void main(String[] args) {
		String s1="ZZZZZZZZCCCCBBBBSSSS";
		int count=0;
		for (int i=0;i<s1.length();i++) {
			if(i<s1.length()-1 && s1.charAt(i)==s1.charAt(i+1)) {
				count++;
			}
			else {
				System.out.print(s1.charAt(i)+""+count);
				count=1;
			}
		}
	}
}
