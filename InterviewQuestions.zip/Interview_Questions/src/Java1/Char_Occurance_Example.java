package Java1;

public class Char_Occurance_Example {

	public static void main(String[] args) {

		String s="aaasssddggfghjkjj";
		int ct=1;

		for (int i=0;i<s.length();i++) {
			if(i<s.length()-1 && s.charAt(i)==s.charAt(i+1)){

				ct++;
			}
			else {
				System.out.print(s.charAt(i)+""+ct);
				ct=1;
		}


	}

}
}
