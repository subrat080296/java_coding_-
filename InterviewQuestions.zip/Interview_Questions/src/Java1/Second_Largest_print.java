package Java1;

import java.util.Arrays;

public class Second_Largest_print {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int []a= {10,30,20,50,30,40};
		
//for (int i=0;i<a.length-1;i++) {
	Arrays.sort(a);
	System.out.print(a[a.length-2]);
}
	}


