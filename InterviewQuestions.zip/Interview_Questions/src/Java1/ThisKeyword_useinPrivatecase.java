package Java1;

class test20
{
	private int x,y;
	void m1(int x,int y)
	{
	this.	x=x;
	this.y=y;
	}
		void display() {
			System.out.println(x);
			System.out.println(y);
	}

}

public class ThisKeyword_useinPrivatecase {

	public static void main(String[] args) {
		test20 t1=new test20();
		t1.m1(5, 6);
		t1.display();

		}

	}


