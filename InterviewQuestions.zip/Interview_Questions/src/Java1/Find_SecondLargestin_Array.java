package Java1;

public class Find_SecondLargestin_Array {

	public static void main(String[] args) {
		int a[]= {120,90,670,34,27,76};
		int secondlargest;
		for (int i=0;i<a.length;i++)
		{
			for (int j=i+1;j<a.length;j++)
			{
				if (a[i]<a[j]) {
					;
				}
				{
					secondlargest=a[i];
					a[i]=a[j];
					secondlargest=a[j];
				}
			}
		}

			System.out.println(a[1]);
		}
	}


