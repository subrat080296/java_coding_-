package Java1;

public class Character_Count_From_String {

	public static void main(String[] args) {
		String s2="fffcccxxxzzzbbnnmmllkkjooiiuuytr";
		int count2=1;

		for(int i=0;i<s2.length();i++)
		{
			if(i<s2.length()-1 && s2.charAt(i)==s2.charAt(i+1))
			{
				count2++;
			}


			else
			  {
				System.out.println(s2.charAt(i)  +  " occurs " +   count2   +  " times");

				count2=1;
			}
		}

	}

}
