package Java1;

public class Run_Menthods_class {
	static void m1() {
		System.out.println("ram");
	}
	static void m2() {
		System.out.println("hori");
	}

	public static void main(String[] args) {
			System.out.println("jena");
			m1();
		//	m2();
		}

	}


