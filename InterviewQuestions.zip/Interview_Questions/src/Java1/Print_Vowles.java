package Java1;

public class Print_Vowles {

	public static void main(String[] args) {
		String s="eghdhjdbxnhnnsoU";
	int count=0;
		String voweles=s.replaceAll("[^aeiouAEIOU]","");
		System.out.println("Present vowel is :"+ voweles);
		//count=voweles.length();
		System.out.println("Present vowel is :"+ voweles.length());

	}

}
