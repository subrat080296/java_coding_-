package Java1;

public class String_Stringbuffer {

	public static void main(String[] args) {
		String s=new String("Durga");
		s.concat("Software");
		System.out.println(s);

	}

}
