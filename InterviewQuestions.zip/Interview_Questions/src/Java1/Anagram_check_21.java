package Java1;

import java.util.Arrays;

public class Anagram_check_21 {

	public static void main(String[] args) {
		 String s="Listen";
		 String s2="Silent";
		 String s3=s.toLowerCase();
		 String s4=s2.toLowerCase();
		 if(s3.length()!=s2.length()) {
			 System.out.println("Its not a anagram");
			
		 }
		 
		 char s5[]= s3.toCharArray();
		char s6[]=s4.toCharArray();
		
		Arrays.sort(s5);
		Arrays.sort(s6);
		
		if(Arrays.equals(s5, s6)) {
			System.out.println("its a pallindrome");
		}

	}

}
