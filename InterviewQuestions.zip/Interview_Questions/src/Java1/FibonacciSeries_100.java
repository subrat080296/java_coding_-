package Java1;

public class FibonacciSeries_100 {

	public static void main(String[] args) {
		int a=0,b=1;
		int count=100;
		int f;
		System.out.print(a+" "+b);
		for (int i=2;i<count;i++)
		{
			f=a+b;
			System.out.print(" " +f);
			a=b;
			b=f;
		}

	}

}
