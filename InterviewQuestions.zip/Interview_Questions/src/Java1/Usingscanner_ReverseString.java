package Java1;
import java.util.Scanner;
public class Usingscanner_ReverseString {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name");
		String input= sc.nextLine();
		StringBuilder reversedString=new StringBuilder(input);
		reversedString.reverse();
		System.out.println(reversedString);

		if(input.equals(reversedString))
		{
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}


	}

}
