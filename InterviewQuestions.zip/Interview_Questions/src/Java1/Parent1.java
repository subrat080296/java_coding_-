package Java1;
class test1{

	public void m1(int...i) {
		System.out.println("Parent of");
	}
}
	class C extends test1{
		public void m1(int i)
		{
			System.out.println("Child oigfhj");
		}
	}

		public class Parent1 {

	public static void main(String[] args) {
		test1 p=new test1();
		p.m1(10,10);


	}
		}




