package Java1;

import java.util.Arrays;

public class Number_Occurance_demo1 {

	public static void main(String[] args) {
	 int [] ar= {23,87,45,90,53,27,27,23};
	 int cnt=1;
	 Arrays.sort(ar);
	 for(int i=0;i<ar.length;i++)
	 {
		 if(i<ar.length-1 && ar[i]==ar[i+1])
		 {
			 cnt++;

		 }
		  System.out.println(ar[i] + " occurs " + cnt + " times");
		 }
	 }

	}


