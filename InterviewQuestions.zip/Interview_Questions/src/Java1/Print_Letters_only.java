package Java1;

public class Print_Letters_only {

	public static void main(String[] args) {
	String s1="!@#$12TR*&$U%E09_!!";
	String Latter=s1.replaceAll("[^A-Za-z]","");//replaceAll("[^A-Za-z]", "") removes everything except letters.
	System.out.println(Latter);
	System.out.println(Latter.length());
	String number=s1.replaceAll("[^0-9]","");//replaceAll("[^0-9]", "") removes everything except digits.
	System.out.println(number);
	System.out.println(number.length());
	String specialc =s1.replaceAll ("[A-Za-z0-9]", "");//  replaceAll("[A-Za-z0-9]", "") removes all letters and digits, leaving only special characters.
	System.out.println(specialc);
	System.out.println(specialc.length());

	}

}
