package Java1;

public class Jaaaaaaaaaaaa {

	public static void main(String[] args) {
	System.out.println("Hello.............");

	}

}
