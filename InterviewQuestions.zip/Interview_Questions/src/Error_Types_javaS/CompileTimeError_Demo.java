package Error_Types_javaS;

public class CompileTimeError_Demo {

	public static void main(String[] args) {
	System.out.println("Hello");

	}

}
