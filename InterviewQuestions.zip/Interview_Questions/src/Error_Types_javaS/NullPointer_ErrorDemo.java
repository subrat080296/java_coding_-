package Error_Types_javaS;

public class NullPointer_ErrorDemo {

	public static void main(String[] args) {
		int result=10/0;
		System.out.println(result);

	}

}
