package I_PracticeSet_1;

public class Method_Hiding_demo {

	public static void main(String[] args) {
		System.out.println("Hello Java");

	}



	class Child extends Method_Hiding_demo{
		public static void main(String[] args)
		{
			System.out.println("its method hiding");
		}
	}
}

