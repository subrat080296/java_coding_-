package I_PracticeSet_1;

public class Stringwert {

	public static void main(String[] args) {
	String s="a";
  System.out.println(s);
	}

}
