package I_PracticeSet_1;
import java.util.Arrays;
public class SmallNo_Array {

	public static void main(String[] args) {
		int b[]= {5,10,20,30,40,50,60,90,80};
		Arrays.sort(b);
		System.out.println(b[0]);
	}

}
