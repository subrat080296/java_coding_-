package I_PracticeSet_1;

public class Convert_Upper_Lower {

	public static void main(String[] args) {
		String s="ASDFGHJ";
		s=s.toLowerCase();
		System.out.println(s);

	}

}
