package I_PracticeSet_1;

public class Missing_Number_Array {

	public static void main(String[] args) {
		 int a[]= {1,2,4,5,7,8,10};
		 int mn=0;
		 for(int i=0;i<a.length-1;i++)
		 {
			 if(a[i]!=a[i]+1)
			 {
				 for(int j=a[i]+1;j<a[i+1];j++)
				 {
					 System.out.print(" "+j);
				 }

			 }

		 }

	}

}
