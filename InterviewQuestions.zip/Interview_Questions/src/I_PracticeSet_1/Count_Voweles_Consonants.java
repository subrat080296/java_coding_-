package I_PracticeSet_1;

public class Count_Voweles_Consonants {

	public static void main(String[] args) {
		String s="Autooomation";
		s=s.toLowerCase();
		String s2=s.replaceAll("[^aeiou]","");

		int s3=s.length()-s2.length();


		System.out.println(s2+"  "+s2.length());
	//	System.out.println(s.length()-s2.length());

		System.out.println("constant:"+ s3);


	}

}
