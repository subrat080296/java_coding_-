package I_PracticeSet_1;

public class Frequency_Of_Arrays_1 {

	public static void main(String[] args) {
		int a[]= {7,3,4,8,2,39,65,7,2,3,7};
		int count =1;
		for (int i=0;i<a.length;i++) {
			if(a[i]==a[i+1])
			{
				count++;
			}

			System.out.println(a[i]+" "+count);
		}

	}
}


