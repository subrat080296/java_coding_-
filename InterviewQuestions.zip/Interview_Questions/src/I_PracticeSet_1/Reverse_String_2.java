package I_PracticeSet_1;

public class Reverse_String_2 {

	public static void main(String[] args)
	{
		String s="PIRUMOHON MAL";
		for(int i=s.length()-1;i>=0;i--)
		{
			System.out.print(s.charAt(i));

		}
	}

}
