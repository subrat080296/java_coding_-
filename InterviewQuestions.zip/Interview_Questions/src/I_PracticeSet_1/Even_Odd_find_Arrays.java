package I_PracticeSet_1;

public class Even_Odd_find_Arrays {

	public static void main(String[] args) {
		int []a= {12,67,34,89,67,39,90,62,1};
		for (int num:a) {
			if (num%2==0) {
				System.out.println(num + " is even");
			}
			else {
				System.out.println(num +" is odd");
			}
		}

	}

}
