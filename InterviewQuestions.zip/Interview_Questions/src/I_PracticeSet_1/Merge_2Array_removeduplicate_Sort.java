package I_PracticeSet_1;

import java.util.TreeSet;

public class Merge_2Array_removeduplicate_Sort {

	public static void main(String[] args) {
		int a[]= {12,78,54,34,10,12};
		int b[]= {10,67,34,97,12,54};

		TreeSet<Integer> set=new TreeSet<>();

		for (int num:a)
		{
		set.add(num);
		}
		for(int num:b)
		{
		set.add(num);
		}
//		for(int num:set)
//		{
			System.out.print( set);
		}
		}





