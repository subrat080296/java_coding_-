package I_PracticeSet_1;

public class Duplicate_Char_Print {

	public static void main(String[] args) {
		String s="abcdefabc";
		for (int i=0;i<s.length();i++)
		{
			for (int j=i+1;j<s.length();j++)
			{
				if(s.charAt(i)==s.charAt(j))
				{
					//System.out.print(s.charAt(i));
					char c=s.charAt(i);
					String c1=s.replaceAll("['dhjn']","");
					System.out.print(c1);
				}
			}
		}

	}

}
