package I_PracticeSet_1;

public class Reverse_String_withoutBuiltin_function {

	public static void main(String[] args) {
		String s="abcdefg";
		for(int i=s.length()-1;i>=0;i--)
		{
			System.out.print(s.charAt(i));
		}

	}

}
