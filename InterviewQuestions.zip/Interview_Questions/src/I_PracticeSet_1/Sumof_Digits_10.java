package I_PracticeSet_1;

public class Sumof_Digits_10 {

	public static void main(String[] args) {
		int a=123456;
		int digit=0;
		int sum=0;
		while(a>0)
		{
			digit=a%10;
			sum=sum+digit;
			a= a/10;
		}
		     System.out.println(sum);

	}

}
