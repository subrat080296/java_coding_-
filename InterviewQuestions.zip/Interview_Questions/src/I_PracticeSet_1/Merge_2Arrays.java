package I_PracticeSet_1;

public class Merge_2Arrays {

	public static void main(String[] args) {
		int a[]= {13,78,54,90,20};
		int b[]= {34,67,20,67,87};

		int c[]=new int[a.length+b.length];
		for(int i=0;i<a.length;i++) {
			c[i]=a[i];
		}
		for (int i=0;i<b.length;i++) {
			c[a.length+i]=b[i];
		}
		for(int num:c) {
			System.out.print(" "+num);


		}

	}

}
