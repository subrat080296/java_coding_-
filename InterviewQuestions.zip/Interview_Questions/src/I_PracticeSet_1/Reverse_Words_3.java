package I_PracticeSet_1;

public class Reverse_Words_3 {

	public static void main(String[] args) {
		String s3="pirumohon mal";
		String [] s4=s3.split(" ");
		for(int i=s4.length-1;i>=0;i--)
		{
			System.out.print(s4[i]+" ");
	}

	}

}
