package I_PracticeSet_1;

import java.util.Arrays;

public class Second_Largest_Array {

	public static void main(String[] args) {

			int c[]= {5,10,20,30,40,50,90,80};
			Arrays.sort(c);
			System.out.println(c[c.length-2]);

		}

}

