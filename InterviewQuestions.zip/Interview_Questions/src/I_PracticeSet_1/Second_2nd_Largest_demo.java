package I_PracticeSet_1;
import java.util.TreeSet;
public class Second_2nd_Largest_demo {

	public static void main(String[] args) {
		int a[]= {12,90,23,12,90,26,38,29,80};

		TreeSet<Integer>set=new TreeSet<>();
		for(int num:a) {
			set.add(num);
		}
		set.remove(set.last());
		System.out.println(set.last());
	}

}
