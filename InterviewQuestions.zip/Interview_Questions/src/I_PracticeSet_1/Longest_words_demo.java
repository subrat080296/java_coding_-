package I_PracticeSet_1;

public class Longest_words_demo {

	public static void main(String[] args) {
		String s="java automation selenium";
		 String[] s2=s.split(" ");
		 String longest=" ";
		 for (String element : s2) {
			 if(element.length()>longest.length())
			 {
				longest=element;
			 }
		 }
		 System.out.println(longest);


	}

}
