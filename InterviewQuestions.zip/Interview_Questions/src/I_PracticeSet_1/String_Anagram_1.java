package I_PracticeSet_1;

public class String_Anagram_1 {

	public static void main(String[] args) {
		String s="listen";
		String rev="";
		s=s.toLowerCase();
		for(int i=s.length()-1;i>=0;i--)
		{
			rev=rev+s.charAt(i);
		}
		System.out.print(rev);
	}

}
