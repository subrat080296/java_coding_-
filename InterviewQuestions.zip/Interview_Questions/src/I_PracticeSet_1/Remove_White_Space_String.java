package I_PracticeSet_1;

public class Remove_White_Space_String {

	public static void main(String[] args) {
		/*String s="this is java automation";

		StringBuilder sb=new StringBuilder();
		for (int i=0;i<s.length()-1;i++) {
			char ch=s.charAt(i);
			if(!Character.isWhitespace(ch)) {
				sb.append(ch);
			}
		}
		System.out.println(sb);
		*/

		String str = "  This is my java code    ";

		String result = String.join("", str.split(" "));
		System.out.println(result);

	}

}
