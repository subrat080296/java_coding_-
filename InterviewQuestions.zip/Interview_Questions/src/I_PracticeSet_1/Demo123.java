package I_PracticeSet_1;

public class Demo123 {

	public static void main(String[] args){
		System.out.println("Hello");
	}

}
