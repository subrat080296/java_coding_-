package I_PracticeSet_1;

public class Print_a90b1_opis_90108020 {

	public static void main(String[] args) {
		int a1=90;
		int b1=10;
		while(a1>b1) {
	 System.out.print(a1+" , "+b1);
	 a1-=10;
	 b1+=10;
	 {
	 if(a1>b1) {
	 System.out.print(" , ");
	 }
	}}
	}
}


