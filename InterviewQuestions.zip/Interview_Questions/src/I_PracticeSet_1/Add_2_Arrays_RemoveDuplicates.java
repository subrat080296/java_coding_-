package I_PracticeSet_1;

import java.util.HashSet;
import java.util.Set;

public class Add_2_Arrays_RemoveDuplicates {

	public static void main(String[] args) {
		int a[]= {12,78,45,67,87,10,20};
		int b[]= {10,67,84,35,30,20,67};
		int c[]= new int[a.length+b.length];

		for(int i=0;i<a.length;i++) {
			c[i]=a[i];
		}
			for (int i=0;i<b.length;i++) {
				c[a.length+i]=b[i];
			//	Arrays.sort(c);

			}
			Set<Integer> set1=new HashSet<>();
			for(int num1:c) {
				set1.add(num1);
			}
			for(Integer num:set1)

			{
				System.out.print(" "+num);
			}
			}

	}


