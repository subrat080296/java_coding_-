package I_PracticeSet_1;

public class SymobolString_1 {

	public static void main(String[] args) {
		String s="6584880";
		StringBuilder sb=new StringBuilder();
		for(int i =0;i<s.length()-1;i++) {
			int a=s.charAt(i)-'0';// its comparing the acci value acci values starts from 0=48;
			int b=s.charAt(i+1)-'0';

		if(a>b) {
			sb.append(">");
		}
		else if(a<b){
			sb.append("<");

		}
		else{
			sb.append("=");
		}
		}

		System.out.println(sb);

	}

}
