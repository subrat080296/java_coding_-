package I_PracticeSet_1;

public class Star_Pattern {

	public static void main(String[] args) {


	}

}
