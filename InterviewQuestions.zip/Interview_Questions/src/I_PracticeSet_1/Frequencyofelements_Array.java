package I_PracticeSet_1;

public class Frequencyofelements_Array {

	public static void main(String[] args) {
	int a[]= {10,20,30,60,10,20,60};
	int count=1;
	for (int i=0;i<a.length;i++) {
		for (int j=i+1;j<a.length;j++) {
			if(a[i]==a[j]) {
				count++
			}
			System.out.println(a[i]+" " +count);
		}
	}

	}

}
