package I_PracticeSet_1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Today_Date_demo {

	public static void main(String[] args) {
		LocalDate today=LocalDate.now();

		DateTimeFormatter f=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		String formateddate=today.format(f);
		System.out.println(formateddate);

	}

}
