package I_PracticeSet_1;

public class Duplicate_Element {

	public static void main(String[] args) {
		int a[]={10,20,30,40,20,30,60,40,80,10,90,20};
		for (int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]==a[j])
					{
						System.out.print(a[i]+" ");
						break;

					}
			}
		}

	}

}
