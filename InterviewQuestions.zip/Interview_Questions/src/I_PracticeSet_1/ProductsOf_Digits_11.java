package I_PracticeSet_1;

public class ProductsOf_Digits_11 {

	public static void main(String[] args) {
	 int v=12345;//1*2*3*4*5
	 int digit=0;
	 int product=1;
	 while(v>0) {
		 digit=v%10;
		 product=product*digit;
		 v=v/10;
	 }
	 System.out.println(product);

	}

}
