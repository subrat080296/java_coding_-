package I_PracticeSet_1;

import java.util.Arrays;

public class Largestin_Arrays {

	public static void main(String[] args) {
		int a[]= {12,67,98,45,601};
		Arrays.sort(a);
		System.out.println((a[a.length-1]));
	}
}
