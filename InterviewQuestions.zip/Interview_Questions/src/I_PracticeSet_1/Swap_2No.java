package I_PracticeSet_1;

public class Swap_2No {

	public static void main(String[] args) {
		int c=10;
		int d=20;
		int e;
		{
			c=c+d;//30
			d=c-d;//10
			c=c-d;

		}
		System.out.println(c);
		System.out.println(d);

	}

}
