package I_PracticeSet_1;

public class String_Rev_1 {

	public static void main(String[] args) {
		String s="Subrata jitnath";

		for (int i=s.length()-1;i>=0;i--)
		{
			System.out.print(s.charAt(i));
		}

	}

}
