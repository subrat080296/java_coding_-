package I_PracticeSet_1;

public class String_vs_StringBuffer_demo {

	public static void main(String[] args) {
	String s=new String("Durga");
	s.concat("software");
	System.out.println(s);


	StringBuffer sb=new StringBuffer("Autamation");
	sb.append("Testing");
	System.out.println(sb);


	}

}
