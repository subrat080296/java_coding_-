package I_PracticeSet_1;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class Date_Pick_Demo {

	public static void main(String[] args)
	{
		LocalDate Today=LocalDate.now();

		DateTimeFormatter f=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		String FromatedDate=Today.format(f);

		System.out.println(FromatedDate);


	}

}
