package I_PracticeSet_1;

public class Reverse_Number_1 {

	public static void main(String[] args) {
		int a=1345678;
		int rev=0;
		int rem=0;
		while(a>0)
		{
			rem =a%10;
			rev=rev*10+rem;
			a=a/10;
		}
		System.out.println(rev);

	}

}
