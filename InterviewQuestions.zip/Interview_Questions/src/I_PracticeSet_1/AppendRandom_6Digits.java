package I_PracticeSet_1;
import java.util.Random;
public class AppendRandom_6Digits {

	public static void main(String[] args) {
		String chars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";

		Random random=new Random();

		StringBuffer sb=new StringBuffer();

		for(int i=0;i<6;i++)
		{
			
			int index= random.nextInt(chars.length());
			
			sb.append(chars.charAt(index));
		}
		
		System.out.println(sb);

	}

}
