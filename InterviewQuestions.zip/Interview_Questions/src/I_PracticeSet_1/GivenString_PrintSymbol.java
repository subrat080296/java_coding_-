package I_PracticeSet_1;

public class GivenString_PrintSymbol {

	public static void main(String[] args) {
		String s="711999"; // >=>== print this
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<s.length()-1;i++) {
			int a=s.charAt(i)-'0';
			int b=s.charAt(i+1)-'0';
			if (a>b) {
				sb.append(">");
			}
			else if(a<b) {
				sb.append("<");

				}
			else{
				sb.append("=");
			}
		}
		System.out.print(sb);

	}

}
