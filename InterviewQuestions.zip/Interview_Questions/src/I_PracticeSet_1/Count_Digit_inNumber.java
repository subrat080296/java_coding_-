package I_PracticeSet_1;

public class Count_Digit_inNumber {

	public static void main(String[] args) {
		int b=156789876;
		int count=0;

		while(b>0) {
			b=b/10;//replace last number
			count++;

			}
		System.out.println(count);

	}

}
