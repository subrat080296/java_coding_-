package I_PracticeSet_1;

public class Fibonacci_Series_6 {

	public static void main(String[] args) {
		int no=1233456789;//1+1=2,2+1=3,3+2=5.................
		int a=0;
		int b=1;
		int c;
	//	System.out.print(a+" "+b);
		for (int i=0;i<=10;i++) {
			c=a+b;
			a=b;b=c;

		System.out.print(" "+c);

		}
	}
	}

