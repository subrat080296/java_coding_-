package I_PracticeSet_1;
import java.util.HashMap;
public class Number_Frequency_Array {

	public static void main(String[] args) {
	int a[]= {10,24,60,38,10,59,60,60,24,38};
	HashMap<Integer, Integer>map=new HashMap<>();
	for(int num:a) {
		map.put(num, map.getOrDefault(num, 0) + 1);
	}
			System.out.println(map);
		}


	}


