package I_PracticeSet_1;

public class Reverse_Words_1 {

	public static void main(String[] args) {
	String s="hello java python selenium";

	String[] s1=s.split(" ");
	for(int i=s1.length-1;i>=0;i--) {
		System.out.print(s1[i]+" ");
	}
	}

}
