package I_PracticeSet_1;

public class Armastrong_Number_7 {

	public static void main(String[] args) {
		int number=153;  //1*1+5*5+3*3=153
		int original_no=number;
		int sum=0;
		int rem=0;
		while(number>0) {
		rem=number%10;
		sum=sum+(rem*rem*rem);
		number=number/10;
		}
		if(original_no==sum) {
		System.out.println("its an armstrong number");

	}
		else {
			System.out.println("its not a armastrong number");
		}
		}


}
