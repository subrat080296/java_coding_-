package I_PracticeSet_1;

public class Prime_Number_Check_9 {

	public static void main(String[] args) {
		int number=18;
		int prime=0;
		for(int i=2;i<=number-1;i++) {
			if(number%i==0)
			{
				prime=prime+1;
			}
		 }
		if(prime==0)
		    {

				System.out.println(number + " is prime");
		        	}

           else
                  {
                 System.out.println(number + " is not prime");

		}

	}
}


