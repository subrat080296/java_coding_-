package I_PracticeSet_1;

public class Remove_White_Space {

	public static void main(String[] args) {
		String s="this is java automation";
		String s1=s.replaceAll("\\s+","");
		//String s2=s.replaceAll("[^a-zA-Z]","");
		System.out.print(s1);

	}

}
