package I_PracticeSet_1;
import java.util.HashMap;
public class Character_Occurance {

	public static void main(String[] args) {
		String s="assadsffvvvvcccbbgg";
		HashMap<Character , Integer>map=new HashMap<>();

		for (char ch: s.toCharArray())
		{

		map.put(ch,map.getOrDefault(ch, 0)+1);
		}
			System.out.println(map);

	}

	}


