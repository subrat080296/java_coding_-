package I_PracticeSet_1;

import java.util.Arrays;
import java.util.Collections;

public class Sort_Arrays_Decending_Order {

	public static void main(String[] args) {
		Integer a[]= {1,2,8,0,5,3,7};

		Arrays.sort(a, Collections.reverseOrder());

		System.out.print("Sorted in decending order ");
	for (int num:a) {
		System.out.print( num+" ");
		}
	}



}
