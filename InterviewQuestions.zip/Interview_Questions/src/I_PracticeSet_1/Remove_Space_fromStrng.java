package I_PracticeSet_1;

public class Remove_Space_fromStrng {

	public static void main(String[] args) {
		String s="sfd   45265sb    SSd   sbbd   sbd";
		s=s.toLowerCase();
	String 	s1=s.replaceAll("[^a-z0-9]","");

	System.out.println("Before removing space:"+ s.length() );
		System.out.println("After removing space: "+ s1.length());

	}

}
