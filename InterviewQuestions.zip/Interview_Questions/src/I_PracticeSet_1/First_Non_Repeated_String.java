package I_PracticeSet_1;
import java.util.HashMap;

public class First_Non_Repeated_String {

	public static void main(String[] args) {
		String s="aabbccddueeffl";
		HashMap<Character ,Integer>map=new HashMap<>();
		for(char ch:s.toCharArray())
		{
			map.put(ch,map.getOrDefault(ch,0)+1);
		}
			for(char ch:s.toCharArray()) {
			if(map.get(ch)==1) {
				System.out.println(ch);
				return;
			}

		}

	}

}

