package I_PracticeSet_1;

import java.util.LinkedHashSet;

public class Remove_DeplicateIn_Array {

	public static void main(String[] args) {
		int a[]= {10,12,10,45,20,78,45};

		LinkedHashSet<Integer> set=new LinkedHashSet<>();
	//	LinkedHashSet<> set=new LinkedHashSet<>();

		for(int num:a) {
			set.add(num);
		}

		System.out.println(set);

		/*
		for(int num :a) {
			set.add(num);
		}
		for(int num:set) {
			System.out.print(" " +num);
		}
		*/

	}

}
