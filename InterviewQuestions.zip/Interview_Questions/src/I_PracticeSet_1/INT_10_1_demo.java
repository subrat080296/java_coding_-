package I_PracticeSet_1;

public class INT_10_1_demo {

	public static void main(String[] args) {
		int c=10;
		int d=1;
		while(c>=d) {
			System.out.print(c+","+d);
			c-=1;
			d+=1;
			if(c>=d)
			{
				System.out.print(",");
			}
		}

	}

}
