package I_PracticeSet_1;

public class First_Noonrepeating_char {

	public static void main(String[] args) {
		String s="javaautomation";
		int count=0;
		for (int i=0;i<s.length();i++) {
			for(int j=0;j<s.length();j++) {
				if(s.charAt(i)==s.charAt(j)) {
					count ++;

				}
			}
			if (count==1){
				System.out.println(s.charAt(i));

			}
		}

	}

}
