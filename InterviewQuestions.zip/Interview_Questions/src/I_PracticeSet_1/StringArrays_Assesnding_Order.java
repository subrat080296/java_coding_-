package I_PracticeSet_1;

import java.util.Arrays;

public class StringArrays_Assesnding_Order {

	public static void main(String[] args) {
		int arr[]= {12,34,89,45,72,89,24,48,5};
		Arrays.sort(arr);
		for (int i=0;i<arr.length-1;i++) {


		System.out.print(" "+ arr[i]);
		}

	}

}
