package I_PracticeSet_1;

public class CharAppear_Check {

	public static boolean check (String s) {
		String s1SS="aaabb";//check all a come before b input aaabb  o/p is true and ababa o/p is false;
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)=='a') {
				return false;
			}
		}

	}

}
