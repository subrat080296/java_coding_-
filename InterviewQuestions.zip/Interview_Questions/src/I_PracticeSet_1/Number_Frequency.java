package I_PracticeSet_1;
import java.util.HashMap;
public class Number_Frequency {

	public static void main(String[] args) {
		int a[]= {444,33,222,11,11,22,11};
		HashMap<Integer, Integer>map=new HashMap<>();
		for (int num:a) {
			map.put(num, map.getOrDefault(num, 0)+1);
		}
		System.out.println(map);

	}

}
