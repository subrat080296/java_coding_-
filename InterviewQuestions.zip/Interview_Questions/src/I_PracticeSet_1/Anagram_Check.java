package I_PracticeSet_1;

import java.util.Arrays;

public class Anagram_Check {

	public static void main(String[] args) {
		String s1="little";
		String s2="listen";
		char[] a=s1.toCharArray();
		char[] b=s2.toCharArray();
		Arrays.sort(a);
		Arrays.sort(b);
		if(a.equals(b)) {
			System.out.println("String is anagram");

		}
		else {
			System.out.println("String not anagram");
		}


	}

}
