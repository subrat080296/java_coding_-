package I_PracticeSet_1;

public class Pallindrome_Number_4 {

	public static void main(String[] args) {
		//int i=122;
		int i=121;
		int reverseno=0;
		int digit=0;
		int originalno=i;
		while(i>0)
		{
			digit=i%10;// to calculate the reminder
			reverseno=reverseno*10+digit;
			i/=10;
		}
		if(originalno==reverseno) {
			System.out.println("its a pallindrome");
		}
		else {
			System.out.println("not a pallindrome no");
		}

	}

}
