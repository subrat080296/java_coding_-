package I_PracticeSet_1;

public class String_Demo1 {

//	private static Object Static;

	public static void main(String[] args) {
//		String s="hello";
//		String s2="horld";
//		System.out.println(" " + s+s2);


	}

}
