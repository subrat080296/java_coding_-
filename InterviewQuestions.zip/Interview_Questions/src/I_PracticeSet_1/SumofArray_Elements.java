package I_PracticeSet_1;

public class SumofArray_Elements {

	public static void main(String[] args) {
		int a[]= {12,89,34,28,60};
		int sum=0;
			for (int num: a)
			{
				sum=sum+num;
			}
			System.out.print(sum);

		}



}
