package I_PracticeSet_1;

public class Replace_char_1 {

	public static void main(String[] args) {
		String s="automation";
		 String s2=s.replace('m', 'Z');
		 System.out.println(s2);

	}

}
