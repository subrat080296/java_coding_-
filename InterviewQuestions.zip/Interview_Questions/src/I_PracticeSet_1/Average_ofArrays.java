package I_PracticeSet_1;

public class Average_ofArrays {

	public static void main(String[] args) {
		int a[]= {12,34,56,87,56,45};
		int sum=0;
		for (int num:a) {
			sum=sum+num;
		}
		double avg= (double)sum/a.length;


	System.out.println(avg);
	}

}
