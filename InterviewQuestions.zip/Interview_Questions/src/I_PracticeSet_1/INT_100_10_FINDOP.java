package I_PracticeSet_1;

public class INT_100_10_FINDOP {

	public static void main(String[] args) {
	int a=100;
	int b=10;
	while(a>=b) {
		System.out.print(a +","+ b);
		a-=10;
	   b+=10;
	    if(a>=b)
     	{
		System.out.print(",");
		}
}

	}

}
