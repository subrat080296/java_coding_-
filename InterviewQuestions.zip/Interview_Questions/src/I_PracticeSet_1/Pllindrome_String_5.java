package I_PracticeSet_1;

public class Pllindrome_String_5 {

	public static void main(String[] args) {
		String s="MadaM";
		String rev="";
		String original=s;
		for (int i=s.length()-1;i>=0;i--)
		{
			rev=rev+s.charAt(i);

			}
		if(s.equals(rev)) {
			System.out.println("its a pallindrome");
		}
		else
		{
			System.out.println("not a pallindrome");
		}

	}

}
