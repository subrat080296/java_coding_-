package I_PracticeSet_1;

public class Skip_String_demo {

	public static void main(String[] args) {
		String s="Subrata";
	//	String a="";
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)=='a')
			{
				continue;
			}
			System.out.print(s.charAt(i));
		}

	}

}
