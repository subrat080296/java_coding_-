package I_PracticeSet_1;

public class Character_Frequency_count {

	public static void main(String[] args) {
		String s1="ZZZZZCCCCBBBBSSSS";//AABBBBCCCD
		int count=0;
		for (int i=0;i<s1.length();i++) {
			if(i<s1.length()-1 && s1.charAt(i)==s1.charAt(i+1)) {
				count++;
			}
			else {
				System.out.println(s1.charAt(i)+"=="+count);
				count=1;

		}
	}
}


}
