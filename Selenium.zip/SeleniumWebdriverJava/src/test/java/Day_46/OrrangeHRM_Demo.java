package Day_46;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class OrrangeHRM_Demo {
  WebDriver driver;
  @BeforeMethod
  void setup() {
	  driver=new ChromeDriver();
	  driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	  driver.manage().window().maximize();
	  
  }
  @Test(priority=1)
  void Logo() throws InterruptedException {
	  
	  Thread.sleep(100);
	 boolean status= driver.findElement(By.xpath("//img[@alt='company-branding']")).isDisplayed();
	 
	 Assert.assertEquals(status, true);
  }
  
  @Test(priority=2, dependsOnMethods="Logo")
  void verifyTitle() {
	  Assert.assertEquals(driver.getTitle(), "OrangeHRM");
  }
  @Test(priority=3, dependsOnMethods="verifyTitle")
  void verifyurl() {
	  Assert.assertEquals(driver.getCurrentUrl(),"https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
  }
  @AfterClass
  void tearDown() {
	  driver.close();
  }
}
