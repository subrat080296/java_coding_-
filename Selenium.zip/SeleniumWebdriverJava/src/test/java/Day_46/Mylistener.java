package Day_46;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;


public class Mylistener implements ITestListener
{
	public void onStart(ITestContext context) {
		    System.out.println("Test Execution will start");
		  }
		  
public void onTestStart(ITestResult result) {
	System.out.println("Test Execution is started");
		  }
public void onTestSuccess(ITestResult result) {
	System.out.println("Test Execution is pass");
		  }
public void onTestFailure(ITestResult result) {
	System.out.println("Test Execution is failed");
		  }
public void onTestSkipped(ITestResult result) {
	System.out.println("Test Execution is skipped");
  }
public void onFinish(ITestContext context) {
	System.out.println("Test Execution is completed");
		  }


}
