package Day_46;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;


public class ExtendReportManager implements ITestListener
{
	public ExtentSparkReporter sparkReporter;//for UI
	public ExtentReports extent; //FOR COMMON INPUT INFO
	public ExtentTest test;// creating test case entries in the report and updated status of the method .
	
	public void onStart(ITestContext contest) {
		sparkReporter =new ExtentSparkReporter(System.getProperty("user.dir")+"/myreports/reportall.html");
		
		sparkReporter.config().setDocumentTitle("Automation Report");//TITTLE OF THE REPORT
		sparkReporter.config().setReportName("Functional Testing");//NAME OF THE REPORT
		sparkReporter.config().setTheme(Theme.DARK);//
		
		extent = new ExtentReports();
		extent.attachReporter(sparkReporter);

		extent.setSystemInfo("Computername", "LocalHost");
		extent.setSystemInfo("Environment", "QA");
		extent.setSystemInfo("Tester", "Subrata");
		extent.setSystemInfo("Project", "UI Automation");
			
		}
	public void onTestSuccess(ITestResult result) {
		test=extent.createTest(result.getName());
		test.log(Status.PASS, "Testcase is PASS is: "+result.getName());
	}
	
	public void onTestFailure(ITestResult result) {
		test=extent.createTest(result.getName());
		test.log(Status.FAIL, "Testcase is failed "+result.getName());
		test.log(Status.FAIL, "Testcases Failed Cause"+result.getThrowable());
	}
	
	
	public void onTestSkipped(ITestResult result) {
		test=extent.createTest(result.getName());
		test.log(Status.SKIP ,"Test Cases SKIP is:"+ result.getName());
		
	}
	}


