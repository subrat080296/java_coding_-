package Day_46;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
//@Listeners(Day_46.Mylistener.class)
public class Lister_TestNG_Demo {

	WebDriver driver;
	
	@Test()
	@BeforeClass()
	void setup() {
		driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
	}
	@Test(priority=1)
	void testlogo()
	{
		Boolean status=	driver.findElement(By.xpath("//img[@alt='company-branding']")).isDisplayed();
		
		Assert.assertEquals(status , true);
	}
	@Test(priority=2)
	void testappurl() {
		Assert.assertEquals(driver.getCurrentUrl(),("https://www.opencart.com/"));
		
	}
	@Test(priority=3 , dependsOnMethods= {"testappurl"})
	void testHomepageTitle() {
		Assert.assertEquals(driver.getTitle(), "OrangeHRM");
	}
	@Test(priority=4)
	void Tesrdown() {
		driver.quit();
	}
}
