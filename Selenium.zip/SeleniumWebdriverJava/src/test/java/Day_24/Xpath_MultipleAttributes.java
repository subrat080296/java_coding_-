package Day_24;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class Xpath_MultipleAttributes {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/desktops");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@name='q'][@placeholder='Search store']")).sendKeys("Tiger");
		

	}

}
