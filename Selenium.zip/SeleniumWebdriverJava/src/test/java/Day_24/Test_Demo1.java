package Day_24;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Test_Demo1 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.redbus.in/");
		
		//give input
	 	WebElement dropdown=driver.findElement(By.xpath("//input[@id=\'srcinput\']"));
	 	dropdown.sendKeys("Adoni");
	 	
	 	Thread.sleep(2000);
	      driver.findElement(By.xpath("//input[@id=\'destinput\']")).sendKeys("Vasi");
	      Thread.sleep(2000);
	  
	      //select date
	      driver.findElement(By.xpath("(//div[contains(@class,'dateInputWrapper')])[1]")).click();
	        Thread.sleep(2000);
	      driver.findElement(By.xpath("//span[normalize-space()='30']")).click();
	      Thread.sleep(2000);
	      
	      //click on search button
	      driver.findElement(By.xpath("//button[@aria-label='Search buses']")).click();
	      
	      Thread.sleep(2000);
	      JavascriptExecutor sja=(JavascriptExecutor) driver;
	      sja.executeScript("window.scrollBy(0,10000)");
	      
	      
	  	TakesScreenshot ts= (TakesScreenshot) driver;
	 File sourcefile	=ts.getScreenshotAs(OutputType.FILE);
	
	 File targetfile=new File(System.getProperty("User.dir")+"\\Screenshot\\demopage1.png");
	 sourcefile.renameTo(targetfile);
     System.out.println("Screenshot saved successfully!");	
	  	
	  	
	      driver.getWindowHandle();
	    System.out.println(driver.getCurrentUrl());//URL
	    
	    System.out.println(driver.getTitle());//TITTLE
	    
	//   System.out.println( driver.getPageSource());//PAGE SOURCE
	   System.out.println(driver.getWindowHandle());
	   
// open multiple window 
		driver.findElement(By.xpath("//a[@class=\'navOption___6e1d4b\']")).click();
	     driver.findElement(By.xpath("//i[@class=\'optionIcon___c6b7c0 icon icon-help\']")).click();
	     driver.findElement(By.xpath("//i[@class=\'optionIcon___c6b7c0 icon icon-help\']")).click();
	     driver.findElement(By.xpath("//i[@class=\'optionIcon___c6b7c0 icon icon-help\']")).click();
	     driver.findElement(By.xpath("//i[@class=\'optionIcon___c6b7c0 icon icon-help\']")).click();
	     driver.findElement(By.xpath("//i[@class=\'optionIcon___c6b7c0 icon icon-help\']")).click();
	     driver.findElement(By.xpath("//i[@class=\'optionIcon___c6b7c0 icon icon-help\']")).click();
	     driver.findElement(By.xpath("//i[@class=\'optionIcon___c6b7c0 icon icon-help\']")).click();
	     driver.findElement(By.xpath("//i[@class=\'optionIcon___c6b7c0 icon icon-help\']")).click();
	     driver.findElement(By.xpath("//i[@class=\'optionIcon___c6b7c0 icon icon-help\']")).click();
	     System.out.println("its print the window id"+ driver.getWindowHandles());

	      Thread.sleep(200);
	   //  driver.navigate().back();
	     
	     String mainWindow = driver.getWindowHandle();
	     Set<String> allWindows = driver.getWindowHandles();
	     
	     for (String window : allWindows) {
	    	    driver.switchTo().window(window);
	    	    
	    	    if (driver.getTitle().contains("RedBus")) {
	    	        System.out.println("Switched to: " + driver.getTitle());
	    	}     

	    	 // Convert Set to List
	    	 List<String> windowList = new ArrayList<>(allWindows);

	    	 // Switch to 4th window (index starts from 0)
	    	 driver.switchTo().window(windowList.get(3));

    	     System.out.println("Switched to 4th window");
	    	 System.out.println(driver.getTitle());

	}
	     
	    
	     
	     
	
	 Thread.sleep(200);
     driver.close();
	}

	
}


