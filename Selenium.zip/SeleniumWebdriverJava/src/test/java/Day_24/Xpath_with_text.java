package Day_24;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

public class Xpath_with_text {

	public static void main(String[] args) {
		WebDriver driver= new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/about-nopcommerce");
		driver.manage().window().maximize();
		//inner text
		
		boolean displayedstatuc=driver.findElement(By.xpath("//h1[text()='About nopCommerce']")).isDisplayed();
		System.out.println(displayedstatuc);

	}

}
