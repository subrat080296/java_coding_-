package Selenium_PracticeSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;



public class Mouse_Action_demo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.flipkart.com/");
		driver.manage().window().maximize();
		 Actions ac=new Actions(driver);
		 
		 Thread.sleep(1000);
		 WebElement el = driver.findElement(By.xpath("//span[text()='Login']"));
		
		ac.moveToElement(el).perform();
		
		 Thread.sleep(1000);
		driver.findElement(By.xpath("//span[text()='My Profile']")).click();
		
		System.out.println("test passed");

	}

}
