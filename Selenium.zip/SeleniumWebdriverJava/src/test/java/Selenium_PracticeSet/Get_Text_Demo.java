package Selenium_PracticeSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Get_Text_Demo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub\
		
		WebDriver driver =new ChromeDriver();
		
		driver.get("https://in.indeed.com/");
		
		driver.manage().window().maximize();
		
		WebElement wl=driver.findElement(By.xpath("//h2[contains(text(),'Your next job starts here')]"));
		String value=wl.getText();
		
		System.out.println(value);
		
		
	}
}