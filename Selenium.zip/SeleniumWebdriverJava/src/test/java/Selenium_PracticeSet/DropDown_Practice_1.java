package Selenium_PracticeSet;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class DropDown_Practice_1 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://practice.expandtesting.com/dropdown");
		driver.manage().window().maximize();
		//driver.manage().window().switchTo(100,500);
	WebElement country=	driver.findElement(By.xpath("//select[@id=\'country\']"));
	
	Thread.sleep(1000);
	Select dropdown=new Select(country);//using select class we can select the dropdown
	dropdown.selectByVisibleText("Aruba");

	}

}
