package Selenium_PracticeSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selenium_Methods_demo {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
//		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
//		
//		//Get Title
//	 String element=driver.getTitle();
//	// System.out.println(element);
//	 if(element.equals("OrangeHRM")) {
//		 System.out.println("testpass");
//	 }
//	 else {
//		 System.out.println("test fail");
//	 }
	// driver.quit();
	 driver.get("https://www.irctc.co.in/nget/train-search");
	 driver.findElement(By.xpath("//button[@type=\'submit\']")).click();
	 
	// driver.switchTo().window(English)
	WebElement flight= driver.findElement(By.xpath("//spam[@class=\'allcircle circleone\']"));

	flight.click();
	 
//	 driver.switchTo().window(element)

	}

}
