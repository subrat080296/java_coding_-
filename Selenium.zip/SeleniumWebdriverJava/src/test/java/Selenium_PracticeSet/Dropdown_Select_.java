package Selenium_PracticeSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class Dropdown_Select_ {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://practice.expandtesting.com/dropdown");
		
		driver.manage().window().maximize();
		
		WebElement el=driver.findElement(By.xpath("//select[@id=\'dropdown\']"));
		Select dropdown1=new Select(el);
		
		dropdown1.selectByVisibleText("Option 2");

	}

}
