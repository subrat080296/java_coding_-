package Selenium_PracticeSet;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HeadLes_Mode_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChromeOptions op=new ChromeOptions();
		op.addArguments("--headless");
		
		WebDriver driver=new ChromeDriver(op);
driver.get("https://www.google.com/");

System.out.println(driver.getTitle());
	}

}
