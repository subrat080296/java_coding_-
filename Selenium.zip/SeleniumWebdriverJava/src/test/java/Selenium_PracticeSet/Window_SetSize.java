package Selenium_PracticeSet;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Window_SetSize {

	public static void main(String[] args) 
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		Dimension dm=new Dimension(700,900);
		driver.manage().window().setSize(dm);
		
		Dimension d=driver.manage().window().getSize();
	   int width_S=d.getWidth();
	   System.out.println(width_S);
	   int height=d.getHeight();
	   System.out.println(height);
	   
	  WebElement wb= driver.findElement(By.xpath("//textarea[@id='APjFqb']"));
	  int higt=wb.getRect().getWidth();
	  System.out.println(higt);
	  int wdth=wb.getRect().getHeight();
	  System.out.println(wdth);
	  
	   

	}

}
