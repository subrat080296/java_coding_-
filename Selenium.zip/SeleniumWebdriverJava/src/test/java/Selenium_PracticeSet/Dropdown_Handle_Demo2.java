package Selenium_PracticeSet;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Dropdown_Handle_Demo2 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://in.bookmyshow.com/explore/movies-kolkata?cat=MT");
		driver.manage().window().maximize();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[@class=\'sc-1or3vea-16 hrepuk\']")).click();
		
		
		
				
	  driver.findElement(By.xpath("a//span[@class=\'sc-1or3vea-20 fqUaRT\']")).click();

		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		WebElement searchBox = wait.until(
		    ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search for your city']")));	
		Thread.sleep(1000);
		searchBox.sendKeys("kolkata" , Keys.ENTER);
	       
		TakesScreenshot ts=(TakesScreenshot) driver;
	File source=ts.getScreenshotAs(OutputType.FILE);
	
File path= new File(System.getProperty("user.dir")+"path");
	
	source.renameTo(path);

	}

}
