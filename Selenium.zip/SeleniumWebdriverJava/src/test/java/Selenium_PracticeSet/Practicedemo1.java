package Selenium_PracticeSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Keys;

public class Practicedemo1 {
	
	public static void main(String[] args) {
	
    WebDriver driver = new ChromeDriver();

    driver.get("https://demo.nopcommerce.com/");
    driver.manage().window().maximize();

    driver.findElement(By.name("q")).sendKeys(Keys.SHIFT,"hello");// it ill input as HELLO

    driver.findElement(By.className("search-box-button")).click();
	}
	


}
