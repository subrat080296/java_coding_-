package Selenium_PracticeSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdown_Demo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.globalsqa.com/demo-site/select-dropdown-menu/");
		
	 driver.manage().window().maximize();
	 WebElement countryDropdown = driver.findElement(By.xpath("//select"));//select
	 Thread.sleep(1000);
	 Select dropdown = new Select(countryDropdown);
	 
	 dropdown.selectByVisibleText("Angola");
	 
	dropdown.selectByIndex(2);
	 
	// dropdown.selectByValue("AL");

	}

}
