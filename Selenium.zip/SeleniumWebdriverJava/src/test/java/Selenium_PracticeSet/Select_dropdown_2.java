package Selenium_PracticeSet;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Select_dropdown_2 {

	public static void main(String[] args) {
		 WebDriver driver=new ChromeDriver();
		 driver.get("");

	}

}
