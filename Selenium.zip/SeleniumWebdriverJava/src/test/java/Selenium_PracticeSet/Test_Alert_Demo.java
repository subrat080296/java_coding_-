package Selenium_PracticeSet;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test_Alert_Demo {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.selenium.dev/selenium/web/alerts.html#");
		driver.manage().window().maximize();
		 driver.findElement(By.id("alert")).click();
		  Thread.sleep(500);
			Alert myalert1=driver.switchTo().alert();
			myalert1.accept();
	  System.out.println("test passed");
	  driver.close();
		

	}

}
