package Selenium_PracticeSet;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Check_DropdownList_countryisPresentorNot {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://practice.expandtesting.com/dropdown");
		driver.manage().window().maximize();
	WebElement country=driver.findElement(By.id("country"));
	
	Select select = new Select(country);
	
	boolean isIndiaPresent = select.getOptions().stream().map(WebElement::getText).anyMatch("Aruba"::equalsIgnoreCase);
	
	if (isIndiaPresent) {
		select.selectByVisibleText("Aruba");
	}
	else {
		throw new NoSuchElementException("India is not available in the dropdown.");
	}
	System.out.println("test passed");

	}

}
