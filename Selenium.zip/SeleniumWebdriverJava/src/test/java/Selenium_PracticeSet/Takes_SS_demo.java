package Selenium_PracticeSet;

import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Takes_SS_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://practice.expandtesting.com/dropdown");
		driver.manage().window().maximize();
		TakesScreenshot ts= (TakesScreenshot)driver;
		File Source=ts.getScreenshotAs(OutputType.FILE);
		
		File target_file=new File("C:\\Users\\a859230\\OneDrive - ATOS\\Desktop\\ss\\image.png");
		
		
		Source.renameTo(target_file);

	}

}
