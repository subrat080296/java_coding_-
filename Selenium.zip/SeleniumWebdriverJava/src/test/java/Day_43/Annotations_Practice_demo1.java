package Day_43;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Annotations_Practice_demo1 {
		
	
	//	WebDriver driver;

		@BeforeClass()
			void login() {
			System.out.println("Login successfully");
		}
			@Test(priority=1)
			void search() {
				System.out.println("Searching the product");
			}
			@Test(priority=2)
			void advsearch() {
				System.out.println("Advanced search");
			}
			
			@AfterClass
			void lgout() {
				System.out.println("Again Logout");
				
			}
			
		}


