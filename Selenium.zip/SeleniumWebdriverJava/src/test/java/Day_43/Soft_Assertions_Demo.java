package Day_43;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Soft_Assertions_Demo {
@Test
void SofteAssertions() {
	System.out.println("Soft assertion 1");
	System.out.println("Soft assertion 2");
	
	SoftAssert sa=new SoftAssert();//create an object
	sa.assertEquals(1,2);
	
	System.out.println("Soft assertions 3");
	System.out.println("Soft assertions 4");
	
	sa.assertAll();//Mandatory to write
}
}
