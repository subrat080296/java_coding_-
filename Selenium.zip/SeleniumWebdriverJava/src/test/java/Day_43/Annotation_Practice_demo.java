package Day_43;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Annotation_Practice_demo {
WebDriver driver;

@BeforeMethod()
	void login() {
	System.out.println("Login successfully");
}
	@Test(priority=1)
	void search() {
		System.out.println("Searching the product");
	}
	@Test(priority=2)
	void advsearch() {
		System.out.println("Advanced search");
	}
	
	@AfterMethod
	void lgout() {
		System.out.println("Again Logout");
		
	}
	
}
