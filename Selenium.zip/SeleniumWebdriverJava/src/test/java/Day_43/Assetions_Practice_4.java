package Day_43;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Assetions_Practice_4 {
	
	WebDriver driver ;
  @Test
  void Tittle() {
	  
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  
	  driver.get("https://orangehrm.com/");
	WebElement title=  driver.findElement(By.xpath("//img[@alt='OrangeHRM Logo']"));
    String actualTitle = title.getAttribute("alt");
    String expectedTitle = "OrangeHRM Logo";

	  
	  Assert.assertEquals(title , expectedTitle);
  }
}
