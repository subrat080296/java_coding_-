package Day_43;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

//Login
//Search
//Logout
//Login
//Adv search
//Logout

public class Annotations_Demo {
	
	@BeforeMethod
	void Login()
	{
		System.out.println("This is login")	;
		}
	@Test(priority=1)
	void Search() {
		System.out.println("this Search");
	}
	@Test(priority=2)
	void Advsearch()
	{
		System.out.println("This advance Search");
	}
	@AfterMethod
	void Logout() {
		System.out.println("Logout ");
	}

}
