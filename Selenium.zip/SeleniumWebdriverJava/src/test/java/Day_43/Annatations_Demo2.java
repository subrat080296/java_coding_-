package Day_43;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Annatations_Demo2 {
	
	//Login
	//Search
	//Adv search
	//Logout

	public class Annotations_Demo {
		
		@BeforeClass
		void Login()
		{
			System.out.println("This is login")	;
			}
		@Test(priority=1)
		void Search() {
			System.out.println("this Search");
		}
		@Test(priority=2)
		void Advsearch()
		{
			System.out.println("This advance Search");
		}
		@AfterClass
		void Logout() {
			System.out.println("Logout ");
		}

	}

}
