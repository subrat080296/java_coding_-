package Day_43;

import org.testng.annotations.Test;
import org.testng.Assert;

public class test_123 {
	
	@Test
	void Test() 
	{
		String s="Hello";
		String s2="Hello";
		Assert.assertEquals(s, s2);
	}

}
