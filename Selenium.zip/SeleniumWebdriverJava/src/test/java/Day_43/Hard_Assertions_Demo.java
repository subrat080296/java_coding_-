package Day_43;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Hard_Assertions_Demo {
  @Test()
  void TesHardAssertions() {
	//  Assert.assertEquals("ABC","ABC");
	 // Assert.assertEquals("ABC","123");
	//  Assert.assertEquals("xyz","ABC");
	  Assert.assertNotEquals(120, 123);//pass
	  Assert.assertNotEquals(123, 123);//failed
  }
}
