package Day_43;

import org.testng.Assert;
import org.testng.annotations.Test;

public class HardAssertions_Practice_1 {
	@Test
	void testAssertion()
	{
		Assert.assertEquals("actual","actual");
	}
	

}
