package Day_43;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Assertion_Practice_1 {
	@Test()
	void testTitle() {
		String tittle="Opencart1";
		
		String tittle1="Opencart1";
		Assert.assertEquals(tittle ,tittle1);
	}

}
