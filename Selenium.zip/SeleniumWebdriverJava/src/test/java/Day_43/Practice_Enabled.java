package Day_43;

import org.testng.annotations.Test;

public class Practice_Enabled {
	@Test
	void print() {
		System.out.println("Hello");
	}
	
	@Test(enabled=false)
	void Return() {
		System.out.println("How are you ");
	}

}
