package Day_43;

import org.testng.annotations.*;

public class All_Annotations_Demo {
 @BeforeSuite()
 void BS() {
	 System.out.println("Before suite");
	 
 }
 @AfterSuite()
 void AS()
 { 
	 System.out.println("After Suite");
 }
 @BeforeTest()
 void BT() {
	 System.out.println("Before test");
 }
 @AfterTest()
 void AT() {
	 System.out.println("This is after test");
 }
 @BeforeClass()
 void BC() {
	 System.out.println("This Before Class");
 }
 @AfterClass()
 void AC() {
	 System.out.println("This is after Class");
	 
 }
 @BeforeMethod()
 void BM() {
	 System.out.println("This is Before Method ");
 }
 @AfterMethod()
 void AM() {
	 System.out.println("This after Methods  ");
 }
 @Test(priority=1)
 void Test() {
	 System.out.println("This Test method_1");
 }
 @Test(priority=2)
 void test2()
 {
	 System.out.println("This is test method __2");
 }
}
