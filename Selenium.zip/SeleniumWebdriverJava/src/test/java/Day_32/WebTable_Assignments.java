package Day_32;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTable_Assignments {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://blazedemo.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		List<WebElement>OP=driver.findElements(By.xpath("//select[@name='fromPort']"));
		System.out.println(OP.size());

		List<WebElement>OP1=driver.findElements(By.xpath("//select[@name='toPort']"));
		for (WebElement options1:OP1){
		System.out.println(options1.getText());
		if(options1.equals("London"));
		Thread.sleep(10);
		driver.findElement(By.xpath("//input[@type='submit']"));


	}

		}
		}
	
			
		
