package Day_32;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Web_Tables_demo {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		//Find total number of rows in a table
		int rows=driver.findElements(By.xpath("//table[@name='BookTable']//tr")).size();
		
		//or
		//int rows=driver.findElements(By.tagName("tr")).size();//this used for single table in a webpage
		System.out.println("no of rows: " + rows);
		//find total number of column
		int column=driver.findElements(By.xpath("//table[@name='BookTable']//th")).size();
		System.out.println("no of column: " + column);
		
		//To read a specific row and column value(eg: row 5 and column 1st)
		String bookName=driver.findElement(By.xpath("//table[@name='BookTable']//tr[5]//td[1]")).getText();
		System.out.println(bookName);
		
		//eg- 7th row and 3rd column
		
		String bookName1=driver.findElement(By.xpath("//table[@name='BookTable']//tr[7]//td[3]")).getText();
		System.out.println(bookName1);
		
		//Print only header of the table
		System.out.println("BookName"+"\t"+"Author"+"\t"+"Subject"+"\t"+"Price");
		
	
		
		//read all row and column value
		//for (int r=2;r<=rows;r++) {
		//	for(int c=2;c<=column;c++) {
		//	String value=driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td["+c+"]")).getText();
			//	System.out.print(value +"\t");
				
		//	}
		//	System.out.println();
			
			//Print the book name which Author name is Mukesh
		/*	
		for(int r=2;r<=rows;r++) {
				String Author=driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td[2]")).getText();
				if(Author.equals("Mukesh")) {
					String BokName=driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td[1]")).getText();
				
				System.out.println(BokName+"\t"+ Author);
				
			}
		}
			*/
		//Print all prices and calculate the Total price
		int total=0;
		for(int r=2;r<=rows;r++) {	
			String Price=driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td[4]")).getText();
		System.out.println(Price);
		total=total+Integer.parseInt(Price);
		System.out.println(total);
		}
		

	}
}


