package Day_37;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Upload_Files_demo {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://davidwalsh.name/demo/multiple-file-upload.php");
		driver.manage().window().maximize();
		
		//Single File upload
		driver.findElement(By.xpath("//input[@id='filesToUpload']")).sendKeys("C:\\Users\\a859230\\OneDrive-ATOS\\Desktop\\Test1.text");
		if(driver.findElement(By.xpath("//ul[id='fileList']//li")).getText().equals("ID_OE1.txt"))
		{
			System.out.println("Files is successfully uploaded");
			
		}
		else 
		{
			System.out.println("uploaded failed");
		}	

	}

}
