package Day_37;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.JavascriptExecutor;
public class Java_Script_Executor_Demo {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/register?returnUrl=%2F");
		driver.manage().window().maximize();
		WebElement ip=driver.findElement(By.xpath("//input[@id='FirstName']"));
		JavascriptExecutor js= (JavascriptExecutor)driver;
		
		js.executeScript("arguments[0].setAttribute('value','jhon')",ip);	
		WebElement radiob=driver.findElement(By.xpath("//input[@id='gender-male']"));
		js.executeScript("arguments[0].click()",radiob);
		

	}

}
