package Day_37;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScrollingPage_Using_JavaScriptExecutor {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("url");
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("Window.ScrollBy (0,500)");

	}

}
