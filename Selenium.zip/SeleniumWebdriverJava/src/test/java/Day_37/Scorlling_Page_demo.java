package Day_37;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scorlling_Page_demo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.countries-ofthe-world.com/flags-of-the-world.html");
		driver.manage().window().maximize();
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		//Scroll down page
		
	//	js.executeScript("window.scrollBy(0,5000)"," ");
		
	//	System.out.println(js.executeScript("return window.pageYOffset;"));
		
		//Scroll till India or any target
	//	WebElement india=driver.findElement(By.xpath("//img[@alt='Flag of India']"));
	//	js.executeScript("arguments[0].scrollIntoView();",india);
	//	System.out.println(js.executeScript("return window.pageYOffset;"));
		
		//Scroll till end of the page
		    js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
			System.out.println(js.executeScript("return window.pageYOffset;"));
			
			//Scrolling upto top or initial of the page
			Thread.sleep(5000);
			js.executeScript("window.scrollBy(0,-document.body.scrollHeight)");

	}

}
