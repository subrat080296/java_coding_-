package Day_41;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Read_Properties_File {

	public static void main(String[] args) throws IOException {
		Properties propertiesobj=new Properties();
		//Location of the file
		FileInputStream file= new FileInputStream(System.getProperty("user.dir")+"\\TestData_Folder\\Configure.properties");
		//Load properties file
		propertiesobj.load(file);
		
		//Reading data from properties file
		String url=propertiesobj.getProperty("url");
		String user=propertiesobj.getProperty("user");
		String pass=propertiesobj.getProperty("pass");
		String details=propertiesobj.getProperty("details");
		System.out.println(url+" "+user+""+pass+""+details+"");

	}

}
