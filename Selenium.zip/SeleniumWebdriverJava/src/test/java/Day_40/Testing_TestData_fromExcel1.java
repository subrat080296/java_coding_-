package Day_40;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Testing_TestData_fromExcel1 {

	public static void main(String[] args) throws IOException {
		// Excel File==>workbook==>sheet==>Row==>Cells
		
		FileInputStream file1 =new FileInputStream(System.getProperty("user.dir")+"\\testdata\\Test1.xlsx");
		
		XSSFWorkbook wb4=new XSSFWorkbook(file1);
		
		XSSFSheet sheet1= wb4.getSheet("Sheet1");
		int totalnoRow=sheet1.getLastRowNum();
		int totalceels=sheet1.getRow(1).getLastCellNum();
		
		System.out.println("total romis :" + totalnoRow);
		System.out.println("total column is:"+totalceels);
		
		for(int r=0;r<totalnoRow;r++)
		{
		XSSFRow	row=sheet1.getRow(r);
		
			for(int c=0;c<totalceels;c++) 
			{
				XSSFCell cell =row.getCell(c);
				System.out.print(cell.toString()+"\t");
			}
			System.out.println();
		}
   wb4.close();
   file1.close();

	}

}
