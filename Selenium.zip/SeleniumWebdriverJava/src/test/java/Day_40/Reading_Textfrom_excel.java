package Day_40;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Reading_Textfrom_excel {

	public static void main(String[] args) throws IOException {
		
		//FileInputStram==>book==>Sheet==>Row==>cell
		
		FileInputStream file5=new FileInputStream(System.getProperty("user.dir")+"\\testdata\\Test2.xlsx");
		
		XSSFWorkbook book=new XSSFWorkbook(file5);
		
		XSSFSheet sh=book.getSheet("Sheet1");
		int row=sh.getLastRowNum();
		int column=sh.getRow(1).getLastCellNum();
		System.out.println(row);
		System.out.println(column);
		
		for(int r=0;r<row;r++) {
			XSSFRow row1=sh.getRow(r);
			
			for(int c=0;c<column;c++) {
				
				XSSFCell cel=row1.getCell(c);
			
			System.out.print(cel.toString()+"\t");
			}
			
		
		System.out.println();
		}

	}

}
