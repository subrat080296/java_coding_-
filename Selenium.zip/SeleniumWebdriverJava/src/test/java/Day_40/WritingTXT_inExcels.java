package Day_40;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class WritingTXT_inExcels {

	public static void main(String[] args) throws IOException {
		//File==>workbook==>>Sheet==>Row==>cell
		FileOutputStream fil=new FileOutputStream(System.getProperty("user.dir")+"\\testdata\\Test3.xlsx");
		
		XSSFWorkbook book=new XSSFWorkbook();
		
		
		XSSFSheet sheet5=book.createSheet("Data");
		
		
		XSSFRow creatrow1=sheet5.createRow(0);
		creatrow1.createCell(0).setCellValue("java");
		creatrow1.createCell(1).setCellValue("selenium");
		creatrow1.createCell(2).setCellValue("automation");
		
		
		XSSFRow creatrow2=sheet5.createRow(0);
		creatrow2.createCell(0).setCellValue("python");
		creatrow2.createCell(1).setCellValue("ruby");
		creatrow2.createCell(2).setCellValue("c++");
		
		XSSFRow creatrow3=sheet5.createRow(0);
		creatrow3.createCell(0).setCellValue("math");
		creatrow3.createCell(1).setCellValue("eng");
		creatrow3.createCell(2).setCellValue("odia");
		
		book.write(fil);
		book.close();
		fil.close();
		
		System.out.println("file is created");

	}

}
