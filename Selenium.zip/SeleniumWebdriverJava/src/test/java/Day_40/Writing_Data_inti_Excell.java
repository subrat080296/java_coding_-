package Day_40;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//Excel File-->Workbook-->Sheets-->Rows-->Cells

public class Writing_Data_inti_Excell {

	public static void main(String[] args) throws IOException {
		FileOutputStream file3=new FileOutputStream(System.getProperty("user.dir")+"\\TestData_Folder\\NewFile.xlsx");
		
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet=workbook.createSheet("Data");
		
		XSSFRow row1=sheet.createRow(0);
		row1.createCell(0).setCellValue("java");
		row1.createCell(1).setCellValue("569");
		row1.createCell(2).setCellValue("Automation");
		
		XSSFRow row2=sheet.createRow(1);
		row2.createCell(0).setCellValue("python");
		row2.createCell(1).setCellValue("509");
		row2.createCell(2).setCellValue("Selenium");
		
		XSSFRow row3=sheet.createRow(2);
		row3.createCell(0).setCellValue("Science");
		row3.createCell(1).setCellValue("900");
		row3.createCell(2).setCellValue("math");
		
		workbook.write(file3);
		workbook.close();
		file3.close();
		System.out.println("file is created successfully");

	}

}
