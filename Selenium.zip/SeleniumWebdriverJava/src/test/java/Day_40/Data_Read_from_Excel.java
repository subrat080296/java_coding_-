package Day_40;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Data_Read_from_Excel {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		
		FileInputStream fis6=new FileInputStream("path");
		XSSFWorkbook wrb=new XSSFWorkbook(fis6);

		XSSFSheet sheet=fis6.getSheet("sheet1");
		
		
		Row row=
		
	}

}
