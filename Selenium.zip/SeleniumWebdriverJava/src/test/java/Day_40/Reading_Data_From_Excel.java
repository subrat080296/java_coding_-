package Day_40;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

// Follow the steps:
//Excel File-->Workbook-->Sheets-->Rows-->Cells
public class Reading_Data_From_Excel {

	public static void main(String[] args) throws IOException {
		FileInputStream file2=new FileInputStream(System.getProperty("user.dir")+"\\TestData_Folder\\Selenium_java.xlsx");
		XSSFWorkbook wb=new XSSFWorkbook(file2);
		XSSFSheet sheet= wb.getSheet("Sheet1");
		
	//	XSSFSheet sheet=wb.getSheetAt(0);
		
		int totalRows=sheet.getLastRowNum();
		int totalCells=sheet.getRow(1).getLastCellNum();
		
		System.out.println("total number of rows:"+totalRows);

		System.out.println("total number of column:"+totalCells);
		
		for (int r=0;r<totalRows;r++) {
			XSSFRow currentRows=sheet.getRow(r);
			for(int c=0;c<totalCells;c++) {
				XSSFCell cell=currentRows.getCell(c);
				System.out.print(cell.toString()+"\t");
			}
			System.out.println();
			
		}
		//workbook.close();
	//	file.close();
	}

}
