package Day_40;

public class Input_from_excel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
