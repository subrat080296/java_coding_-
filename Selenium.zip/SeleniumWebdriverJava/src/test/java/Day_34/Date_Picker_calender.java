package Day_34;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Date_Picker_calender {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://jqueryui.com/datepicker/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//Switch to frame
		driver.switchTo().frame(0);
		//Method1 using Sendkeys select date
	//	driver.findElement(By.xpath("//input[@id='datepicker']")).sendKeys("01/08/2026");
		
		//Select date using date picker
		String year="2026";
		String month="May";
		String date="28";
		
		driver.findElement(By.xpath("//input[@id='datepicker']")).click();//open caclender/datepicker
		//select month and year
		while(true)
		{	
		
		String currentYear=driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();
		String currentMonth=driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();	
		    if(currentMonth.equals(month) && currentYear.equals(year))
		    {
		    	break;
		    }
	
		driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();// for next button
//driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-w']")).click();//for previous buttom

	}
		List<WebElement> alldates=driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr/td/a"));
		for(WebElement dt:alldates) {
			if(dt.getText().equals(date)) {
				dt.click();
				break;
			}
	
		}
		
}
		
}
