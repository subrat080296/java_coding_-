package Day_28;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class Assignment_Demo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		Thread.sleep(1000);
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id=\'Wikipedia1_wikipedia-search-input\']")).sendKeys("Selenium");
		driver.findElement(By.xpath("//input[@type=\'submit\']")).click();
		driver.findElement(By.linkText("Selenium")).click();
		driver.findElement(By.linkText("Selenium in biology")).click();
		driver.findElement(By.linkText("Selenium (software)")).click();
		driver.findElement(By.linkText("Selenium disulfide")).click();
		driver.findElement(By.linkText("Selenium dioxide")).click();
		Set<String>wid1=driver.getWindowHandles();
		//System.out.println(driver.getPageSource());
		
		//driver.findElement(By.linkText("Selenium")).click();
		//Set<String>Windowid=driver.getWindowHandles();
		//System.out.println(Windowid);
		
		for (String wid11:wid1)
		{
			String tittle=driver.switchTo().window(wid11).getTitle();
			System.out.println(tittle);
			
		}
		
	}

}
