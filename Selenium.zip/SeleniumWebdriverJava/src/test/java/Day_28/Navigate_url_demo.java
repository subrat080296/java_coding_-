package Day_28;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Navigate_url_demo {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.navigate().to("https://demo.nopcommerce.com/register?returnUrl=%2F");
		
		driver.navigate().back();
		
		System.out.println(driver.getCurrentUrl());
		driver.navigate().forward();
		
		System.out.println(driver.getCurrentUrl());
		driver.navigate().refresh();

	}

}
