package Day_28;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Get_multiple_windowIDS {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id=\'Wikipedia1_wikipedia-search-input\']")).sendKeys("Selenium");
		driver.findElement(By.xpath("//input[@type=\'submit\']")).click();
		driver.findElement(By.linkText("Selenium")).click();
		driver.findElement(By.linkText("Selenium in biology")).click();
		driver.findElement(By.linkText("Selenium (software)")).click();
		driver.findElement(By.linkText("Selenium disulfide")).click();
		driver.findElement(By.linkText("Selenium dioxide")).click();
		
		
		Set<String>wid=driver.getWindowHandles();
		//System.out.println(wid);
		//System.out.println("Link count is:"+ wid.size());
		
		for (String wid1:wid) {
			String tittle=driver.switchTo().window(wid1).getTitle();
		
			
			System.out.println(tittle);
			
			//if(tittle.equals("Selenium in biology - Wikipedia"))
			//{
			//driver.close();
			//}
			if (tittle.equals("Selenium (software) - Wikipedia")) {
			System.out.println(driver.getCurrentUrl());
			
		//	System.out.print(tittle +""+ count);

		//	if(tittle.equals("Selenium in biology - Wikipedia")) {
			//	driver.close();
		//	}
			
		
			
			}
		}
		}
		
		

	}


