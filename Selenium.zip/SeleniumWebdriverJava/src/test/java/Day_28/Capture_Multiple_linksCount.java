package Day_28;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Capture_Multiple_linksCount {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id=\'Wikipedia1_wikipedia-search-input\']")).sendKeys("Selenium");
		driver.findElement(By.xpath("//input[@type=\'submit\']")).click();
		List <WebElement> links=(List<WebElement>) driver.findElements(By.partialLinkText("Selenium"));
		System.out.println(links.size());
		for(int i=0;i<=links.size();i++) {
			String linkname=links.get(i).getText();
			System.out.println(linkname);
			
		}
		

	}
}


