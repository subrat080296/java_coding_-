package Day_30;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleFrames_Using_Selenium {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://ui.vision/demo/webtest/frames/");
		driver.manage().window().maximize();
		//Frame1
		WebElement frame1=driver.findElement(By.xpath("//frame[@src=\'frame_1.html\']"));
		driver.switchTo().frame(frame1);
		driver.findElement(By.xpath("//input[@name=\'mytext1\']")).sendKeys("Hello");
		driver.switchTo().defaultContent();//this is came to home page or previous page
		
		
		//Frame2
		WebElement frame2=driver.findElement(By.xpath("//frame[@src=\'frame_2.html\']"));
		driver.switchTo().frame(frame2);
		driver.findElement(By.xpath("//input[@name=\'mytext2\']")).sendKeys("how r you");
		driver.switchTo().defaultContent();
		
		//frame3
		WebElement frame3=driver.findElement(By.xpath("//frame[@src=\'frame_3.html\']"));
		driver.switchTo().frame(frame3);
		//driver.findElement(By.xpath("//input[@name=\'mytext3\']")).sendKeys("fine");
		//driver.switchTo().defaultContent();
		//frame4
		/*WebElement frame4=driver.findElement(By.xpath("//frame[@src=\'frame_4.html\']"));
		driver.switchTo().frame(frame4);
		driver.findElement(By.xpath("//input[@name=\'mytext4\']")).sendKeys("wbu?");
		driver.switchTo().defaultContent();
		*/
		
		//Select box under an checkbox
		driver.findElement(By.xpath("//input[@name=\'mytext3\']")).sendKeys("java");
		driver.switchTo().frame(0);
		driver.findElement(By.xpath("//div[@class='AB7Lab Id5V1']")).click();
	
	

	}

}
