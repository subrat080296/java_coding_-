package Day_30;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Hnadle_Window_Demo {

	public static void main(String[] args) {
	WebDriver driver=new ChromeDriver();
	driver.get("https://ui.vision/demo/webtest/frames/");
	driver.manage().window().maximize();
	WebElement frame5=driver.findElement(By.xpath("//frame[@src=\'frame_5.html\']"));
	driver.switchTo().frame(frame5);
	driver.findElement(By.xpath("//input[@name=\'mytext5\']")).sendKeys("Hello");
	//driver.switchTo().defaultContent();
	driver.findElement(By.linkText("https://a9t9.com ")).click();

	}

}
