package Day_31;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Hidden_Dropdown_demo {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php");
		driver.manage().window().maximize();
	//driver.sleep(10);
		//login
		
		driver.findElement(By.name("username")).sendKeys("Admin2349");
		driver.findElement(By.name("password")).sendKeys("Password234");
		driver.findElement(By.xpath("//button[normalize-space()='login']")).click();
		
		//clicking on PIM
		driver.findElement(By.xpath("pimurl")).click();
		
		
	}

}
