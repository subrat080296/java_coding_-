package Day_31;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Select_dropdown_inSelenium {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		WebElement countrydropdown=driver.findElement(By.xpath("//select[@id=\'country\']"));
		
		Select dc=new Select(countrydropdown);//Select class is used for select dropdown 
		
	//	dc.selectByVisibleText("Japan");
		//dc.selectByValue("india");
		
		dc.selectByIndex(4);
		//capture all dropdowns
		
		List<WebElement>options=dc.getOptions();
		System.out.println(options.size());
		//Print all options
		for (int i=0;i<options.size();i++) 
		{
			System.out.println(options.get(i).getText());
		};
	}

}
