package Day_31;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Practice_Select_dropdown_1 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://testautomationpractice.blogspot.com/");	
		driver.manage().window().maximize();
		Thread.sleep(5000);
	WebElement dropdowncountry=	driver.findElement(By.xpath("//select[@id='country']"));
	
Select dropdowncountry1=new Select(dropdowncountry);


	List<WebElement>options1=(dropdowncountry1.getOptions());
		System.out.println("total country dropdown:"+ options1.size());
		
	//	for (int i=0;i<options1.size();i++) {
	//		System.out.println(options1.get(i).getText());
		
			for (WebElement op:options1) {
			System.out.println(op.getText());
				
			Thread.sleep(100);
		 if (op.getText().equals("Japan")) {
			 op.click();
		 }
		}
	}
}


