package Day_31;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class BootStrap_Dropdown {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.jquery-az.com/bbots/demo.php?ex=63.0_2");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//button[contains(@class,'multiselect')]")).click();//it will show all dropdown checkbox
		
		//Select single checkbox
		driver.findElement(By.xpath("//input[@value='java']")).click();//it will select  a specific check box
		
		//Capture all option size/count;
		List<WebElement>options=driver.findElements(By.xpath("//ul[contains@class,'multiselect']//label"));
		System.out.println("number of options is: " +options.size());


		//Print all options from dropdown using for lop or enhanced frolop
		for (WebElement op:options) {
		System.out.println(op.getText());
		}
		
		
		//Select multiple options
		for (WebElement op:options) {
		String option=op.getText();
		if(option.equals("java")||option.equals("python")||option.equals("ruby")||option.equals("sql")) {
		op.click();
		}
		}

	}

}
