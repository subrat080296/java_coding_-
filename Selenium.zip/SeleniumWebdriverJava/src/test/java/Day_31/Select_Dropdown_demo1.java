package Day_31;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Select_Dropdown_demo1 {

	private static final String ExcepectedCondtions = null;

	public static void main(String[] args) {
		WebDriver driver= new ChromeDriver();
		driver.get(null);
		WebDriverWait mywait=new WebDriverWait(driver,Duration.ofSeconds(19));
		Alert myalert4=mywait.until(ExpectedConditions.alertIsPresent());
		WebElement dropdown=driver.findElement(By.xpath("url of dropdown"));
		Select dropd=new Select(dropdown);
		
		dropd.selectByIndex(2);
		
		List<WebElement>alloption=dropd.getOptions();
		System.out.println(alloption.size());
		
		for(int i=0;i<alloption.size();i++)
		{
			System.out.println(alloption.get(i).getText());
			
		}
	
		

	}

}
