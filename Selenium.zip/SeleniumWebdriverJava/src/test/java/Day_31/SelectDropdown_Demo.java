package Day_31;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SelectDropdown_Demo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://testautomationpractice.blogspot.com/");
		
		Thread.sleep(400);
		JavascriptExecutor js= (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,500)");
		
		WebDriverWait mywait=new WebDriverWait(driver, Duration.ofSeconds(10));
		Alert myalert= mywait.until(ExpectedConditions.alertIsPresent());
		WebElement Country=driver.findElement(By.xpath("//select[@id=\'country\']"));
		Select dc=new Select(Country);
		
		 dc.selectByIndex(5);
		// dc.selectByVisibleText("Japan");
	

	}

}
