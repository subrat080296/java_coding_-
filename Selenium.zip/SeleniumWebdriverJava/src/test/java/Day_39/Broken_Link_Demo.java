package Day_39;

public class Broken_Link_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
