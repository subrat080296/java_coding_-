package Day_35;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Drag_drop_Action {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		Actions act=new Actions(driver);
		WebElement dragg=driver.findElement(By.xpath("http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html"));
		WebElement droop=driver.findElement(By.xpath("http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html"));
		
		act.dragAndDrop(dragg, droop);

	}

}
