package Day_35;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Double_click_Actions {

	public static void main(String[] args) {
	WebDriver driver=new ChromeDriver();
	driver.get("url");
	driver.manage().window().maximize();
	List<WebElement> mylist=driver.findElements(By.xpath("//input[@class='list']"));
		for(int i=0;i<mylist.size();i++) 
		{
			if(mylist.get(i).isSelected()) {
		
		mylist.get(i).click();
			}
		}

	}

}
