package Day_35;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Mouse_Over_Demo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		WebElement computer=driver.findElement(By.xpath("//a[@role='button'][normalize-space()='Computers']"));
		WebElement desktop=driver.findElement(By.xpath("//a[@role='button'][normalize-space()='Desktops']"));
		Actions act=new Actions(driver);
		//mouseover action
		Thread.sleep(10);
		act.moveToElement(computer).moveToElement(desktop).click().build().perform();
		//act.moveToElement(computer).moveToElement(desktop).perform();

	}

}
