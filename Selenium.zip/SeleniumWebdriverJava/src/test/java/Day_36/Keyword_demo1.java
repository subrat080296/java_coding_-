//package Day_36;
//
//import org.openqa.selenium.Keys;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//public class Keyword_demo1 {
//
//	public static void main(String[] args) {
//		WebDriver driver=new ChromeDriver();
//		driver.get("url1");
//		//ctrl+c 
//		
//		
//		act.keyDown(Keys.CONTROL).sendkeys("c");
//		
//
//	}
//
//}
