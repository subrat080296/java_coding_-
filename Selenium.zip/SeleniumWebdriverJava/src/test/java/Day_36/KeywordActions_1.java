package Day_36;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class KeywordActions_1 {

	public static void main(String[] args) {
		WebDriver driver= new ChromeDriver();
		driver.get(null);
		
		driver.get("url");
		driver.findElement(By.xpath("url1"));
		Actions act=new Actions(driver);
		act.keyDown(Keys.CONTROL).sendKeys("c").keyUp(Keys.CONTROL).perform();
		
		act.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).perform();

	}

}
