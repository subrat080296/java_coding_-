package Day_36;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Slider_handling_Demo {
	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/slider.php");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Actions act=new Actions(driver);
		//min slider
		//WebElement min_slider=driver.findElement(By.xpath("(//input[@id='ageInputId'])[1]"));
		//System.out.println(min_slider.getLocation());//wiil get x and y axis value before drag
		//act.dragAndDropBy(min_slider, 100,198).perform();
		//System.out.println("after drag:"+ min_slider.getLocation());
		
		// max slider
		WebElement max_slider=driver.findElement(By.xpath("(//input[@id='ageInputId'])[1]"));
		System.out.println(max_slider.getLocation());//wiil get x and y axis value before drag
		act.dragAndDropBy(max_slider, -150,198).perform();
		System.out.println("after drag:"+ max_slider.getLocation());
		
		
		
	
	}
}
