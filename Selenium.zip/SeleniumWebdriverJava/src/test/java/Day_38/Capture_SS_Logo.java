package Day_38;
import org.openqa.selenium.io.FileHandler;
import java.io.IOException;
import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Capture_SS_Logo {

	public static void main(String[] args) throws InterruptedException, IOException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();

Thread.sleep(500);
		WebElement logo=driver.findElement(By.xpath("//img[@alt=\'company-branding\']"));
		
		File Sourcefile1 = logo.getScreenshotAs(OutputType.FILE);
		
		File targetfile1=new File("C:\\Users\\a859230\\OneDrive - ATOS\\Desktop\\image\\image2.png");
		
		FileHandler.copy(Sourcefile1, targetfile1);
		
		 System.out.println("Screenshot saved successfully.");
		
		

	}

}
