package Day_38;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.TakesScreenshot;

public class Take_SS {

	private static final File SourceFile = null;

	public static void main(String[] args) {
	WebDriver driver=new ChromeDriver();
	driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	driver.manage().window().maximize();
  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1000));
	TakesScreenshot ts1=(TakesScreenshot) driver;
	
	//File TargetFile=new File(System.getProperty("user.dir")+"\\Screenshot\\fullpage.png");
	File TargetFile=new File(".\\Screenshot\\homepage.png");
	SourceFile.renameTo(TargetFile);
//	fileUtils(TargetFile);

	}

		
}



