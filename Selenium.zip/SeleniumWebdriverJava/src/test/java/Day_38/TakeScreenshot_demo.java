package Day_38;
import org. openqa.selenium.chrome.ChromeDriver;

import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;


public class TakeScreenshot_demo {

	public static void main(String[] args) {
		WebDriver driver =new ChromeDriver();
		driver.get("https://www.redbus.in/#suggestions");

		TakesScreenshot tss=(TakesScreenshot) driver;
		
		File sourcefile=tss.getScreenshotAs(OutputType.FILE);
		
		File TargetFile=new File (System.getProperty("User.dir")+ "path");
		sourcefile.renameTo(TargetFile);
	}

}
