package Day_38;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Remove_Borwser_iscontrolledbyAutomation {

	public static void main(String[] args)
	{
		ChromeOptions opt=new ChromeOptions();
		opt.setExperimentalOption("excludeSwitches",new String[] {"enable-automation"});
		WebDriver driver=new ChromeDriver(opt);
		driver.manage().window().maximize();
		driver.get("https://demo.nopcommerce.com/");
		
		System.out.println(driver.getTitle());

	}

}
