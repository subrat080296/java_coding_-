package Day_38;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HeadLess_Testing_Demo {

	public static void main(String[] args) {
		ChromeOptions op=new ChromeOptions();
		op.addArguments("--headless=new");
		WebDriver driver=new ChromeDriver(op);
		driver.get("https://demo.nopcommerce.com/");
		String tittle=driver.getTitle();
		System.out.println(tittle);
		
		

	}

}
