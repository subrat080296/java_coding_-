package Day_38;

import java.io.File;

import javax.xml.transform.Source;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SCreenshot_practice {
    public static void main(String[] args) {

        WebDriver driver = new ChromeDriver();

        driver.get("https://www.google.com");

        // Take screenshot
        TakesScreenshot ts = (TakesScreenshot) driver;
        File sourceFile = ts.getScreenshotAs(OutputType.FILE);

        // Destination file
        File targetFile = new File(System.getProperty("user.dir") + "/screenshots/google.png");

        // Copy screenshot
        sourceFile.renameTo(targetFile);

        System.out.println("Screenshot captured successfully.");

        driver.quit();
    }
}