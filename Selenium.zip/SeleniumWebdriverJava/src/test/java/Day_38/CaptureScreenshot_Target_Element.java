package Day_38;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CaptureScreenshot_Target_Element {

	public static void main(String[] args) throws InterruptedException {
	WebDriver driver=new ChromeDriver();
	driver.get("https://demo.nopcommerce.com/");
	driver.manage().window().maximize();
	Thread.sleep(1000);
	TakesScreenshot ts1=(TakesScreenshot)driver;
	WebElement targetss=driver.findElement(By.xpath("//section[@class='product-grid home-page-product-grid']//div[@class='item-grid']"));
	File sf=targetss.getScreenshotAs(OutputType.FILE);
	File tf=new File(System.getProperty("user.dir")+"\\Screenshot\\target.png");
	sf.renameTo(tf);
	
	

	}

}
