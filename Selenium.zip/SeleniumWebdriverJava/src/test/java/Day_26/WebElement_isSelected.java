package Day_26;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElement_isSelected {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/register?returnUrl=%2F");
		driver.manage().window().maximize();
		
		
	//	System.out.println("before selecting anything");
	//	WebElement male_rd=driver.findElement(By.xpath("//input[@id='gender-male']"));
	//	System.out.println(male_rd.isSelected());
	//	WebElement female_rd=driver.findElement(By.xpath("//input[@id='gender-female']"));	
		
		//System.out.println(female_rd.isSelected());
		
		  System.out.println("After male selected");
		   
			WebElement male_rd=driver.findElement(By.xpath("//input[@id='gender-male']"));
			male_rd.click();
			
			System.out.println(male_rd.isSelected());
			
			System.out.println("after selecting female rd");
			
			WebElement female_rd=driver.findElement(By.xpath("//input[@id='gender-female']"));
			female_rd.click();
		   System.out.println(female_rd.isSelected());
		

	}

}
