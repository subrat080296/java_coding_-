package Day_26;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class WebDriver_Get_PageSource {

	public static void main(String[] args) throws InterruptedException {
	WebDriver driver=new ChromeDriver();
		//WebDriver driver=new EdgeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		Thread.sleep(5000);
		driver.manage().window().maximize();
		System.out.println(driver.getPageSource());

	}

}
