package Day_26;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriver_CloseCommand {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		Thread.sleep(5000);
		driver.manage().window().maximize();
		
	//	String Windowid=driver.getWindowHandle();
	//	System.out.println(Windowid);//275AB4342ABC976688983C28D0CAC2A4   // F672801C196DC81E3A20C69567F4273F
		driver.findElement(By.linkText("OrangeHRM, Inc")).click();
		Set<String>Windowid=driver.getWindowHandles();
		System.out.println(Windowid);
		//driver.close();
		Thread.sleep(500);
		driver.quit();

	}

}
