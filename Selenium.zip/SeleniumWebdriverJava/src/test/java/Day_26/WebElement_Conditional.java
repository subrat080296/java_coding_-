package Day_26;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElement_Conditional {

	public static void main(String[] args) {
	WebDriver driver=new ChromeDriver();
	driver.get("https://demo.nopcommerce.com/");
	driver.manage().window().maximize();
	WebElement logo=driver.findElement(By.xpath("//img['alt=\"nopCommerce demo store\']"));
	System.out.println("log is available:" + logo.isDisplayed());
	

	}

}
