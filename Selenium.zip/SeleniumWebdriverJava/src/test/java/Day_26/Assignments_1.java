package Day_26;
import java.util.Set;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class Assignments_1 {
public static void main(String[] args) throws InterruptedException {
 WebDriver driver=new ChromeDriver();
 driver.manage().window().maximize();
 //Thread.sleep(1000);
driver.get("https://testautomationpractice.blogspot.com/");
//  System.out.println(driver.getCurrentUrl());
//  System.out.println(driver.getTitle());
 // System.out.println(driver.getPageSource());
// System.out.println( driver.getWindowHandle());
 Thread.sleep(500);
// driver.findElement(By.linkText("Udemy Courses")).click();
 //Set<String> windowid=driver.getWindowHandles();
 //System.out.println(windowid);
 
 
  driver.findElement(By.xpath("//input[@placeholder='Enter Name']")).sendKeys("Ramcharam");
 WebElement email=driver.findElement(By.xpath("//input[@placeholder='Enter EMail']"));
 email.sendKeys("123r@gmail.com");
 driver.findElement(By.xpath("//input[@placeholder='Enter Phone']")).sendKeys("987654");
 driver.findElement(By.xpath("//textarea[@id=\'textarea\']")).sendKeys("testing automation");
 
 driver.findElement(By.xpath("//input[@id=\'male\']")).click();
 
}
}
