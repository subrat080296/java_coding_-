package Day_29;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Handles_Alert_UsingKEYtext {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//button[@onclick=\'jsPrompt()\']")).click();
		Thread.sleep(5000);
		Alert myalert1=driver.switchTo().alert();
		myalert1.sendKeys("Hello");
		myalert1.accept();
		//myalert1.dismiss();
		

	}

}
