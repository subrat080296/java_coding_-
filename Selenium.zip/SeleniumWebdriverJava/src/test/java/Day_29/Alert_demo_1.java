package Day_29;

import java.time.Duration;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Alert_demo_1 {

	private static final String ExcepectedCodition = null;

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get(null);
		WebDriverWait mywait=new WebDriverWait (driver,Duration.ofSeconds(10));
		driver.findElement(By.xpath("url")).click();
		
		Alert myalert=mywait.until(ExpectedConditions.alertIsPresent());
		
		Alert myalert1=driver.switchTo().alert();
		myalert1.accept();
		myalert1.dismiss();
		myalert1.getText();
		
//		import org.openqa.selenium.support.ui.WebDriverWait;
//		import org.openqa.selenium.support.ui.ExpectedCondition;
//		
//		WebDriverWait mywait=new WebDriverWait(driver, Duration.ofSeconds(10));
//		mywait.until(ExcepectedCodition.isalertPresenet());
	
	}
	

}
