package Day_29;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UncheckCheckSelected_CheckBoxes {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		//for select single check box
	//	driver.findElement(By.xpath("//input[@id='sunday']")).click();
		
		//for select multiple window using forloop
		List<WebElement> checkboxes2= driver.findElements(By.xpath("//input[@class='form-check-input' and @type='checkbox']"));
		//i want to select  5,6,7
		
		for (int i=4;i<checkboxes2.size();i++)
		{
			checkboxes2.get(i).click();
		}
		Thread.sleep(5000);
		for (int i=0;i<checkboxes2.size();i++)
		{
		     if(checkboxes2.get(i).isSelected())// for uncheck those are already checked
		    		 {
		    	       checkboxes2.get(i).click();
		    		 }
			
		}

	}

}
