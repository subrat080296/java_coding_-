package Day_29;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleConfirmation_popof {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//button[@onclick=\'jsConfirm()\']")).click();
		//driver.switchTo().alert().accept();//it will press ok and close the alert
		Thread.sleep(5000);
		driver.switchTo().alert().dismiss();
	}

}
