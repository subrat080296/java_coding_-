package Day_29;

import java.time.Duration;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HandlesAlert_Using_Excilicit_Wait {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		
		WebDriverWait mywait1=new WebDriverWait(driver,Duration.ofSeconds(10));
		
		driver.findElement(By.xpath("//button[@onclick=\'jsAlert()\']")).click();
		
		Alert myalert3=mywait1.until(ExpectedConditions.alertIsPresent());
		
		System.out.println(myalert3.getText());
		myalert3.accept();

	}

}
