package Day_29;

import org.openqa.selenium.WebDriver;

import day1.ChromeDriver;

public class Alert_Handle_Demo21 {

	public static void main(String[] args) throws InterruptedException {
	ChromeDriver driver=new ChromeDriver();
		//WebDriver driver=new EdgeDriver();
		((WebDriver) driver).get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		Thread.sleep(5000);
		((WebDriver) driver).manage().window().maximize();
		System.out.println(((WebDriver) driver).getPageSource());
  
  
}
}