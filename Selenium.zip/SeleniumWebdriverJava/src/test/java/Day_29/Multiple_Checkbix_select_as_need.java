package Day_29;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Multiple_Checkbix_select_as_need {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		//for select single check box
	//	driver.findElement(By.xpath("//input[@id='sunday']")).click();
		
		//for select multiple window using forloop
		List<WebElement> checkboxes1= driver.findElements(By.xpath("//input[@class='form-check-input' and @type='checkbox']"));
		//i want to select  5,6,7
		//7-3
	//	for (int i=3;i<checkboxes1.size();i++) {
			//checkboxes1.get(i).click();
			
			//Select first 3 checkboex
			//for (int i=0;i<3;i++) {
			//	checkboxes1.get(i).click();
				
				//select 4 ,5
				
				for (int i=4;i<6;i++) {
					checkboxes1.get(i).click();
					
			
		}

	}

}
