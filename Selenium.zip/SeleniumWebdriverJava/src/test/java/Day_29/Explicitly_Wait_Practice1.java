package Day_29;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Explicitly_Wait_Practice1 {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get(null);
		driver.manage().window().maximize();
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		
		WebElement Loginb=wait.until(ExpectedConditions.elementToBeClickable(By.id(null)));
		Loginb.click();

	}

}
