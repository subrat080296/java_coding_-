package Day_29;

import java.time.Duration;
//import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alert_Handles {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		//for Normal Alert
		driver.findElement(By.xpath("//button[@onclick=\'jsAlert()\']")).click();
		Thread.sleep(500);
	//	driver.switchTo().alert().accept();
		
	//Capture the text
		
		Alert myalert=driver.switchTo().alert();
	System.out.println(	(myalert.getText()));
	myalert.accept();
		

	}

}
