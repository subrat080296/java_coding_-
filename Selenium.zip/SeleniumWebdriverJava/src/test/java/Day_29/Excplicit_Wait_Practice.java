package Day_29;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Excplicit_Wait_Practice {

	public static void main(String[] args) throws InterruptedException {
	WebDriver driver=new ChromeDriver();
	driver.get("https://demo.nopcommerce.com/login?returnUrl=%2F");
	driver.manage().window().maximize();
	WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
driver.findElement(By.xpath("//input[@id='Email']")).sendKeys("User123@yopmail.com");
  driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("pasword123");
  driver.findElement(By.xpath("//input[@id='RememberMe']")).click();
	WebElement login=wait.until(ExpectedConditions.elementToBeClickable(By.id("//button[normalize-space()='Log in']")));
	Thread.sleep(100);
	login.click();

	}

}
