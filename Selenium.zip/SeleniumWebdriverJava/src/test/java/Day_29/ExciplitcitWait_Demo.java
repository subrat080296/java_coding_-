package Day_29;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExciplitcitWait_Demo {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().window().maximize();
		WebDriverWait mywait4=new WebDriverWait(driver,Duration.ofSeconds(10));
		driver.findElement(By.xpath("//button[@onclick=\"jsConfirm()\"]")).click();
		
		Alert myalert4=mywait4.until(ExpectedConditions.alertIsPresent());
		System.out.print(myalert4.getText());
		myalert4.accept();

	}

}
