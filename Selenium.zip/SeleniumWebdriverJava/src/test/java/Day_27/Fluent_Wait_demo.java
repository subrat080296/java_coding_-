package Day_27;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

public class Fluent_Wait_demo {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("url2");
		Wait<WebDriver>mywait=new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(10)).ignoring(NoSuchElementException.class);

	}

}
