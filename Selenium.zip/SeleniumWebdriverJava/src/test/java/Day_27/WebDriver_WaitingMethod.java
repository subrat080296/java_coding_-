package Day_27;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriver_WaitingMethod {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		//driver.get("https://demo.nopcommerce.com/register?returnUrl=%2F");
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
	//	driver.findElement(By.xpath("//input[@name=\'FirstName\']")).sendKeys("rohon");
		Thread.sleep(500);
		driver.findElement(By.xpath("//input[@placeholder=\'Username\']")).sendKeys("sree1324@gmail.com");

	}

}
