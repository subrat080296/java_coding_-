package Day_27;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

//import org.openqa.selenium.By;

public class ExceplicitWait_demo2 {

	public static void main(String[] args) {
	WebDriver driver=new ChromeDriver();
	WebDriverWait wb=new WebDriverWait(driver,Duration.ofSeconds(10));
	driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	driver.manage().window().maximize();
	WebElement Username=wb.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder=\'Username\']")));
	Username.sendKeys("ram76");
	

	}

}
