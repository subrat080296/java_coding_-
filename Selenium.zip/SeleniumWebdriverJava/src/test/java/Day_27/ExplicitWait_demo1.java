package Day_27;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import org.openqa.selenium.*;
public class ExplicitWait_demo1 {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		WebDriverWait mywait1=new WebDriverWait(driver,Duration.ofSeconds(10));
		WebElement checkbiox=mywait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("url1")));
		checkbiox.sendKeys("right");
	}

}
