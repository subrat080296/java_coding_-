package Day_22;

public class Day_22_demo {

	public static void main(String[] args) {
		System.out.println("Hello");

	}

}
