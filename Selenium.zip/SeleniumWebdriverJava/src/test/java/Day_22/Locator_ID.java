package Day_22;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locator_ID {

	public static void main(String[] args) {
		WebDriver driver =new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/");
		driver.manage().window().maximize();
		boolean logoisdisplaystatus=driver.findElement(By.id("header-logo")).isDisplayed();
		System.out.println(logoisdisplaystatus);

	}

}
