package Day_42;

import org.testng.annotations.Test;

//open an application or url
//login 
//logout

public class TestNG_FirstTestcase {
	@Test (priority=1)
  void openapp()
  {
	  System.out.println("opening the application");
	 
  }
	@Test (priority=2)
  void login()
  {
	System.out.println("login successfully")  ;

  }
	@Test (priority=3)
  void logout()
  {
	  System.out.println("logout successfully");
  }
}
