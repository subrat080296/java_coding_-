package Day_42;

import org.testng.annotations.Test;

public class Test_NG_demo_1 {
	
	@Test(priority=1)
	void openbrowser() 
	{
		System.out.println("Brower is opened successfully");
		}
	@Test(priority=3)
	void Login() {
		System.out.println("login successfully");
		
	}
	@Test(priority=2)
	void logout() {
		System.out.println("Loout successfully");
	}

}
