package Day_42;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
//Open application
//verify Logo
//Login successfully
//close
public class OrrangeHrm_demo {
	
	WebDriver driver;// this a class variable so that we can  access any where within the package
	
	
  @Test(priority=1)
  void openapp() 
  {
	driver= new ChromeDriver();
	driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
  }
  @Test(priority=2)
  void verifyLogo() throws InterruptedException
  {
	  Thread.sleep(10);
	 Boolean Logo= driver.findElement(By.xpath("//img[@alt='company-branding']")).isDisplayed();
	 System.out.println(Logo);
	 
  }
  @Test(priority=3)
  void loginsuccessfully() {
	  driver.findElement(By.xpath("//input[@name='username']")).sendKeys("UserID");
	  driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Password");
	  driver.findElement(By.xpath("//button[@type='submit']")).click();
//		 driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("admin");
//		 driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("password");
//		 driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
  }
  @Test(priority=4)
  void close() {
	  driver.close();
  }
}
