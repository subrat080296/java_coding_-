package Day_23;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Page_Size_demo1 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		
		Thread.sleep(1000);
		Dimension d4=new Dimension(500,300);
		driver.manage().window().setSize(d4);
		
		
		Dimension size_w_h=driver.manage().window().getSize();
		int w_size=size_w_h.getWidth();
		System.out.println(w_size);
		int h_size=size_w_h.getHeight();
		System.out.println(h_size);

	}

}
