package Day_23;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Height_width_Window {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("https://www.google.com/");
		
		Thread.sleep(1000);
		//determine demention
	      Dimension d1 = new Dimension(200, 500);
		
		   driver.manage().window().setSize(d1);
		   
		  Dimension d2=driver.manage().window().getSize();
		   int width=d2.getWidth();
		   System.out.println(width);
		   int height=d2.getHeight();
		   System.out.println(height);
//		   
//		  WebElement wl= driver.findElement(By.xpath("//textarea[@id='APjFqb']"));
//          int serchbox_ht= 	wl.getRect().getHeight();
//          System.out.println(serchbox_ht);
//	        int secrhbix_wdt=   wl.getRect().getWidth();
//	        System.out.println(secrhbix_wdt);
	           
	           

	}

}
