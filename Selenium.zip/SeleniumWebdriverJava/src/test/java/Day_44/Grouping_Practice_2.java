package Day_44;

import org.testng.annotations.Test;

public class Grouping_Practice_2 {
	
	@Test
	void signup() {
		System.out.println("Signupby mail");
	}
	@Test
	void signup1() {
		System.out.println("Signupby mobile");
	}
	@Test
	void signup2() {
		System.out.println("Signupby number");
	}

}
