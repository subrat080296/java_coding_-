package Day_44;

import org.testng.annotations.Test;

public class Grouing_Demo2 {
@Test(priority=1, groups= {"regression"})
void signupbymail() {
	System.out.println("signup by email");
}
@Test(priority=2, groups= {"regression"})
void signupbyfacebook() {
	System.out.println("signup by facebook");
}
@Test(priority=3, groups= {"regression"})
void signupbyTwitter() {
	System.out.println("signup by Twitter");
}
}
