package Day_44;

import org.testng.annotations.Test;

public class Grouping_Practice_1 {
	
	@Test(priority=1 ,groups= {"sanity", "regression"})
	void login() {
		System.out.println("facebook login");
	}
	@Test
	void login1() {
		System.out.println("Instagram login");
	}
	@Test
	void login3() {
		System.out.println("yt login");
	}

}
