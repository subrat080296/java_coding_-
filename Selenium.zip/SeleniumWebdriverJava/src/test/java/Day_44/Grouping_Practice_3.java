package Day_44;

import org.testng.annotations.Test;

public class Grouping_Practice_3 {
	
	@Test
	void payment() {
		System.out.println("payment by card");
	}
	@Test
	void payment1() {
		System.out.println("payment by gpay");
	}
	@Test
	void payment2() {
		System.out.println("payment by phpay");
	}

}
