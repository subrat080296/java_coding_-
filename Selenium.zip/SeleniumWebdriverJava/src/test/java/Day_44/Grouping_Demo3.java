package Day_44;

import org.testng.annotations.Test;

public class Grouping_Demo3 {
@Test(priority=1, groups= {"sanity","regression","functional"})
void PaymentsinRupees() {
	System.out.println("payment in rupees...........");
}
@Test(priority=2,groups= {"sanity","regression","functional"})
void PaymentsinDollar() {
	System.out.println("payment in Dollar.............");
}
}
