package Day_44;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Dependency_Practice_1 {
	
	@Test(priority=1)
	void openapp() {
		Assert.assertTrue(false);
	}
	@Test(priority=2 , dependsOnMethods={"openapp"})
	void search() {
		Assert.assertTrue(true);
	}
	@Test(priority=3)
	void logout() {
		Assert.assertTrue(true);
	}
	@Test(priority=4 , dependsOnMethods={"search"})
	void advsearch() {
		Assert.assertTrue(true);
	}

}
