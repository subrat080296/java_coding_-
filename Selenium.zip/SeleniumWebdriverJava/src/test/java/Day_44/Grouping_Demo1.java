package Day_44;

import org.testng.annotations.Test;

public class Grouping_Demo1 {
@Test(priority=1, groups= {"sanity"})
void Login() {
	System.out.println("login by mail");
}
@Test(priority=2,groups= {"sanity"})
void loginbyfacebook() {
	System.out.println("login in to facebook");
}
@Test(priority=3,groups= {"sanity"})
void loginTwitter() {
	System.out.println("login in Twitter");
}
}
