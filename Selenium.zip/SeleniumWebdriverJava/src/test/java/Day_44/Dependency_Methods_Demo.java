package Day_44;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Dependency_Methods_Demo {

	@Test(priority=1)
	void openapp() {
		Assert.assertTrue(true)	;

	}
	@Test(priority=2 )
	void Login() {
		Assert.assertTrue(false);
	}
	@Test(priority=3,dependsOnMethods= {"Login"})
	void Search() {
		Assert.assertTrue(true);
	}
	@Test(priority=4, dependsOnMethods= {"Login"})
	void Logout() {
		Assert.assertTrue(true);
	}

}
