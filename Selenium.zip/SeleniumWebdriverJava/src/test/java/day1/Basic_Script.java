package day1;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Basic_Script {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		WebDriver driver= new ChromeDriver();
		driver.get("https://www.google.com/search?q=images+flowers&shoprs=GBIqB2Zsb3dlcnMyCggSEgZJbWFnZXNgAQ&sa=X&ved=2ahUKEwj1uobJsaeNAxUsma8BHbJDAIkQip4GKAJ6BAgZEFs");
		////String title = driver.getTitle();
		//System.out.println("Title is : "+title);
		//
		//WebElement emailBox = driver.findElement(By.id("Email"));
		//emailBox.clear();
		//emailBox.sendKeys("subrata.jena123.com");
		
		//driver.findElement(By.id("Email")).sendKeys("subrata.jena@edifixio.com");
		///driver.findElement(By.id("password")).sendKeys("Subrat");
		//driver.findElement(By.xpath("//*[@id=\"yDmH0d\"]/c-wiz/div/div[2]/div/div/div/form")).click();
		
		//driver.close();
		List<WebElement> images=driver.findElements(By.tagName("imges"));
		System.out.println("total number of image:"+ images.size());
		

	}

}
