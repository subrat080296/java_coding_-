package day1;

import org.openqa.selenium.firefox.FirefoxDriver;

public class ChromeDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FirefoxDriver driver = new FirefoxDriver();
		driver.close();
         
	}

}
