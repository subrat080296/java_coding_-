package day1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class Locate_Element_Using_PartiaLinktext {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/electronics");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("Apparel")).click();

	}

}
