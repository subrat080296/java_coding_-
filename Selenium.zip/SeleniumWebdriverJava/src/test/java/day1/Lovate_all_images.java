package day1;

import java.util.List;

import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
public class Lovate_all_images {

	public static void main(String[] args) {
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://demo.nopcommerce.com/");
		driver.manage().window().maximize();
		
		List<WebElement>images= driver.findElements(By.tagName("img"));
		System.out.println(images.size());
		driver.close();
		

	}

}
