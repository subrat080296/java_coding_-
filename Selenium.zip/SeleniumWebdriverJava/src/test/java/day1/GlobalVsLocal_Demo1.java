package day1;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

public class GlobalVsLocal_Demo1 {
	
	
	//this global variable
	static String base1_url ="https://orangehrm.com/";

	public static void main(String[] args) {
		
		
		//Local Variable
		
	//	String Base_url="https://demo.nopcommerce.com/";
		
		// WebDriver driver = new ChromeDriver();
		
		WebDriver driver=new ChromeDriver();
		
		
		driver.get(base1_url);
		
		String title=driver.getTitle();
		
		System.out.println(title);
		
		String pagesource=driver.getPageSource();
		System.out.println(pagesource);
	
		
		driver.close();

	}

}
