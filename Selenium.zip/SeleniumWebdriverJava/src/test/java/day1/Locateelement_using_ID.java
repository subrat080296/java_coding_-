package day1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.By;

public class Locateelement_using_ID {

	public static void main(String[] args) {
	WebDriver driver=new ChromeDriver();
	driver.get("https://demo.nopcommerce.com/electronics");
	driver.manage().window().maximize();
	//id
	driver.findElement(By.id("Search")).isDisplayed();
	System.out.println("logo will display");

	}

}
