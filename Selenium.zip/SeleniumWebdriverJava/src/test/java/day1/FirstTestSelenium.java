package day1;

import org.openqa.selenium.chrome.ChromeDriver;

/*
 * Test 1
 * Launch chrome browser
 * Open url https:demo.opencart.com/
 * validate title should be "your store"
 * close browser
 */

public class FirstTestSelenium {

	public static void main(String[] args) {
		
	// Launch chrome browser
		ChromeDriver driver=new ChromeDriver();
		
		//Open url https:demo.opencart.com/
		driver.get("https://demo.opencart.com/");
		
		//validate title should be "your store"
  String act_tittle= driver.getTitle();
  if (act_tittle.equals("your store"))
  {
	  System.out.println("Test Passed");
  }
	  else
	  {
		  System.out.println("Test failed");
	  }
  //close browser
 // driver.close();
  
  }
	}


