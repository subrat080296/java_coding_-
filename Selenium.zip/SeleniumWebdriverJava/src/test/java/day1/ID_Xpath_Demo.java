package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ID_Xpath_Demo {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		
		driver.manage().window().maximize();
		Thread.sleep(1000);
		
		
	      //	Using ID Loacator
		
	    //   driver.findElement(By.id("twotabsearchtextbox")).sendKeys("laptop");
	       
	       
	     //  Using Name Locator
	       
	    //   driver.findElement(By.name("field-keywords")).sendKeys("Mobile");
	       
	       driver.findElement(By.linkText("Login")).click();
	       
	       

	}

}
