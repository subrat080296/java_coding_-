package day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class StartsWith_xpath_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		
		//h5[stsrts-with(text(),oxd-text oxd-text--h5 orangehrm-login-title]
		
		//p[starts-with(text(),forgot]

	}

}
