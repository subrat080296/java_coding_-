package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class Contains_xpath_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub\
		
		WebDriver driver =new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		driver.manage().window().maximize();
		
		//Contains 
		driver.findElement(By.xpath("//form[@contains(text(),\'search\']")).click();

	}

}
