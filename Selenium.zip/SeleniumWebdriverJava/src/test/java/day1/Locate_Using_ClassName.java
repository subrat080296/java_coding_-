package day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

import org.openqa.selenium.By;

public class Locate_Using_ClassName {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.nopcommerce.com/computers");
		//List<WebElement> headerLinks= driver.findElements(By.className("header-upper"));
		List<WebElement>Links= driver.findElements(By.tagName("a"));
		System.out.println("Toatl no of hrader link:" +  Links.size());
		//driver.close();

	}

}
