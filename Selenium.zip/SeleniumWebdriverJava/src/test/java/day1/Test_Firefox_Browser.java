package day1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Test_Firefox_Browser {

	public static void main(String[] args) {
		/*
		 * Test 1
		 * Launch chrome//ff browser
		 * Open url https:demo.opencart.com/  ; https://demo.nopcommerce.com/
		 * validate title should be "your store"
		 * close browser
		 */
		
		WebDriver driver=new FirefoxDriver();
				driver.get("https://demo.nopcommerce.com/");
				String act_title=driver.getTitle();
				{
					if(act_title.equals("Your store"))
					{
						System.out.println("Test Pass");
						
					}
					else {
						System.out.println("test Failed");
					}
					driver.close();
				}
				
				
		
		

	}

}
