package Day_45;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Data_Driven_Practice {
	WebDriver driver;
	@Test(dataProvider="dp1")
	void Login(String email, String pwd) throws InterruptedException {
		driver=new ChromeDriver();
		driver.get("https://tutorialsninja.com/demo/index.php?route=account/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//input[@id='input-email']")).sendKeys(email);
		driver.findElement(By.xpath("//input[@id='input-password']")).sendKeys(pwd);
		driver.findElement(By.xpath("//input[@value='Login']")).click();
		Assert.assertTrue(true);
		Thread.sleep(100);
		driver.close();
	}
    @DataProvider(name="dp1", indices= {0,3,5})//it will run the user is and pass as per given Index number
 Object[][] loginData()
 {
	Object data1[][]= {
		{"abc121@gmail.com","Password123"},
	    {"abc1211@gmail.com","Password1234"},
	    {"abc1212@gmail.com","Password1235"},
	    {"abc1213@gmail.com","Password1236"},
		{"abc1214@gmail.com","Password1237"},
		{"abc1215@gmail.com","Password1238"},
	    };
	return data1;
 }
    

}
