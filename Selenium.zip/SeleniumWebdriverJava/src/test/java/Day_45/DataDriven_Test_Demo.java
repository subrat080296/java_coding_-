package Day_45;

//import static org.testng.Assert.fail;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataDriven_Test_Demo {
	WebDriver driver;
	@Test(dataProvider="dp")
		void testlogin(String email , String pwd) throws InterruptedException {
		driver=new ChromeDriver();
		driver.get("https://tutorialsninja.com/demo/index.php?route=account/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//input[@id='input-email']")).sendKeys(email);
		driver.findElement(By.xpath("//input[@id='input-password']")).sendKeys(pwd);
		driver.findElement(By.xpath("//input[@value='Login']")).click();
		Thread.sleep(1000);
		boolean status=driver.findElement(By.xpath("//div[@class='alert alert-danger alert-dismissible']")).isDisplayed();
		if(status==true) {
			driver.findElement(By.xpath("//div[@class='form-group']//a[normalize-space()='Forgotten Password']")).click();
			Assert.assertTrue(true);
			
			
		}
		else {
			Assert.fail();
		}
	}
	@AfterClass
	void teardowb() {
		driver.close();
	}


//Same Steps i will do multiple login with different user id and password


    @DataProvider(name="dp", indices= {0,3,5})//it will run the user is and pass as per given Index number
 Object[][] loginData()
 {
	Object data[][]= {
		{"abc121@gmail.com","Password123"},
	    {"abc1211@gmail.com","Password1234"},
	    {"abc1212@gmail.com","Password1235"},
	    {"abc1213@gmail.com","Password1236"},
		{"abc1214@gmail.com","Password1237"},
		{"abc1215@gmail.com","Password1238"},
	    };
	return data;
 }
    
}
