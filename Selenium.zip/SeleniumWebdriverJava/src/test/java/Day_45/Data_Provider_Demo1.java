package Day_45;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Data_Provider_Demo1 {
	
	WebDriver driver;
	

	@BeforeClass
	void setup() {
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
	}
	@Test(dataProvider="dataprovider")
	void Login(String email , String pass ) throws InterruptedException {
		driver.get("https://demo.guru99.com/V4/");
		driver.findElement(By.xpath("//input[@name='uid']")).sendKeys(email);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pass);
		driver.findElement(By.xpath("//input[@name='btnLogin']")).click();
		
		
	boolean status=	driver.findElement(By.xpath("//td[normalize-space()='Manger Id : mngr']")).isDisplayed();
		//Thread.sleep(100);
	
	if(status==true) {
		driver.findElement(By.xpath("//a[@href='EditCustomer.php']")).click();
		Assert.assertTrue(true);
	}
	 else
	{
		Assert.assertTrue(false);
	}
	}
	@AfterClass
	void tearDown() 
	{
		driver.quit();
	}
	
	@DataProvider(name ="dataprovider" , indices= {0,3,4})//Name is used for data provoder purpose  and indica=es is used for drtemine the Index 
	Object[][]Logindata()
	{
		Object data[][]= 
			{ 
				{"user1","password1"},
				{"user2","password2"},
				{"user3","password3"},
				{"user4","password4"},
				{"mngr662681","gaqypAv"},
		};
		return data;
	}

}

