package Day_45;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Parameterization_Practice {
	WebDriver driver;
	
	@Parameters({"browser"})
	@BeforeClass
	void Setup(String br) {
		
		driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
	}
	@Test
	void Title() {
		Assert.assertEquals(driver.getTitle(),"OrangeHRM");
	}
	
	@Test
	void logo() {
		boolean suatus=driver.findElement(By.xpath("//img[@alt='company-branding']")).isDisplayed();
		
		Assert.assertEquals(suatus, true);
	}
	
	@Test
	void URL() {
				
				Assert.assertEquals(driver.getCurrentUrl(), "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
				
				Assert.assertTrue(true);
	}
	@AfterClass
	void teardown() {
		driver.close();
	}

}
