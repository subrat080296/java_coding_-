package Day_47;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

          public class POM_demo {
	
		// Creating this for a LOGIN PAGE
		
		
		WebDriver driver;
		//Constructor
		
		POM_demo(WebDriver driver)
		{
			this.driver=driver;
		}
		
		//Locator
		
	//WebElement Usernametxt=driver.findElement(By.xpath("//input[@placeholder='Username']"));
	
	By loc_username = By.xpath("//input[@placeholder='Username']");
//	driver.findElement(loc_username).senfKeys("sxz123");
	
	By loc_password = By.xpath("//input[@placeholder='Password']");
	//driver.findElement(loc_password).senfKeys("pass123");
	
	By loc_btn = By.xpath("//button[normalize-space()='Login']");
		
		//Action Method
	
	public void setUsername(String username123)
	{
		driver.findElement(loc_username).sendKeys("username123");
		
	}
	public void setPassword(String password123)
	{
		driver.findElement(loc_password).sendKeys("password123");
	}
	public void clicklogin()
	
	{
		driver.findElement(loc_btn).click();
		
	}
		

		
	
}
