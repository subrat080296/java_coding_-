package Day_47;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



public class POM_LoginTest 
	{
	        WebDriver driver;
		
	      	@BeforeClass
		
			void setup() 
			{
				driver = new ChromeDriver();
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
				driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	            driver.manage().window().maximize();
	          }
			@Test
			void Login() 
			{
				POM_demo login=new POM_demo(driver);
				login.setUsername("Admin");
				login.setPassword("admin123");
				login.clicklogin();
				
				Assert.assertEquals(driver.getTitle(), "OrangeHRM");
			}
			
			@AfterClass
			void TearDown() {
			//	driver.quit();
			
		
		
		

	}

}
