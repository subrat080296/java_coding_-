package Day_47;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LoginTest {
	WebDriver driver;
	@BeforeClass
	void setup() {
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}
	@Test
	void test() 
	{
		Login_Page login=new Login_Page(driver);
		login.setUsername("Admin");
		login.setpassword("admin123");
		login.button();
		
		Assert.assertEquals(driver.getTitle(),"OrangeHRM");
	}
	@AfterClass
	void tearDSown() {
		driver.quit();
	}

}
