package Day_47;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login_Page {
	
	//When ever we creating page object class we are considering 3 main parts
	WebDriver driver;
	
	//Constructor
	Login_Page (WebDriver driver)
	{
		this.driver=driver;
		
	}
	
	
	//Locator
     By username_loc=By.xpath("//input[@placeholder='Username']");
	By pass_p=By.xpath("//input[@placeholder='Password']");
	By btn_login=By.xpath("//button[normalize-space()='Login']");
	
	
	//Actions
	
	public void setUsername(String user) {
		driver.findElement(username_loc).sendKeys("Admin");
		
	}
	public void setpassword(String pass) {
		driver.findElement(pass_p).sendKeys("pass");
		
	}
	public void button() {
		driver.findElement(btn_login).click();
	}

}
