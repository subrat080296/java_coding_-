package Day_47;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Page_Fact_Login_1 {
	
	
	WebDriver driver;
	
	
	//Constructor
	Page_Fact_Login_1(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
		
	}
	
	//Locator
	
	@FindBy(xpath="//input[@placeholder='Username']")
	WebElement txtUserName;
	
	@FindBy(xpath="//input[@placeholder='Password']")
	WebElement txtUserPass;
	
	@FindBy(xpath="//button[normalize-space()='Login']")
	WebElement btn_login;
           //}
// Actions 

public void setUserName(String user) 
{
	txtUserName.sendKeys("Admin");
         }
        public void setUserPass(String Pass) 
        {
        	txtUserPass.sendKeys("admin123");
        }
        public void cliklogin() {
        	btn_login.click();
        }
        }
       
